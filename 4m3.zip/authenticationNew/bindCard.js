/*
* 输入信息 名字
* */

var name;//名字
var peoId;//身份证号
var demo1;//职业
var bankno;//银行卡号
var phone_num;//银行卡预留手机号
var userId;//用户id

//下个页面需要带入的数据
var msg = {
    name : "" ,
    peoId : '',
    phone_num :'',
    bankno : '',
    userId : ''
};
$(function(){
    setTimeout(function(){
        IsNeedClear();
        getTransferData("login_key");
        //获取卡号
        if($('#peoCard').val() !== ''){
            bankno = $('#peoCard').val().replace(/\s/g,"");
            if (bankno == "") {
                return;
            }
            if (luhmCheck(bankno)) {
                //获取卡信息；
                getBankType(bankno);

            }
        }
        queryAgreement();
    },100);
});
$(".get").click(function () {
    phone_num = $("#phone_num").val();
    var reg01 = /^[1][3,4,5,6,7,8,9][0-9]{9}$/;
    if(phone_num == ''){
        // alert("请输入预留手机号");
        tipsError("请输入预留手机号");
    }else if(!(reg01.test(phone_num))){
        // alert("手机号格式不正确");
        tipsError("手机号格式不正确");
    }else{
        $(".get").attr("disabled", true);
        var count_down = parseInt(60);
        $(".get").val("60S");
        $(".get").css("color", "#999");
        var time = setInterval(function () {
            count_down--;
            $(".get").val(count_down + "S");
            if (count_down < 0) {
                clearInterval(time);
                $(".get").val("重新发送");
                $(".get").css("color", "#1673d0");
                $(".get").attr("disabled", false);
            }
        }, 1000);
        //获取验证码
        getCode();
    }
});

//获取验证码
function getCode() {
    msgCodeEvent('点击发送验证码-绑定银行卡','bindCard.html','1');
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.auth.shortMsgLoginCheck";
    //请求参数追加自定义参数
    jsonObject["sendType"] = "0";
    jsonObject["queryEacctFlag"] = "0";
    jsonObject["mobile"] = phone_num;
    // jsonObject["schFlag"] = "1";
    var jsonObject2 =secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.auth.shortMsgLoginCheck";
    getForData(jsonObject2,function(data){
        if (isBeta) {
            $("#codeNo").val(data.dymcode);
            focusAnimation('#codeNo');
        }
        tipsWell(data.retMsg);
    });
}

//验证什么银行的卡
$("#peoCard").blur(function (e) {
    //获取卡号
    bankno = (this.value).replace(/\s/g,"");
    if (bankno == "") {
        return;
    }
    if (luhmCheck(bankno)) {
        //获取卡信息；
        getBankType(bankno);

    }
});

//获取银行卡信息
function getBankType(bankno) {
    var jsonObject = getJsonObject();
    //请求参数追加自定义参数
    jsonObject["method"] = "dbk.account.getBindCardInfo";
    jsonObject["userId"] = getMid();
    jsonObject["cardNo"] = bankno;
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.account.getBindCardInfo";
    getForData(jsonObject2, function (data) {
        banks = data;
        $("#singleLimit").text(moneyOfFormat2(data.singlePenLimit));
        $("#dayLimit").text(moneyOfFormat2(data.dayTopLimit));
        $("#bankName").text(data.bankName);
        $("#bankType").text(data.card);
        $("#bankIcon").attr('src', checkCard(data.bankNo).icon);
        $(".card-info").show();
    });
}

function queryAgreement() {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.auth.selectAgreement";
    var jsonObject4 = secondaryIndilling(jsonObject);
    jsonObject4["method"] = "dbk.auth.selectAgreement";
    showLoding();
    //请求参数追加自定义参数
    getForData(jsonObject4, function (data) {
        $('#agreement').text('《' + data.outerName + '》').attr('href', data.value);
        $('#agreement1').text('《' + data.prOuterName + '》').attr('href', data.prValue)
    });
}

$("#nextBtn").click(function(){
    name = $("#name").val();
    peoId = $("#peoId").val();
    demo1 = $("#demo1").val();
    phone_num = $("#phone_num").val();
    // bankno = $("#peoCard").val();
    // var reg02 = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
    if(name == ''){
        // Alert('请输入名字');
        tipsError('请输入名字');
    } else if (!proving(peoId)) {
        // Alert('请输入正确格式的身份证号码');
        tipsError('请输入正确格式的身份证号码');
    }
    else if(demo1 == ''){
        // Alert('请选择职业');
        tipsError('请选择职业');
    } else if (!luhmCheck(bankno)) {
        return;
    } else if (phone_num.length < 11 && !testP(phone_num)) {
        // Alert('请输入正确格式的预留手机号');
        tipsError('请输入正确格式的预留手机号');
    } else if ($("#codeNo").val() == '' && !/^\d{6}$/.test($("#codeNo").val())) {
        // Alert('请输入正确格式的验证码');
        tipsError('请输入正确格式的验证码');
    }else if(!($("#agreeInput").is(":checked"))){
        tipsError("请勾选协议");
    }else{
        msgCodeEvent('提交验证码-绑定银行卡','bindCard.html','2');
        msg.name = name;
        msg.peoId = peoId;
        msg.phone_num = phone_num;
        msg.bankno = bankno;
        msg.userId = getMid();
        var jsonObject = getJsonObject();
        jsonObject["method"] = "dbk.account.checkUserIdCardAndBankCardInfo";
        //请求参数追加自定义参数
        jsonObject["custName"] = name;
        jsonObject["idNo"] = peoId;
        jsonObject["cardNo"] = bankno;
        jsonObject["reservedPhone"] = phone_num;
        jsonObject["dymCode"] = $("#codeNo").val();
        jsonObject["mobile"]= getMobile();
        var jsonObject2 =secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.account.checkUserIdCardAndBankCardInfo";
        getForData(jsonObject2,function(data){
            if(data.retCode == '000000'){
                window.location.href='../authenticationNew/set_password.html?txt$' + encodeURI(JSON.stringify(msg));
                try {
                    var UMSAObject = getUMSAObject();
                    UMSAObject["eventDesc"] = '用户绑卡认证成功';
                    postEventActivityJsonUMSA("event0020",'personal-info.html',UMSAObject);
                }catch (e){
                    Alert(e.message);
                }
            }
        },true,function (badData) {
            var UMSAObject = getUMSAObject();
            UMSAObject["eventDesc"] = '用户绑卡认证失败';
            postEventActivityJsonUMSA("event0021",'personal-info.html',UMSAObject);
            tipsError(badData.retMsg);
        });
    }
});

//点击返回按钮
$("#shback").click(function () {
    if($("#typeTitle").html() === '支持银行及限额'){
        $('#supportBankAndLimitPage').hide();
        $("#b_Card").show();
        $("#typeTitle").html('绑定银行卡');
    }else if($("#typeTitle").html() === '绑定银行卡'){
        showPopAffirm('温馨提示','尚未完成开户操作，是否确认退出？','取消','确定');
        $(".cancel01").click(function(){
            hidePopAffirm();
        });
        $(".confirm").click(function(){
            if(localStorage.getItem('firstTwo') != '0'){
                localStorage.setItem('firstTwo','1');
            }
            shClose();
        });
    }
});

//手机物理返回键禁用
isgoback(true);
function onBackPressed(){
    if($("#typeTitle").html() === '支持银行及限额'){
        $('#supportBankAndLimitPage').hide();
        $("#b_Card").show();
        $("#typeTitle").html('绑定银行卡');
    }else if($("#typeTitle").html() === '绑定银行卡'){
        showPopAffirm('温馨提示','尚未完成开户操作，是否确认退出？','取消','确定');
        $(".cancel01").click(function(){
            hidePopAffirm();
        });
        $(".confirm").click(function(){
            if(localStorage.getItem('firstTwo') == null || localStorage.getItem('firstTwo') != 0){
                localStorage.setItem('firstTwo','1');
            }
            shClose();
        });
    }
}

