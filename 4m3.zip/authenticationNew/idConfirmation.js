/*页面逻辑
*判断是从开户上级页面进入还是其他页面高低门槛进入
* 点击图片先调用 原生的OCR方法 进行图片上传
* 上传以后自动调用原生方法 获得 图片数据 调用getText方法 进行页面反显
* 点击下一步的时候 先调用接口进行后台验证身份  再提交图片给后台
* 进入结果页面
* */
var msg;
var dat;
var fo;
setTimeout(function () {
    IsNeedClear();
    getTransferData("login_key");
    var Request = new Object();
    Request = GetRequest();
    dat=(Request["txt"]);
    if(dat){
        fo = JSON.parse(dat);
    }else{
        fo = {};
    }
    msg = fo;
    if(msg.isOpen === '0'){
        $("#nextStep").text('完  成');
    }else{
        $("#nextStep").text('下 一 步');
    }
    var UMSAObject = getUMSAObject();
    UMSAObject["eventDesc"] = '身份认证';
    postEventActivityJsonUMSA("event0022_idConfirmation",'idConfirmation.html',UMSAObject);
}, 100);
var imgD = [];
var imageData = [];
$('#viewExample').click(function(){
    $('#exampleCon').show();
});
//点击拍摄正面的图片进行 正面拍摄 身份证
$("#butfrist").click(function () {

    if (/iphone|ipad|ipod/.test(ua)) {
        window.iOS.goToOCRwithStatusBusinessTypeEacctNo("1", "BS001", getEAcct());
    } else if (/android/.test(ua)) {
        window.android.gointoOCR();
    }
});

//点击拍摄反面的图片进行 正面拍摄 身份证
$("#butnext").click(function () {

    if (/iphone|ipad|ipod/.test(ua)) {
        window.iOS.goToOCRwithStatusBusinessTypeEacctNo("0", "BS001", getEAcct());
    } else if (/android/.test(ua)) {
        window.android.gointoOCR1();
    }

});


function getfirstImg(imagepath) {
    if (/android/.test(ua)) {
        var cc = JSON.parse(imagepath);
        imgD[0] = cc;
//			if(cc["isFront"]) {
//				$("#firstImg").attr("src", "../../" + cc["imagePath"].replace("/sdcard/", ""));
//			} else {
//				$("#nextImg").attr("src", "../../" + cc["imagePath"].replace("/sdcard/", ""));
//			}
    }
    if (/iphone|ipad|ipod/.test(ua)) {
        if (imagepath.fileType == "P0002") {
            // Alert("请扫描识别身份证头像面")
            tipsError("请扫描识别身份证头像面");
        } else {
            $("#firstImg").attr("src", imagepath.imagePath);
            imageData[0] = imagepath;
        }
    }
    //反显
    getText();
}
$('#rgoTo').click(function(){
    showPopAffirm('温馨提示','若跳过上传身份证，您的e账户部分功能将受到限制，建议您现在上传，请确认是否跳过','跳过','继续上传');

    $('.cancel01').click(function(){
        //是否走的是开户流程
        if(msg.isOpen === '1'){
            // 判断是否上传身份验证
            var fromHtml='1';
            window.location.href = 'openAccountResult.html?txt$' + fromHtml;
        }else{ //从身份认证过来的
            window.history.go(-1);
        }
    });

    $(".confirm").click(function(){
        hidePopAffirm();
    })
});

function getfirstImg1(imagepath) {
    if (/android/.test(ua)) {
        $("#firstImg").attr("src", "data:image/png;base64," + imagepath);

        var ima = {};

        ima["fileType"] = "P0002";

        ima["ImageName"] = MathRand() + ".JPG";
        ima["Image"] = imagepath;
        imageData[1] = ima;
    }
}

function MathRand() {
    var Num = "";
    for (var i = 0; i < 6; i++) {
        Num += Math.floor(Math.random() * 10);
    }
    return Num;
}

function getnextImg1(imagepath) {

    $("#nextImg").attr("src", "data:image/png;base64," + imagepath);

    if (/android/.test(ua)) {
        var ima = {};
        ima["fileType"] = "P0001";
        ima["ImageName"] = MathRand() + ".JPG";
        ima["Image"] = imagepath;
        imageData[0] = ima;
    }
}

function getnextImg(imagepath) {
    if (/android/.test(ua)) {

        var cc = JSON.parse(imagepath);
        imgD[1] = cc;
//			if(cc["isFront"]) {
//				$("#firstImg").attr("src", "../../" + cc["imagePath"].replace("/sdcard/", ""));
//			} else {
//				$("#nextImg").attr("src", "../../" + cc["imagePath"].replace("/sdcard/", ""));
//			}
    }
    if (/iphone|ipad|ipod/.test(ua)) {
        if (imagepath.fileType == "P0002") {
            $("#nextImg").attr("src", imagepath.imagePath);
            imageData[1] = imagepath;

        } else {
            // Alert("请扫描识别身份证国徽面")
            tipsError("请扫描识别身份证国徽面");
        }
    }
}

// 原声自动调用以后 直接得到数据
function getText(){
    if (/android/.test(ua)) {
        $("#idCardInfoShow").show();
        $("#name").val(imgD[0].getName);
        focusAnimation("#name");
//            $("#gender").html(dat[0].gender);
//         $("#nation").text(dat[0].nation);
//            $("#birthday").html(dat[0].birthday);
//         $("#address").val(dat[0].address);
//            $("#idNumber").val(dat[0].idNumber);
        $("#peoId").val(imgD[0].getId);
        focusAnimation('#peoId');
        // $("#authority").text(dat[1].authority);
        // $("#validity").html(dat[1].validity);
    } else if (/iphone|ipad|ipod/.test(ua)) {
        $("#idCardInfoShow").show();
        $("#name").val(imageData[0].name || imageData[0].custName);
        focusAnimation("#name");
        $("#peoId").val(imageData[0].idNumber || imageData[0].idNo);
        focusAnimation('#peoId');
    }

};

$("#nextStep").click(function () {
    if (imageData.length == 2) {
        var jsonObject = getJsonObject();
        jsonObject["method"] = "dbk.account.checkUserIdcardInfo";//进行身份验证的接口
        if(/android/.test(ua)){
            // jsonObject['custName'] = imgD[0].getName;//名字
            jsonObject['custName'] = $("#name").val();//名字

            // jsonObject['idNo'] = imgD[0].getId;//身份
            jsonObject['idNo'] = $("#peoId").val();//身份
            jsonObject['autcority'] = imgD[1].getlssueauthority;//机关
            jsonObject['address'] = imgD[0].getAddress;//地址
            jsonObject["validity"] = imgD[1].getValidity;//有效期
            jsonObject["nation"] = imgD[0].getNational;//minzu

        }else if(/iphone|ipad|ipod/.test(ua)){
            // jsonObject['custName'] = imageData[0].custName;//名字
            jsonObject['custName'] = $("#name").val();//名字
            // jsonObject['idNo'] = imageData[0].idNo;//身份
            jsonObject['idNo'] = $("#peoId").val();//身份
            jsonObject['address'] = imageData[0].address;//地址
            jsonObject["validity"] = imageData[1].validity;//有效期
            jsonObject['autcority'] = imageData[1].autcority;//机关
            jsonObject["nation"] = imageData[0].nation;//minzu
        }
        var jsonObject2 = secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.account.checkUserIdcardInfo";
        getForData(jsonObject2,function(data){
            if (data.retCode == "000000") {
                //身份认证成功以后 上传图片给后台
                imgCheck();
            } else {
                Alert(resultMsg);
            }
        })
        // showLoding();
        // ajax({
        //     method: "POST",
        //     url: address,
        //     data: jsonObject2,
        //     contentType: "application/x-www-form-urlencoded;charset=utf-8",
        //     timeout: requestTimeOut,
        //     dataType: "json",
        //     success: function (data1) {
        //         dissmissLoding();
        //         var data = secondaryde(data1);
        //
        //     }
        // });
    } else {
        // Alert("请提交完整的数据")
        tipsError("请提交完整的数据");
    }
});

function ajax(opt) {
    opt = opt || {};
    opt.method = opt.method.toUpperCase() || 'POST';
    opt.url = opt.url || '';
    opt.async = opt.async || true;
    opt.data = opt.data || null;
    opt.success = opt.success || function () {
    };
    jsonpFunction = opt.success;
    var xmlHttp = null;
    if (XMLHttpRequest) {
        xmlHttp = new XMLHttpRequest();
    } else {
        xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
    }
    var params = [];
    for (var key in opt.data) {
        params.push(key + '=' + opt.data[key]);
    }

    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4) {
            dissmissLoding();
            if (xmlHttp.status == 200) {
                eval(xmlHttp.responseText);
            } else {
                requestFailTips();
            }
        }
    };

    var postData = params.join('&');
    if (opt.method.toUpperCase() === 'POST') {
        xmlHttp.open(opt.method, opt.url, opt.async);
        xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded;charset=utf-8');
        xmlHttp.send(postData);
    } else if (opt.method.toUpperCase() === 'GET') {
        xmlHttp.open(opt.method, opt.url + '?' + postData, opt.async);
        xmlHttp.send(null);
    }
}

$('#shback').click(function () {
    showPopAffirm('温馨提示','若跳过上传身份证，您的e账户部分功能将受到限制，建议您现在上传，请确认是否跳过','跳过','继续上传');

    $('.cancel01').click(function(){
        //是否走的是开户流程
        if(msg.isOpen === '1'){
            // 判断是否上传身份验证
            var fromHtml='1';
            window.location.href = 'openAccountResult.html?txt$' + fromHtml;
        }else{ //从身份认证过来的
            window.history.go(-1);
        }
    });

    $(".confirm").click(function(){
        hidePopAffirm();
    })
});
isgoback(true);

function onBackPressed() {
    showPopAffirm('温馨提示','若跳过上传身份证，您的e账户部分功能将受到限制，建议您现在上传，请确认是否跳过','跳过','继续上传');

    $('.cancel01').click(function(){
        //是否走的是开户流程
        if(msg.isOpen === '1'){
            // 判断是否上传身份验证
            var fromHtml='1';
            window.location.href = 'openAccountResult.html?txt$' + fromHtml;
        }else{ //从身份认证过来的
            window.history.go(-1);
        }
    });

    $(".confirm").click(function(){
        hidePopAffirm();
    })
}
screenshot(true);


//点击跳过

//点击下一步的时候 先验证身份 再提交图片
function imgCheck(){
    //传过去信息进行验证
    if (imageData.length == 2) {
        var jsonObject = getJsonObject();
        jsonObject["method"] = "dbk.image.imageUpload";
        jsonObject["eacctNo"] = getEAcct();
        jsonObject["accountFlag"] = "1";
        jsonObject["channel"] = "C0001";
        imageData[0]["businessType"] = "BS001";
        imageData[1]["businessType"] = "BS001";
        jsonObject["ImageList"] = imageData;
        var jsonObject2 = secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.image.imageUpload";

        //上传图片的方式
        jsonObject2.securityData = jsonObject2.securityData.replace(/\+/g, "%2B");
        jsonObject2.securityData = jsonObject2.securityData.replace(/\&/g, "%26");
        jsonObject2.digitalEnvelope = jsonObject2.digitalEnvelope.replace(/\+/g, "%2B");
        jsonObject2.digitalEnvelope = jsonObject2.digitalEnvelope.replace(/\&/g, "%26");
        jsonObject2.dataSummary = jsonObject2.dataSummary.replace(/\+/g, "%2B");
        jsonObject2.dataSummary = jsonObject2.dataSummary.replace(/\&/g, "%26");
        showLoding();
        ajax({
            method: "POST",
            url: address.replace("=?", "=jsonpFunction"),
            data: jsonObject2,
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            timeout: requestTimeOut,
            dataType: "json",
            success: function (data1) {
                dissmissLoding();
                var data = secondaryde(data1);
                if (data.retCode == "000000") {
                    //加入判断有没有进行身份认证的
                    getm(function(){
                        //是否走的是开户流程
                        if(msg.isOpen === '1'){
                            // 判断是否上传身份验证
                            var fromHtml='0';
                            if (/android/.test(ua)) {
                                window.location.href = "openAccountResult.html?txt$" + fromHtml;
                            }
                            if (/iphone|ipad|ipod/.test(ua)) {
                                window.location.href = "openAccountResult.html?txt$" + fromHtml;
                            }
                        }else{ //从身份认证过来的
                            window.history.go(-1);
                        }
                        var UMSAObject = getUMSAObject();
                        UMSAObject["eventDesc"] = '身份认证成功';
                        postEventActivityJsonUMSA("event0022_idConfirmation_success",'idConfirmation.html',UMSAObject);
                    });
                } else {
                    // Alert("上传失败")
                    tipsError("上传失败");
                    var UMSAObject = getUMSAObject();
                    UMSAObject["eventDesc"] = '身份认证失败';
                    postEventActivityJsonUMSA("event0022_idConfirmation_fail",'idConfirmation.html',UMSAObject);
                }
            }
        });
    } else {
        // Alert("请提交完整的数据");
        tipsError("请提交完整的数据");
    }
}
