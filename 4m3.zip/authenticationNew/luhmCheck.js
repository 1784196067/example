/**
 *  luhmCheck.js
 * Created by  hyl on  2018/3/27  13:49.
 */
//银行卡号校验

//Description:  银行卡号Luhm校验

//Luhm校验规则：16位银行卡号（19位通用）:

// 1.将未带校验位的 15（或18）位卡号从右依次编号 1 到 15（18），位于奇数位号上的数字乘以 2。
// 2.将奇位乘积的个十位全部相加，再加上所有偶数位上的数字。
// 3.将加法和加上校验位能被 10 整除。

function luhmCheck(bankno) {
    bankCard = $("#peoCard").val();
    if (bankno.length < 15 || bankno.length > 19) {
//			alert(bankno.substring(0, 6));

        // alert('银行卡号长度必须在15到19之间');
        tipsError('银行卡号长度必须在15到19之间');
        // formatBankNo(bankCard);
        return false;

    }
    var num = /^\d*$/;  //全数字
    if (!num.exec(bankno)) {

        // alert('银行卡号必须全为数字');
        tipsError('银行卡号必须全为数字');
        // formatBankNo(bankCard);
        return false;
    }
    //开头6位
    var strBin = "10,18,30,35,37,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,58,60,62,65,68,69,84,87,88,94,95,98,99";
    if (strBin.indexOf(bankno.substring(0, 2)) == -1) {
        console.log('银行卡号开头6位不符合规范');
        // alert('银行卡号输入错误，请重新输入');
        tipsError('银行卡号输入错误，请重新输入');
        // formatBankNo(bankCard);
        return false;
    }
    var lastNum = bankno.substr(bankno.length - 1, 1);//取出最后一位（与luhm进行比较）

    var first15Num = bankno.substr(0, bankno.length - 1);//前15或18位
    var newArr = new Array();
    for (var i = first15Num.length - 1; i > -1; i--) {    //前15或18位倒序存进数组
        newArr.push(first15Num.substr(i, 1));
    }
    var arrJiShu = new Array();  //奇数位*2的积 <9
    var arrJiShu2 = new Array(); //奇数位*2的积 >9

    var arrOuShu = new Array();  //偶数位数组
    for (var j = 0; j < newArr.length; j++) {
        if ((j + 1) % 2 == 1) {//奇数位
            if (parseInt(newArr[j]) * 2 < 9)
                arrJiShu.push(parseInt(newArr[j]) * 2);
            else
                arrJiShu2.push(parseInt(newArr[j]) * 2);
        }
        else //偶数位
            arrOuShu.push(newArr[j]);
    }

    var jishu_child1 = new Array();//奇数位*2 >9 的分割之后的数组个位数
    var jishu_child2 = new Array();//奇数位*2 >9 的分割之后的数组十位数
    for (var h = 0; h < arrJiShu2.length; h++) {
        jishu_child1.push(parseInt(arrJiShu2[h]) % 10);
        jishu_child2.push(parseInt(arrJiShu2[h]) / 10);
    }

    var sumJiShu = 0; //奇数位*2 < 9 的数组之和
    var sumOuShu = 0; //偶数位数组之和
    var sumJiShuChild1 = 0; //奇数位*2 >9 的分割之后的数组个位数之和
    var sumJiShuChild2 = 0; //奇数位*2 >9 的分割之后的数组十位数之和
    var sumTotal = 0;
    for (var m = 0; m < arrJiShu.length; m++) {
        sumJiShu = sumJiShu + parseInt(arrJiShu[m]);
    }

    for (var n = 0; n < arrOuShu.length; n++) {
        sumOuShu = sumOuShu + parseInt(arrOuShu[n]);
    }

    for (var p = 0; p < jishu_child1.length; p++) {
        sumJiShuChild1 = sumJiShuChild1 + parseInt(jishu_child1[p]);
        sumJiShuChild2 = sumJiShuChild2 + parseInt(jishu_child2[p]);
    }
    //计算总和
    sumTotal = parseInt(sumJiShu) + parseInt(sumOuShu) + parseInt(sumJiShuChild1) + parseInt(sumJiShuChild2);

    //计算Luhm值
    var k = parseInt(sumTotal) % 10 == 0 ? 10 : parseInt(sumTotal) % 10;
    var luhm = 10 - k;

    if (lastNum == luhm) {
        return true;

    }else {
        console.log('银行卡号必须符合Luhm校验');
        // alert('银行卡校验失败，请重新输入');
        tipsError('银行卡校验失败，请重新输入');
        // formatBankNo(bankCard);
        return false;
    }
};


//获取银行logo;
function checkCard(bankNo) {
    var cardList=[
        {"cardIcon":"../img/bank_img/BANK_CCB@2x.png","bankNo": "105100000017","bg":"../img/openEAccount/BANK_CCB@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_CMB@2x.png","bankNo":"308584000013","bg":"../img/openEAccount/BANK_CMB@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_COMM@2x.png","bankNo":"301290000007","bg":"../img/openEAccount/BANK_COMM@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_ICBC@2x.png","bankNo": "102100099996","bg":"../img/openEAccount/BANK_ICBC@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_BOC@2x.png","bankNo":"104100000004","bg":"../img/openEAccount/BANK_BOC@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_ABC@2x.png","bankNo":"103100000026","bg":"../img/openEAccount/BANK_ABC@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_HXBANK@2x.png","bankNo":"304100040000","bg":"../img/openEAccount/BANK_HXBANK@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_GDB@2x.png","bankNo":"306581000003","bg":"../img/openEAccount/BANK_GDB@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_CMBC@2x.png","bankNo":"305100000013","bg":"../img/openEAccount/BANK_CMBC@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_CIB@2x.png","bankNo":"309391000011","bg":"../img/openEAccount/BANK_CIB@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_CITIC@2x.png","bankNo": "302100011000","bg":"../img/openEAccount/BANK_CITIC@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_BJBANK@2x.png","bankNo":"313100000013","bg":"../img/openEAccount/BANK_BJBANK@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_CEB@2x.png","bankNo":"303100000006","bg":"../img/openEAccount/BANK_CEB@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_SHBANK@2x.png","bankNo":"313290000017","bg":"../img/openEAccount/BANK_SHBANK@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_SPDB@2x.png","bankNo":"310290000013","bg":"../img/openEAccount/BANK_SPDB@2x.png"},
        // {"cardIcon":"../img/bank_img/BANK_SPABANK@2x.png","bankNo":"313584099990","bg":"../img/openEAccount/BANK_SPABANK@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_SPABANK@2x.png","bankNo":"307584007998","bg":"../img/openEAccount/BANK_SPABANK@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_NJCB@2x.png","bankNo":"313301008887","bg":"../img/openEAccount/BANK_NJCB@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_PSBC@2x.png","bankNo": "403100000004","bg":"../img/openEAccount/BANK_PSBC@2x.png"},
        {"cardIcon":"../img/bank_img/BANK_SHRCB@2x.png","bankNo": "322290000011","bg":"../img/openEAccount/BANK_SHRCB@2x.png"}
    ];
    var cards={};
    cards["icon"]="../img/bank_img/BANK_default.png";
    cards["bg"]="../img/openEAccount/BANK_default.png";
    for(var i=0;i<cardList.length;i++){
        if(bankNo==cardList[i].bankNo){
            cards["icon"]=cardList[i].cardIcon;
            cards["bg"]=cardList[i].bg;
            return cards;
        }
    }
    return cards;
};