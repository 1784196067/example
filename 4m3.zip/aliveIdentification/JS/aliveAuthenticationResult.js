/**
 * Created by wangshengkui on 2017/5/16.
 */
var isShowGoToManualAuditButton = undefined; // 是否显示人工审核按钮
var aliveResultDataDict = {};
var busType = undefined;
var strUserId = undefined;
var aliveSuccess = undefined;
$(function(){
    $('#successDiv').hide();
    $('#falseDiv').hide();
    $("#id_p_check").hide();
    setTimeout(function() {
        IsNeedClear();
        getTransferData("login_key");
        var Request = new Object();
        Request = GetRequest();
        var result = (Request["txt"]);
        var resultDict = JSON.parse(result);
        isShowGoToManualAuditButton = resultDict.isShowSubAuditButton;
        busType = resultDict.busType;
        strUserId = resultDict.userId;
        aliveSuccess = resultDict.aliveIsSuccess;
        aliveResultDataDict.userId = strUserId;
        aliveResultDataDict.busType = busType;
        if (busType == "0" ){
            aliveResultDataDict.newPhoneNumber = resultDict.newPhoneNumber;
        }
        if (busType == "2" ){
            aliveResultDataDict.backHtmlPage = resultDict.backHtmlPage;
        }
        setUpAliveResultView(aliveSuccess,busType);

        // 人工审核
        $('#goToAuditButton').click(function(){
            window.location.href = "manualAuditLead.html?txt$"+JSON.stringify(aliveResultDataDict);
        });
        // 重新检测
        $('#againStartAlive').click(function(){
            var newNumber = undefined;
            if (busType == "0"){
                newNumber = resultDict.newPhoneNumber;
            }
            // clickStartAliveIdentification("0",busType,strUserId,newNumber);
            /**
             * 人脸识别   IOS 调用宜签人脸  android 调用商汤人脸
             */
            if (/iphone|ipad|ipod/.test(ua)) {
                clickStartAliveIdentification("0",busType,strUserId,newNumber);
            } else if (/android/.test(ua)) {
                window.android.goToSTSilentLiveness();
            }
        });
        // 返回按钮_成功返回按钮隐藏
        $('#aliveResultBack').click(function(){
            window.location.href = "selectVerifyMode.html?txt$"+JSON.stringify(aliveResultDataDict);
        });
        // 人脸识别成功_修改操作完成_点击完成
        $('#id_alive_result_finishButton').click(function(){
            if (busType == '4'){
                // shClose();
                window.location.href = '../../featuredNew/featuredIndex.html';
            }
            if (busType == '0'){
                // 修改登录手机号完成
                // shClose();
                window.location.href = '../../featuredNew/featuredIndex.html';
            }
            if (busType == '1'){
                //重置交易密码
                window.location.href = "../../settingNew/accountSafe.html";
            }
            if (busType == '2'){
                // 交易认证完成
                window.location.href = resultDict.backHtmlPage;
            }
        });
    },100);

});
isgoback(true);
function onBackPressed(){
    isgoback(true);
    if (canGoBack) {
        if (aliveSuccess == "true") {
            if (busType == '0') {
                // 修改登录手机号完成
                shClose();
            }
            if (busType == '4') {
                shClose();
            }
            if (busType == '1') {
                //重置交易密码
                window.location.href = "../../security_center/security_settings.html";
            }
            if (busType == '2') {
                // 交易认证完成
                window.location.href = aliveResultDataDict.backHtmlPage;
            }
        } else {
            window.location.href = "selectVerifyMode.html?txt$" + JSON.stringify(aliveResultDataDict);
        }
    } else {
        return;
    }
}
// 重新检测__采集成功__点击下一步
function clickAliveIdentificationNextButton(aliveData){
    setCheckShow('true');
    setTimeout(function(){
        var jsonObject2_alive = getJsonObject();
        var methodString = undefined;
        if(busType == "0"){
            methodString = "dbk.changeMobile.secondRequest";
        }else {
            methodString = "dbk.account.secondRequest";
        }
        jsonObject2_alive["userId"] = strUserId;
        if (/iphone|ipad|ipod/.test(ua)) {
            jsonObject2_alive["reqData"] = aliveData.data;
            jsonObject2_alive["reqHash"] = aliveData.hash;
            jsonObject2_alive["reqExtra"] = aliveData.extra;
            jsonObject2_alive["transId"] = aliveData.transId;
        } else if (/android/.test(ua)) {
            jsonObject2_alive["reqData"] = JSON.parse(aliveData).data;
            jsonObject2_alive["reqHash"] = JSON.parse(aliveData).hash;
            jsonObject2_alive["reqExtra"] = JSON.parse(aliveData).extra;
            jsonObject2_alive["transId"] = JSON.parse(aliveData).transId;
        }
        jsonObject2_alive["method"] = methodString;
        var jsonObject2_alive2 = secondaryIndilling(jsonObject2_alive);
        jsonObject2_alive2["method"] = methodString;
        jsonObject2_alive2.securityData = jsonObject2_alive2.securityData.replace(/\+/g, "%2B");
        jsonObject2_alive2.securityData = jsonObject2_alive2.securityData.replace(/\&/g, "%26");
        jsonObject2_alive2.digitalEnvelope = jsonObject2_alive2.digitalEnvelope.replace(/\+/g, "%2B");
        jsonObject2_alive2.digitalEnvelope = jsonObject2_alive2.digitalEnvelope.replace(/\&/g, "%26");
        jsonObject2_alive2.dataSummary = jsonObject2_alive2.dataSummary.replace(/\+/g, "%2B");
        jsonObject2_alive2.dataSummary = jsonObject2_alive2.dataSummary.replace(/\&/g, "%26");
        showLoding();
        ajax({
            method: "POST",
            url: address.replace("=?","=jsonpFunction"),
            data: jsonObject2_alive2,
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            timeout: requestTimeOut,
            dataType: "json",
            success: function(data1) {
                dissmissLoding();
                var aliveData = secondaryde(data1);
                if (aliveData != null && aliveData.retCode == "000000") {
                    if (aliveData.resConfirm == "true"){
                        aliveSuccess = "true";
                        aliveSuccessNextStop(busType);
                    }else {
                        setCheckShow('false');
                    }
                }else {
                    setCheckShow('false');
                    alert(aliveData.retMsg);
                }
            },
            error: function () {
                setCheckShow('false');
                requestFailTips();
            }
        });
    },100);
}


function aliveSuccessNextStop(busTypeNumber){
    if (busTypeNumber == "0"){
        // 修改登录手机号
        var jsonObject = getJsonObject();
        //请求参数追加自定义参数
        jsonObject["method"] = "dbk.changeMobile.changeMobileNo";
        jsonObject["newMobileNo"] = aliveResultDataDict.newPhoneNumber;//手机号
        jsonObject["userId"] = strUserId;
        var jsonObject2 = secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.changeMobile.changeMobileNo";
        $.ajax({
            type: "POST",
            url: address,
            data: jsonObject2,
            timeout: requestTimeOut,
            dataType: "json",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            beforeSend: function () {
                showLoding();
            },
            success: function (data1) {
                setCheckShow('false');
                var data = secondaryde(data1);
                if (data.retCode == "000000") {
                    setUpAliveResultView("true",busTypeNumber);
                } else{
                    alert(data.retMsg);
                }
            },
            error: function () {
                requestFailTips();
            },
            complete: function () {
                dissmissLoding();
            }
        });
    }
    if (busTypeNumber == "1"){
        // 重置交易密码页面
        dataSelectModeDict.aliveIsSuccess = "true";
        window.location.href = "resetTradePassword.html?txt$"+JSON.stringify(dataSelectModeDict);
        dissmissLoding();
    }
    if (busTypeNumber == "2"){
        var jsonObject = getJsonObject();
        //请求参数追加自定义参数
        jsonObject["method"] = "dbk.account.dealTDLimit";
        jsonObject["userId"] = strUserId;
        var jsonObject2 =secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.account.dealTDLimit";
        $.ajax({
            type: "POST",
            url: address,
            data: jsonObject2,
            timeout: requestTimeOut,
            dataType: "json",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            beforeSend: function () {
                showLoding();
            },
            success: function (data1) {
                setCheckShow('false');
                var data= secondaryde(data1);
                if (data.retCode == "000000") {
                    setUpAliveResultView("true",busTypeNumber);
                } else {
                    alert(data.retMsg);
                }
            },
            error: function () {
                requestFailTips();
            },
            complete: function () {
                dissmissLoding();
            }
        });
    }
    if (busTypeNumber == "4"){
        setUpAliveResultView("true",busTypeNumber);
        dissmissLoding();
    }
}
// 布局页面的显示效果
function setUpAliveResultView(aliveResult,busTypeNumber){
    $('#successDiv').hide();
    $('#falseDiv').hide();
    if (aliveResult == "true"){
        // 验证通过
        $('#aliveResultBack').hide();
        $("#id_alive_success_p_0").hide();
        $("#id_alive_success_p_1").hide();
        $("#id_alive_success_p_2").hide();
        $("#id_alive_success_p_4").hide();

        if(busTypeNumber == '0'){
            // 修改登录手机号
            $("#id_alive_success_p_0").show();
        }
        if (busTypeNumber == "1"){
            $("#id_alive_success_p_1").show();
        }
        if (busTypeNumber == "2"){
            // 交易认证
            $("#id_alive_success_p_2").show();
        }
        if (busTypeNumber == "4"){
            // 交易认证
            $("#id_alive_success_p_4").show();
        }
        $('#successDiv').show();
    }else {
        if (isShowGoToManualAuditButton == "false"){
            $('#goToAuditButton').hide();
            $("#id_audit_msg").hide();
        }else {
            $("#id_audit_reset").hide();
        }
        $('#falseDiv').show();
    }
}

var canGoBack = true;
function  setCheckShow(isShow){
    if (isShow == "true"){
        //TODO：
        // $(".more_header").hide();
        canGoBack = false;
        $('#aliveResultBack').hide();
        $(".manualAudit_two").hide();
        $("#id_p_check").show();
        return;
    }
    if (isShow == "false"){
        canGoBack = true;
        $('#aliveResultBack').show();
        // 返回按钮_成功返回按钮隐藏
        $('#aliveResultBack').click(function () {
            window.location.href = "selectVerifyMode.html?txt$" + JSON.stringify(aliveResultDataDict);
        });
        $(".more_header").show();
        $(".manualAudit_two").show();
        $("#id_p_check").hide();
    }
}

// 商汤人脸识别回调
function stLivenessCallback(faceBase64) {
    uploadImg(faceBase64);
}

function uploadImg(faceData) {
    setCheckShow('true');
    var imageData = [];
    var img = {};
    img["fileType"] = "P0003";
    img["ImageName"] = MathRand() + ".JPG";
    img["Image"] = faceData;
    img["businessType"] = "BS001";
    imageData[0] = img;

    var methodSt = undefined;
    if(busType == '0'){
        methodSt = "dbk.idConfirmWithoutLogin.checkIdentityConfirm";
    }else {
        methodSt = "dbk.idConfirm.checkIdentityConfirm";
    }

    var jsonObject = getJsonObject();
    jsonObject["ImageList"] = JSON.stringify(imageData);
    jsonObject["userId"] = strUserId;
    jsonObject["valType"] = "0";// 验证方式 0:人脸  1:人工
    jsonObject["busType"] = busType;// 业务类型 0:修改登录手机号  1:重置该交易密码 2:4 3:更改绑定卡 6:自营贷 7:扫码
    jsonObject["method"] = methodSt;
    if (/iphone|ipad|ipod/.test(ua)) {
        jsonObject["appType"] = "IOS"; // 客户端类型
    } else if (/android/.test(ua)) {
        jsonObject["appType"] = "ST"; // 客户端类型
    }
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = methodSt;
    jsonObject2.securityData = jsonObject2.securityData.replace(/\+/g, "%2B");
    jsonObject2.securityData = jsonObject2.securityData.replace(/\&/g, "%26");
    jsonObject2.digitalEnvelope = jsonObject2.digitalEnvelope.replace(/\+/g, "%2B");
    jsonObject2.digitalEnvelope = jsonObject2.digitalEnvelope.replace(/\&/g, "%26");
    jsonObject2.dataSummary = jsonObject2.dataSummary.replace(/\+/g, "%2B");
    jsonObject2.dataSummary = jsonObject2.dataSummary.replace(/\&/g, "%26");
    ajax({
        method: "POST",
        url: address.replace("=?", "=jsonpFunction"),
        data: jsonObject2,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        timeout: requestTimeOut,
        dataType: "json",
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            dissmissLoding();
            var aliveData = secondaryde(data1);
            if (aliveData != null && aliveData.retCode == "000000") {
                if (aliveData.resConfirm == "true"){
                    aliveSuccess = "true";
                    aliveSuccessNextStop(busType);
                }else {
                    setCheckShow('false');
                }
            }else {
                setCheckShow('false');
                alert(aliveData.retMsg);
            }
        },
        error: function () {
            setCheckShow('false');
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}
