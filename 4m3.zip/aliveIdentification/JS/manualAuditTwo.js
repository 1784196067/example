/**
 * Created by wangshengkui on 2017/5/15.
 */
var auditTwoDataDict = {}; // 界面之间数据传递字典
var uploadManualImageArray = []; // 上传的图片数组
$(function () {
    setTimeout(function () {
        IsNeedClear();
        getTransferData("login_key");
        var Request = new Object();
        Request = GetRequest();
        var result = (Request["txt"]);
        var resultTwoDict = JSON.parse(result);
        var strUserId = resultTwoDict.userId;
        auditTwoDataDict.busType = resultTwoDict.busType;
        auditTwoDataDict.transId = resultTwoDict.transId;
        auditTwoDataDict.idCardNumber = resultTwoDict.idCardNumber;
        auditTwoDataDict.userId = strUserId;
        if (resultTwoDict.busType == "0") {
            auditTwoDataDict.newPhoneNumber = resultTwoDict.newPhoneNumber;
        }
        if (resultTwoDict.busType == "2") {
            auditTwoDataDict.backHtmlPage = resultTwoDict.backHtmlPage;
        }
        if (resultTwoDict.busType == "3") {
            auditTwoDataDict.backHtmlPage = resultTwoDict.backHtmlPage;
            auditTwoDataDict.newBankCard = resultTwoDict.newBankCard;
        }
        if (resultTwoDict.busType == "3") {
            //更改绑定卡,银行阿卡丢失
            $('#id_audit_two_cardLose').show();
            $('#id_audit_table_span').text('上传相关信息');
        } else {
            $('#id_audit_two_cardLose').hide();
            $('#id_audit_table_span').text('上传手持身份证');
        }
        $('#id_audit_two_back').click(function () {
            if (confirm("返回需要重新上传身份证信息")) {
                window.location.href = "manualAuditOnePage.html?txt$" + JSON.stringify(auditTwoDataDict);
            }
        });
        // 点击获取手持身份证
        $("#id_audit_firstImg").click(function () {
            if (/iphone|ipad|ipod/.test(ua)) {
                var cameraDict = {};
                cameraDict.fileType = "P0003";
                cameraDict.busType = resultTwoDict.busType;
                cameraDict.businessType = "BS002";
                cameraDict.eacctNo = strUserId;
                window.iOS.openCameraWithDataDictionary(cameraDict);
            } else if (/android/.test(ua)) {
                window.android.openCameraWithDataDictionary();

            }
        });
        if (resultTwoDict.busType == '3') {
            // 点击获取银行卡遗失证明
            $("#id_audit_secondImg").click(function () {
                if (/iphone|ipad|ipod/.test(ua)) {
                    var cameraDict = {};
                    cameraDict.fileType = "P0004";
                    cameraDict.busType = resultTwoDict.busType;
                    cameraDict.businessType = "BS002";
                    cameraDict.eacctNo = strUserId;
                    window.iOS.openCameraWithDataDictionary(cameraDict);
                } else if (/android/.test(ua)) {
                    window.android.openCameraWithDataDictionary1();

                }
            });
        }
        // 点击下一步,提交图片
        $('#id_audit_two_nextButton').click(function () {
            if (resultTwoDict.busType == '3') {
                if (uploadManualImageArray.length == 2) {
                    uploadManualAuditImageData(uploadManualImageArray, resultTwoDict.transId, resultTwoDict.busType, strUserId);
                } else {
                    alert("请上传完整的数据");
                }
            } else {
                if (uploadManualImageArray.length == 1) {
                    uploadManualAuditImageData(uploadManualImageArray, resultTwoDict.transId, resultTwoDict.busType, strUserId);
                } else {
                    alert("请上传完整的数据");
                }
            }
        });
    }, 100);

});
isgoback(true);
function onBackPressed(){
    if (confirm("返回需要重新上传身份证信息")) {
        window.location.href = "manualAuditOnePage.html?txt$" + JSON.stringify(auditTwoDataDict);
    }
}
function uploadManualAuditImageData(imageList, transId, busType, userId) {
    setTimeout(function () {
        var jsonObject = getJsonObject();
        var methodString = undefined;
        if (busType == "0") {
            methodString = "dbk.changeMobile.uploadIdConfirmImg";
        } else {
            methodString = "dbk.account.uploadIdConfirmImg";
        }
        jsonObject["userId"] = userId;
        jsonObject['transId'] = transId;
        jsonObject["busType"] = busType;
        jsonObject["ImageList"] = imageList;
        jsonObject["method"] = methodString;
        var jsonObject2 = secondaryIndilling(jsonObject);
        jsonObject2["method"] = methodString;
        jsonObject2.securityData = jsonObject2.securityData.replace(/\+/g, "%2B");
        jsonObject2.securityData = jsonObject2.securityData.replace(/\&/g, "%26");
        jsonObject2.digitalEnvelope = jsonObject2.digitalEnvelope.replace(/\+/g, "%2B");
        jsonObject2.digitalEnvelope = jsonObject2.digitalEnvelope.replace(/\&/g, "%26");
        jsonObject2.dataSummary = jsonObject2.dataSummary.replace(/\+/g, "%2B");
        jsonObject2.dataSummary = jsonObject2.dataSummary.replace(/\&/g, "%26");
        showLoding();
        ajax({
            method: "POST",
            url: address.replace("=?", "=jsonpFunction"),
            data: jsonObject2,
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            timeout: requestTimeOut,
            dataType: "json",
            success: function (data1) {
                var data = secondaryde(data1);
                if (data.retCode == "000000") {
                    var phoneNumber = data.retMobile;
                    var phoneTailsNumber = phoneNumber.substring(7, 11);
                    // alert("上传成功");
                    auditTwoDataDict.phoneTailsNumber = phoneTailsNumber;
                    window.location.href = "manualAuditThreePage.html?txt$" + JSON.stringify(auditTwoDataDict);
                } else {
                    alert(data.retMsg);
                }
            },
            error: function () {
                requestFailTips();
            },
            complete: function () {
                dissmissLoding();
            }
        });
    }, 100);
}
/**
 * ios相机回调
 * */
function sendCardData(imageData) {
    if (/iphone|ipad|ipod/.test(ua)) {
        // 手持身份证
        if (imageData.fileType == 'P0003') {
            for (var i = 0;i<uploadManualImageArray.length;i++){
                var imageItem = uploadManualImageArray[i];
                if (imageItem.fileType == "P0003"){
                    uploadManualImageArray.splice(i,1);
                    break;
                }
            }
            uploadManualImageArray.push(imageData);
            $("#id_audit_firstImg").attr("src", imageData.imagePath);

        }
        // 银行卡遗失证明
        if (imageData.fileType == 'P0004') {
            for (var i = 0;i<uploadManualImageArray.length;i++){
                var imageItem = uploadManualImageArray[i];
                if (imageItem.fileType == "P0004"){
                    uploadManualImageArray.splice(i,1);
                    break;
                }
            }
            uploadManualImageArray.push(imageData);
            $("#id_audit_secondImg").attr("src", imageData.imagePath);

        }
    } else {
        //手持
        var cameraDict = {};
        cameraDict.fileType = "P0003";
        cameraDict.busType = auditTwoDataDict.busType;
        cameraDict.businessType = "BS002";
        cameraDict["ImageName"] = MathRand() + ".JPG";

        cameraDict.Image = imageData;
        $("#id_audit_firstImg").attr("src", "data:image/png;base64," + imageData);
        for (var i = 0;i<uploadManualImageArray.length;i++){
            var imageItem = uploadManualImageArray[i];
            if (imageItem.fileType == "P0003"){
                uploadManualImageArray.splice(i,1);
                break;
            }
        }
        uploadManualImageArray.push(cameraDict);
    }
}
function sendCardData1(imageData) {
    //银行卡
    var cameraDict = {};
    cameraDict.fileType = "P0004";
    cameraDict.busType = auditTwoDataDict.busType;
    cameraDict.businessType = "BS002";
    cameraDict.Image = imageData;
    cameraDict["ImageName"] = MathRand() + ".JPG";
    $("#id_audit_secondImg").attr("src", "data:image/png;base64," + imageData);
    for (var i = 0;i<uploadManualImageArray.length;i++){
        var imageItem = uploadManualImageArray[i];
        if (imageItem.fileType == "P0004"){
            uploadManualImageArray.splice(i,1);
            break;
        }
    }
    uploadManualImageArray.push(cameraDict);
}


function MathRand() {
    var Num = "";
    for (var i = 0; i < 6; i++) {
        Num += Math.floor(Math.random() * 10);
    }
    return Num;
}