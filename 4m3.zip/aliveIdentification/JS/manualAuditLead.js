/**
 * Created by wangshengkui on 2017/5/16.
 */
var manualAuditLeadDict = {};
var strUserId = undefined;
var resultManualLeadDictData;
var cardNo;
$(function(){
    $("#id_p_check").hide();
    setTimeout(function() {
        IsNeedClear();
        getTransferData("login_key");
        var Request = new Object();
        Request = GetRequest();
        var result = (Request["txt"]);
        var resultManualLeadDict = JSON.parse(result);
        resultManualLeadDictData = resultManualLeadDict;
        strUserId = resultManualLeadDict.userId;

        manualAuditLeadDict.busType = resultManualLeadDict.busType;
        manualAuditLeadDict.userId = strUserId;
        if (manualAuditLeadDict.busType == "0"){
            manualAuditLeadDict.newPhoneNumber = resultManualLeadDict.newPhoneNumber;
            cardNo=resultManualLeadDict.newPhoneNumber
        }
        if(manualAuditLeadDict.busType == '2'){
            manualAuditLeadDict.backHtmlPage = resultManualLeadDict.backHtmlPage;
        }
        if (manualAuditLeadDict.busType == "3"){
            manualAuditLeadDict.backHtmlPage = resultManualLeadDict.backHtmlPage;
            manualAuditLeadDict.newBankCard = resultManualLeadDict.newBankCard;
            cardNo =resultManualLeadDict.newBankCard;
        }
        $('#id_audit_lead_back').click(function(){
            window.location.href = 'selectVerifyMode.html?txt$'+JSON.stringify(manualAuditLeadDict);
        });
        // 开始申请,活体检测
        $('#startApply').click(function(){
            var newNumber = undefined;
            if (resultManualLeadDict.busType == "0"){
                newNumber = resultManualLeadDict.newPhoneNumber;
            }
            if (resultManualLeadDict.busType == "3"){
                newNumber = resultManualLeadDict.newBankCard;
            }
            // clickStartAliveIdentification('1',resultManualLeadDict.busType,strUserId,newNumber);

            /**
             * 人脸识别   IOS 调用宜签人脸  android 调用商汤人脸
             */
            if (/iphone|ipad|ipod/.test(ua)) {
                clickStartAliveIdentification('1',resultManualLeadDict.busType,strUserId,newNumber);
            } else if (/android/.test(ua)) {
                window.android.goToSTSilentLiveness();
            }
        });
    },100);

});
isgoback(true);
function onBackPressed(){
    window.location.href = 'selectVerifyMode.html?txt$'+JSON.stringify(manualAuditLeadDict);
}
// 采集成功__点击下一步
function clickAliveIdentificationNextButton(aliveData){
    $(".more_header").hide();
    $(".manualAudit_two").hide();
    $("#id_p_check").show();
    setTimeout(function(){
        var jsonObject2_alive = getJsonObject();
        var methodString = undefined;
        if(manualAuditLeadDict.busType == "0"){
            methodString = "dbk.changeMobile.secondRequest";
        }else {
            methodString = "dbk.account.secondRequest";
        }
        jsonObject2_alive["userId"] = strUserId;
        if (/iphone|ipad|ipod/.test(ua)) {
            jsonObject2_alive["reqData"] = aliveData.data;
            jsonObject2_alive["reqHash"] = aliveData.hash;
            jsonObject2_alive["reqExtra"] = aliveData.extra;
            jsonObject2_alive["transId"] = aliveData.transId;
            manualAuditLeadDict.transId = aliveData.transId;
            manualAuditLeadDict.idCardNumber = aliveData.idCardNumber;
        } else if (/android/.test(ua)) {

            jsonObject2_alive["reqData"] = JSON.parse(aliveData).data;
            jsonObject2_alive["reqHash"] = JSON.parse(aliveData).hash;
            jsonObject2_alive["reqExtra"] = JSON.parse(aliveData).extra;
            jsonObject2_alive["transId"] = JSON.parse(aliveData).transId;
            manualAuditLeadDict.transId = JSON.parse(aliveData).transId;
            manualAuditLeadDict.idCardNumber =JSON.parse(aliveData).idCardNumber;

        }
        jsonObject2_alive["method"] = methodString;
        var jsonObject2_alive2 = secondaryIndilling(jsonObject2_alive);
        jsonObject2_alive2["method"] = methodString;
        jsonObject2_alive2.securityData = jsonObject2_alive2.securityData.replace(/\+/g, "%2B");
        jsonObject2_alive2.securityData = jsonObject2_alive2.securityData.replace(/\&/g, "%26");
        jsonObject2_alive2.digitalEnvelope = jsonObject2_alive2.digitalEnvelope.replace(/\+/g, "%2B");
        jsonObject2_alive2.digitalEnvelope = jsonObject2_alive2.digitalEnvelope.replace(/\&/g, "%26");
        jsonObject2_alive2.dataSummary = jsonObject2_alive2.dataSummary.replace(/\+/g, "%2B");
        jsonObject2_alive2.dataSummary = jsonObject2_alive2.dataSummary.replace(/\&/g, "%26");
        showLoding();
        ajax({
            method: "POST",
            url: address.replace("=?","=jsonpFunction"),
            data: jsonObject2_alive2,
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            timeout: requestTimeOut,
            dataType: "json",
            success: function(data1) {
                var aliveData = secondaryde(data1);
                if (aliveData != null && aliveData.retCode == "000000") {

                    // 无论活体认证是否成功,均往下跳转
                    window.location.href = "manualAuditOnePage.html?txt$"+JSON.stringify(manualAuditLeadDict);
                }else {
                    $(".more_header").show();
                    $(".manualAudit_two").show();
                    $("#id_p_check").hide();
                    alert(aliveData.retMsg);
                }
            },
            error: function () {
                requestFailTips();
            },
            complete: function () {
                dissmissLoding();
            }
        });
    },100);
}

// 商汤人脸识别回调
function stLivenessCallback(faceBase64) {
    $(".more_header").hide();
    $(".manualAudit_two").hide();
    $("#id_p_check").show();
    uploadImg(faceBase64);
}

function uploadImg(faceData) {
    var imageData = [];
    var img = {};
    img["fileType"] = "P0003";
    img["ImageName"] = MathRand() + ".JPG";
    img["Image"] = faceData;
    img["businessType"] = "BS001";
    imageData[0] = img;

    var methodSt = undefined;
    if(resultManualLeadDictData.busType == '0'){
        methodSt = "dbk.idConfirmWithoutLogin.checkIdentityConfirm";
    }else {
        methodSt = "dbk.idConfirm.checkIdentityConfirm";
    }

    var jsonObject = getJsonObject();
    jsonObject["ImageList"] = JSON.stringify(imageData);
    jsonObject["userId"] = strUserId;
    jsonObject["accountNo"] = cardNo;

    jsonObject["valType"] = "1";// 验证方式 0:人脸  1:人工
    jsonObject["busType"] = resultManualLeadDictData.busType;// 业务类型 0:修改登录手机号  1:重置该交易密码 2:4 3:更改绑定卡 6:自营贷 7:扫码
    jsonObject["method"] = methodSt;
    if (/iphone|ipad|ipod/.test(ua)) {
        jsonObject["appType"] = "IOS"; // 客户端类型
    } else if (/android/.test(ua)) {
        jsonObject["appType"] = "ST"; // 客户端类型
    }
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = methodSt;
    jsonObject2.securityData = jsonObject2.securityData.replace(/\+/g, "%2B");
    jsonObject2.securityData = jsonObject2.securityData.replace(/\&/g, "%26");
    jsonObject2.digitalEnvelope = jsonObject2.digitalEnvelope.replace(/\+/g, "%2B");
    jsonObject2.digitalEnvelope = jsonObject2.digitalEnvelope.replace(/\&/g, "%26");
    jsonObject2.dataSummary = jsonObject2.dataSummary.replace(/\+/g, "%2B");
    jsonObject2.dataSummary = jsonObject2.dataSummary.replace(/\&/g, "%26");
    ajax({
        method: "POST",
        url: address.replace("=?", "=jsonpFunction"),
        data: jsonObject2,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        timeout: requestTimeOut,
        dataType: "json",
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var aliveData = secondaryde(data1);
            if (aliveData != null && aliveData.retCode == "000000") {
                manualAuditLeadDict.transId = aliveData.transId;
                // 无论活体认证是否成功,均往下跳转
                window.location.href = "manualAuditOnePage.html?txt$"+JSON.stringify(manualAuditLeadDict);
            }else {
                $(".more_header").show();
                $(".manualAudit_two").show();
                $("#id_p_check").hide();
                alert(aliveData.retMsg);
            }
        },
        error: function () {
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}
