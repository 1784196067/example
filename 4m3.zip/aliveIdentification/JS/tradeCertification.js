/**
 * Created by wangshengkui on 2017/5/19.
 */
var busType = undefined;
var backHtmlPage = undefined;
var password01 = '';
var newCardPassword01 = '';
var isTrigger = false;
var isTrigger0 = false;
var flag = '0';
$(function(){
    setTimeout(function(){
        IsNeedClear();
        getTransferData("login_key");
        var Request = new Object();
        Request = GetRequest();
        var result = (Request["txt"]);
        var resultDict = undefined;
        if (JSON.stringify(result) != undefined){
            resultDict = JSON.parse(result);
            busType = resultDict.busType;
        }else {
            busType = '0';
        }
        var newBanCardType = undefined;// 新绑定卡类型
        if(busType == '2' || busType == '3'){
            backHtmlPage = resultDict.backHtmlPage;
        }
        setUpUIView(busType);
        // $("input").focus(function () {
        //     var nh = $('body').height();
        //     var nn = $(this).offset().top;
        //     var he = moneyOfFormat(nn/nh);
        //     if(he > 0.2){
        //         var topHeight = -he*100;
        //         if (he > 0.35){
        //             topHeight = -50;
        //         }
        //         $('section').css('top',topHeight+'px');
        //         return false;
        //     }
        // });
        // $("input").blur(function () {
        //     $('section').css('top','45px');
        //     return false;
        // });
        // 点击身份认证页面 返回按钮
        $("#id_tradeCertification_back").click(function(){
            if (getIsLogined()) {
                if (busType == '0') {
                    shClose01("");
                }
                if (busType == '1') {
                    // window.location.href = "../../security_center/security_settings.html";
                    window.location.href = "../../settingNew/accountSafe.html";
                }
                if (busType == '2') {

                    window.history.go(-1);

                }else if(busType == '3'){
                    window.location.href = backHtmlPage;
                } else {
                    window.location.href = '../../settingNew/accountSafe.html';
                }
            }else{
                shClose01("");
                // startToLogin();
            }
        });
        // 点击获取验证码
        $("#id_getDynamicCode").click(function(){
            var mobileNumber = undefined;
            if (busType == '0'){
                mobileNumber = $("#id_newPhone_number").val();
            }else if(busType == "3"){
                mobileNumber = $('#id_bindNewCard_phoneNumber').val();
            }else{
                mobileNumber = getMobile();
            }
            if(checkFormat_phoneNumber(mobileNumber)){
                $("#id_getDynamicCode").attr("disabled", true);
                var count_down = parseInt(60);
                $("#id_getDynamicCode").val("60s后重新发送");
                $("#id_getDynamicCode").css("color", "#999");
                var time = setInterval(function () {
                    count_down--;
                    $("#id_getDynamicCode").val(count_down + "s");
                    if (count_down < 0) {
                        clearInterval(time);
                        $("#id_getDynamicCode").val("重新发送");
                        $("#id_getDynamicCode").css("color", "#007ae0");
                        $("#id_getDynamicCode").attr("disabled", false);
                    }
                }, 1000);
                getTestCode(mobileNumber);
            }
        });
        // 设置本行卡
        $("#id_bindNewCard").hide();
        $("#id_bindNewCard_number").blur(function(){
            var newCardNumber = $("#id_bindNewCard_number").val().replace(/\s/g,'');
            if (newCardNumber.length > 15 && checkFormat_bankCardNumber(newCardNumber)){
                newBanCardType = checkBankCardType(newCardNumber);
                if (newBanCardType == "2") {
                    // 他行卡
                    $("#id_bindNewCard").hide();
                } else {
                    // 本行卡
                    $("#id_bindNewCard").show();
                }
            }
        });
        // 登录外修改登录手机号,无绑定卡情况处理
        var isBindBankCard = false; // 是否有绑定卡
        $("#id_IDCardNumber").blur(function(){
            var idCardNumber = $("#id_IDCardNumber").val(); // 身份证号码
            if (busType == '0' && idCardNumber.length == 18 && checkFormat_idCardNumber(idCardNumber)){
                var jsonObject = getJsonObject();
                jsonObject["method"] = "dbk.changeMobile.selectBindCardByIdNo";
                jsonObject["idNo"] = idCardNumber;
                var jsonObject2 =secondaryIndilling(jsonObject);
                jsonObject2["method"] = "dbk.changeMobile.selectBindCardByIdNo";
                $.ajax({
                    type: "POST",
                    url: address,
                    data: jsonObject2,
                    timeout: requestTimeOut,
                    dataType: "json",
                    contentType: "application/x-www-form-urlencoded;charset=utf-8",
                    beforeSend: function () {
                        showLoding();
                    },
                    success: function (data1) {
                        var data= secondaryde(data1);
                        if (data.retCode == "000000") {
                            if (data.flag == "1"){
                                isBindBankCard = true; // 有绑定卡
                                // $("#id_trade_bankCard").show();
                            }else {
                                isBindBankCard = false; // 无绑定卡
                            }
                        }else if (data.retCode == "Login9999") {
                            logout();
                            doKickOutAction("", "");
                        } else if (data.retCode == "Login9998") {
                            logout();
                            logout1("home");
                        }else {
                            alert(data.retMsg);
                        }
                    },
                    error: function () {
                        requestFailTips();
                    },
                    complete: function () {
                        dissmissLoding();
                    }
                });
            }
        });

        // 点击下一步
        $('#id_tradeCertification_nextButton').click(function(){
            var idCardNumber = $("#id_IDCardNumber").val(); // 身份证
            var bankCardNumber = $("#id_bankCardNumber").val().replace(/\s/g,''); // 银行卡号
            var password  = password01; // 交易密码
            var newPhoneNumber = $("#id_newPhone_number").val(); // 新手机号
            var dynamicCode = $("#id_dynamicCode").val(); //验证码
            // 修改绑定卡
            var newCardNumber = $("#id_bindNewCard_number").val().replace(/\s/g,'');
            var newCardBindPhoneNumber = $('#id_bindNewCard_phoneNumber').val();
            var newCardPassword = newCardPassword01 ;// 本行卡交易密码
            // && (isBindBankCard == false || isBindBankCard == true && checkFormat_bankCardNumber(bankCardNumber))
            if (busType == '0' && checkFormat_idCardNumber(idCardNumber) && checkFormat_phoneNumber(newPhoneNumber) && checkFormat_dynamicNumber(dynamicCode)) {
                checkDynamicCode();
            }
            if ((busType == '1' && checkFormat_idCardNumber(idCardNumber) && checkFormat_dynamicNumber(dynamicCode)) ||
                (busType == '2' && checkFormat_idCardNumber(idCardNumber) && checkFormat_tradePassword(password) && checkFormat_dynamicNumber(dynamicCode)) ||
                (busType == '3' && checkFormat_bankCardNumber(newCardNumber) && ((newBanCardType == "2") || newBanCardType == "1" && checkFormat_tradePassword(newCardPassword)) &&checkFormat_phoneNumber(newCardBindPhoneNumber) && checkFormat_dynamicNumber(dynamicCode)) ){
                // 3 本行卡需要校验交易密码
                goToNextPage();
            }
            // 0校验动态验证码,其它后台校验
            function checkDynamicCode(){
                msgCodeEvent('提交验证码-身份认证交易页面','tradeCertification.html','2');
                var jsonObject = getJsonObject();
                jsonObject["method"] = "dbk.auth.shortMsgValidate";
                jsonObject["dymCode"] = dynamicCode;
                jsonObject["isRegFlag"] = "1";
                jsonObject["mobile"] = newPhoneNumber;
                var jsonObject2 =secondaryIndilling(jsonObject);
                jsonObject2["method"] = "dbk.auth.shortMsgValidate";
                $.ajax({
                    type: "POST",
                    url: address,
                    data: jsonObject2,
                    timeout: requestTimeOut,
                    dataType: "json",
                    contentType: "application/x-www-form-urlencoded;charset=utf-8",
                    beforeSend: function () {
                        showLoding();
                    },
                    success: function (data1) {
                        var data= secondaryde(data1);
                        if (data.retCode == "000000") {
                            goToNextPage();
                        } else {
                            tipsError(data.retMsg);
                            dissmissLoding();
                        }
                    },
                    error: function () {
                        requestFailTips();
                    },
                    complete: function () {

                    }
                });
            }
            function goToNextPage() {
                var jsonObject = getJsonObject();
                var methodString = undefined;
                //请求参数追加自定义参数
                if(busType == '0'){
                    methodString = "dbk.changeMobile.idConfirmValidate";
                }else {
                    methodString = "dbk.account.idConfirmValidate";
                }
                jsonObject["method"] = methodString;
                jsonObject["busType"] = busType;
                if (busType == '0') {
                    jsonObject["idNo"] = idCardNumber;
                    jsonObject["cardNo"] = bankCardNumber;
                    jsonObject["newMobileNo"] = newPhoneNumber;
                }
                if (busType == '1') {
                    // 重置交易密码:身份证号 银行卡 动态密码
                    jsonObject["idNo"] = idCardNumber;
                    // jsonObject["cardNo"] = bankCardNumber;
                    jsonObject["dymCode"] = dynamicCode;
                    jsonObject["oldMobileNo"] = getMobile();
                    jsonObject["userId"] = getMid();
                }
                if (busType == '2') {
                    // 交易业务认证:身份证号 交易密码 动态码
                    jsonObject["idNo"] = idCardNumber;
                    // jsonObject["tradePwd"] = getEncryptNum(true, password);
                    jsonObject["tradePwd"] =  password;
                    jsonObject["dymCode"] = dynamicCode;
                    jsonObject["oldMobileNo"] = getMobile();
                    jsonObject["userId"] = getMid();
                }
                if (busType == '3') {
                    // 更改绑定卡:新绑定卡/新绑定卡手机号/交易密码/动态验证码
                    jsonObject["busType"] = busType;
                    jsonObject["cardNo"] = newCardNumber;
                    jsonObject["newMobileNo"] = newCardBindPhoneNumber;
                    jsonObject["dymCode"] = dynamicCode;
                    // jsonObject["pwd"] = getEncryptNum(true,newCardPassword);
                    jsonObject["pwd"] = newCardPassword;
                    jsonObject["changeCardStep"] = newBanCardType; // 1本行卡 2他行卡
                    jsonObject["userId"] = getMid();
                }
                var jsonObject2 = secondaryIndilling(jsonObject);
                jsonObject2["method"] = methodString;
                $.ajax({
                    type: "POST",
                    url: address,
                    data: jsonObject2,
                    timeout: requestTimeOut,
                    dataType: "json",
                    contentType: "application/x-www-form-urlencoded;charset=utf-8",
                    beforeSend: function () {
                        showLoding();
                    },
                    success: function (data1) {
                        var data = secondaryde(data1);
                        if (data.retCode == "000000") {
                            var tradeCertifyDict = {};
                            tradeCertifyDict.busType = busType;
                            if(busType == "0"){
                                tradeCertifyDict.newPhoneNumber = newPhoneNumber;
                                tradeCertifyDict.userId = data.userId;
                            }else {
                                tradeCertifyDict.userId = getMid();
                                if (busType == "2"){
                                    tradeCertifyDict.backHtmlPage = resultDict.backHtmlPage;
                                }
                                if (busType == "3"){
                                    tradeCertifyDict.backHtmlPage = resultDict.backHtmlPage;
                                    tradeCertifyDict.newBankCard = newCardNumber;
                                }
                            }
                            window.location.href = "selectVerifyMode.html?txt$" + JSON.stringify(tradeCertifyDict);
                        } else {
                            tipsError(data.retMsg);
                        }
                    },
                    error: function () {
                        requestFailTips();
                    },
                    complete: function () {
                        dissmissLoding();
                    }
                });
            }
        });
        $(".input").bind('input propertychange',function(){
            if($("#id_tradeCertification_nextButton").hasClass('unclick')){
                if($(this).val() != '' ){
                    $("#id_tradeCertification_nextButton").removeClass('unclick');
                }
            }
        })
    },100);
});

$("#id_pass_word").click(function(){
    if(isTrigger){
        $("#id_trade_passWords").trigger('click');
    }
});

$("#id_newPhone_number").click(function(){
    if(isTrigger0){
        $("#id_bindNewCards").trigger('click');
    }
});



//点击交易密码
$('#id_trade_passWords').click(function () {
    $('#id_pass_word').val("");
    blurAnimation('#id_pass_word');
    flag = 1;
    if (/iphone|ipad|ipod/.test(ua)) {
        window.iOS.showKeyboard();
    } else if (/android/.test(ua)) {
        window.android.gointo();
    }
});
//新绑定卡交易密码
$('#id_bindNewCards').click(function () {
    $('#id_newPhone_number').val("");
    blurAnimation('#id_newPhone_number');
    flag = 2;
    if (/iphone|ipad|ipod/.test(ua)) {
        window.iOS.showKeyboard();
    } else if (/android/.test(ua)) {
        window.android.gointo();
    }
});

function getNative(pwd) {
    if (flag == 1) {
        password01  = pwd;
        $('#id_pass_word').val("******");
        focusAnimation('#id_pass_word');
        isTrigger = true ;
    } else {
        newCardPassword01 = pwd;
        $('#id_newPhone_number').val("******");
        focusAnimation('#id_newPhone_number');
        isTrigger0 = true ;
    }
}

isgoback(true);
function onBackPressed(){
    if (getIsLogined()) {
        if (busType == '0') {
            shClose01("");
        }
        if (busType == '1') {
            // window.location.href = "../../security_center/security_settings.html";
            window.location.href = "../../settingNew/accountSafe.html";
        }
        if (busType == '2') {

            window.history.go(-1);

        }else if(busType == '3'){
            window.location.href = backHtmlPage;
        } else {
            window.location.href = '../../settingNew/accountSafe.html';
        }
    }else{
        shClose01();
    }
}
function setUpUIView(strBusType){
    // 布局显示页面
    $(".tableContent").hide();
    $("#id_tradeCertification_IDNumber").hide(); //身份证号码
    $("#id_trade_bankCard").hide(); // 银行卡号
    $("#id_trade_passWord").hide(); // 交易密码
    $("#id_tradeCertification_changePhoneNumber").hide(); // 新手机号
    // 修改绑定卡
    $("#id_newBankCard").hide();
    $("#id_bindNewCard").hide();
    $("#id_newBankCard_phone").hide();
    $("#isShow_r").hide();
    var tradeTypeText = undefined;
    if (strBusType == '0'){
        tradeTypeText = "修改登录手机号";
        $("#id_tradeCertification_IDNumber").show();
        //$("#id_trade_bankCard").show();
        $("#id_tradeCertification_changePhoneNumber").show();
    }
    if (strBusType == '1'){
        tradeTypeText = "重置交易密码";
        $("#id_tradeCertification_IDNumber").show();
        // $("#id_trade_bankCard").show();
        $('#typeText').hide();
        $("#id_trade_bankCard").hide();
        $("#isShow_r").show();
        $('#typeTitle').text(tradeTypeText);
    }
    if (strBusType == '2'){
        tradeTypeText = "交易认证";
        $("#id_tradeCertification_IDNumber").show();
        $("#id_trade_passWord").show();
    }
    if (strBusType == "3"){
        // 更改绑定银行卡
        tradeTypeText =  "更换绑定银行卡";
        $("#id_newBankCard").show();
        $("#id_bindNewCard").show();
        $("#id_newBankCard_phone").show();
    }
    $('#id_tradeCertification_tradeType').val(tradeTypeText);
    $(".tableContent").show();
}
// 获取验证码
function getTestCode(phoneNumber){
    setTimeout(function(){
        msgCodeEvent('点击发送验证码-身份认证交易页面','tradeCertification.html','1');
        var jsonObject = getJsonObject();
        jsonObject["method"] = "dbk.auth.shortMsgLoginCheck";
        //请求参数追加自定义参数
        jsonObject["sendType"] = "0";
        jsonObject["queryEacctFlag"] = "0";
        jsonObject["mobile"] = phoneNumber;
        var jsonObject2 =secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.auth.shortMsgLoginCheck";
        $.ajax({
            type: "POST",
            url: address,
            data: jsonObject2,
            timeout: requestTimeOut,
            dataType: "json",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            beforeSend: function () {
                showLoding();
            },
            success: function (data1) {
                var data= secondaryde(data1);
                if (null != jsonObject.timeStamp) {
                    if (data != null) {
                        var retSign = getRetSign(data.retSign);
                        if (jsonObject.timeStamp == retSign) {
                            if (data.retCode == "000000") {
                                if (isBeta) {
                                    $("#id_dynamicCode").val(data.dymcode);
                                    focusAnimation('#id_dynamicCode');
                                }
                                tipsWell(data.retMsg);
                            }else {
                                tipsError(data.retMsg);
                            }
                        } else {
                            alert("校验签名失败1");
                        }
                    }
                } else {
                    alert("校验签名失败2");
                }
            },
            error: function () {
                requestFailTips();
            },
            complete: function () {
                dissmissLoding();
            }
        });
    },100);
}
