/**
 * Created by wangshengkui on 2017/5/19.
 */
var resetTradePasswordDataDict = {};
var passWord = '';
var pass_sure = '';
var isTrigger = false;
var isTrigger0 = false;
var flag = '0';
$(function(){
    setTimeout(function() {
        IsNeedClear();
        getTransferData("login_key");
        var Request = new Object();
        Request = GetRequest();
        var result = (Request["txt"]);
        var resultDict = JSON.parse(result);
        var busType = resultDict.busType;
        var userId = resultDict.userId;

        resetTradePasswordDataDict.busType = busType;


        $("#id_resetPass_Back").click(function(){
            resetTradePasswordBackAction();
        });
        function resetTradePasswordBackAction(){
            if (confirm("返回需要重新进行身份认证,确定是否返回")){
                window.location.href = "selectVerifyMode.html?txt$"+JSON.stringify(resetTradePasswordDataDict);
            }
        }
        $("#id_resetTradePass_nextButton").click(function(){
            var newPass = passWord;
            var newEnsurePass = pass_sure;
            if ((resultDict.aliveIsSuccess == "true") && checkFormat_tradePassword(newPass) && checkFormat_tradePassword(newEnsurePass)){
                if(newPass == ''){
                    tipsError("请输入密码");
                    return false;
                }
                if(newEnsurePass == ''){
                    tipsError("请再次输入密码");
                    return false;
                }
                if((newPass != newEnsurePass)){
                    tipsError("您输入的两次密码不一致，请重新输入");
                    return false;
                } else {
                    var jsonObject = getJsonObject();
                    //请求参数追加自定义参数
                    jsonObject["method"] = "dbk.account.changeTradPwd";
                    // jsonObject["tradePwdNew"] = getEncryptNum(true, newPass);
                    jsonObject["tradePwdNew"] = newPass;
                    jsonObject["transId"] = resultDict.transId;
                    var jsonObject2 =secondaryIndilling(jsonObject);
                    jsonObject2["method"] = "dbk.account.changeTradPwd";
                    $.ajax({
                        type: "POST",
                        url: address,
                        data: jsonObject2,
                        timeout: requestTimeOut,
                        dataType: "json",
                        contentType: "application/x-www-form-urlencoded;charset=utf-8",
                        beforeSend: function () {
                            showLoding();
                        },
                        success: function (data1) {
                            var data= secondaryde(data1);
                            if (data.retCode == "000000") {
                                 resetSuccess();
                            }else if (data.retCode == "Login9999") {
                                logout();
                                doKickOutAction("", "");
                            }else if (data.retCode == "Login9998") {
                                logout();
                                logout1("home");

                            }else {
                                tipsError(data.retMsg);
                            }
                        },
                        error: function () {
                            requestFailTips();
                        },
                        complete: function () {
                            dissmissLoding();
                        }
                    });


                }
            }
        });
        function resetSuccess(){
            resetTradePasswordDataDict.userId = userId;
            resetTradePasswordDataDict.aliveIsSuccess = resultDict.aliveIsSuccess;
            window.location.href = "aliveAuthenticationResult.html?txt$"+JSON.stringify(resetTradePasswordDataDict);
        }
    },100);

});

$("#id_resetTradePass_new").click(function(){
    if(isTrigger){
        $("#passWord1").trigger('click');
    }
});

$("#id_resetTradePass_ensureNew").click(function(){
    if(isTrigger0){
        $("#pass_sure1").trigger('click');
    }
});

$('#passWord1').click(function () {
    $('#id_resetTradePass_new').val("");
    blurAnimation('#id_resetTradePass_new');
    flag = 1;
    if (/iphone|ipad|ipod/.test(ua)) {
        window.iOS.showKeyboard();
    } else if (/android/.test(ua)) {
        window.android.gointo();
    }
});
$('#pass_sure1').click(function () {
    $('#id_resetTradePass_ensureNew').val("");
    blurAnimation('#id_resetTradePass_ensureNew');
    flag = 2;
    if (/iphone|ipad|ipod/.test(ua)) {
        window.iOS.showKeyboard();
    } else if (/android/.test(ua)) {
        window.android.gointo();
    }
});

//getNative方法必须是全局的
function getNative(pwd) {
    if (flag == 1) {
        passWord = pwd;
        $('#id_resetTradePass_new').val("******");
        focusAnimation('#id_resetTradePass_new');
        isTrigger = true ;
    } else {
        pass_sure = pwd;
        $('#id_resetTradePass_ensureNew').val("******");
        focusAnimation('#id_resetTradePass_ensureNew');
        isTrigger0 = true ;
    }
}
isgoback(true);
function onBackPressed(){
    if (confirm("返回需要重新进行身份认证,确定是否返回")){
        window.location.href = "selectVerifyMode.html?txt$"+JSON.stringify(resetTradePasswordDataDict);
    }
}