/**
 * Created by wangshengkui on 2017/5/16.
 */
// 点击开始调用活体认证
function clickStartAliveIdentification(valTypeStr,busTypeStr,userId,newAccountNumber){
    setTimeout(function(){
        var jsonObject1_alive = getJsonObject();
        var methodString = undefined;
        if(busTypeStr == "0"){
            methodString = "dbk.changeMobile.firstRequest";
        }else {
            methodString = "dbk.account.firstRequest";
        }
        if (/iphone|ipad|ipod/.test(ua)) {
            jsonObject1_alive["appType"] = "IOS"; // 客户端类型
            jsonObject1_alive["sdkVersion"] = window.iOS.clickOpenAliveIdentification(); // SDK版本号
        }
        if (busTypeStr == "0" || busTypeStr == "3"){
            jsonObject1_alive["accountNo"] = newAccountNumber;
        }
        jsonObject1_alive["userId"] = userId;
        jsonObject1_alive["valType"] = valTypeStr;// 验证方式 0:人脸  1:人工
        jsonObject1_alive["busType"] = busTypeStr;// 业务类型 0:修改登录手机号  1:重置该交易密码 2:交易认证业务 3:更改绑定卡 4:公安实名认证
        jsonObject1_alive["method"] = methodString;
        var jsonObject1_alive2 = secondaryIndilling(jsonObject1_alive);
        jsonObject1_alive2["method"] = methodString;
        $.ajax({
            type: "POST",
            url: address,
            dataType: "json",
            data: jsonObject1_alive2,
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            beforeSend: function () {
                showLoding();
            },
            success: function (data1) {
                var aliveData = secondaryde(data1);
                if (aliveData != null && aliveData.retCode == "000000") {
                    if (/iphone|ipad|ipod/.test(ua)) {
                        //alert("iphone");
                        var aliveDictionary = {};
                        aliveDictionary.userName = aliveData.userName;
                        aliveDictionary.userCard = aliveData.userCard;
                        aliveDictionary.stream_data = aliveData.stream_data;
                        aliveDictionary.random_data = aliveData.random_data;
                        aliveDictionary.work_flow = aliveData.work_flow;
                        aliveDictionary.transId = aliveData.transId;
                        window.iOS.goToAliveIdentificationWithDictionary(aliveDictionary);
                    } else if (/android/.test(ua)) {
                        //alert("android");
                        var aliveDictionary = {};
                        aliveDictionary.userName = aliveData.userName;
                        aliveDictionary.userCard = aliveData.userCard;
                        aliveDictionary.stream_data = aliveData.stream_data;
                        aliveDictionary.random_data = aliveData.random_data;
                        aliveDictionary.work_flow = aliveData.work_flow;
                        aliveDictionary.transId = aliveData.transId;
                        window.android.goToAliveIdentificationWithDictionary(JSON.stringify(aliveDictionary));
                    }
                }else {
                    alert(aliveData.retMsg);
                }
            },
            error: function () {
                requestFailTips();
            },
            complete: function () {
                dissmissLoding();
            }
        });
    },100);
}
/**
 * 调用相机
 * */
function clickOpenCamera(dictionary){
    if (/iphone|ipad|ipod/.test(ua)) {
            window.iOS.openCameraWithDataDictionary(dictionary);
    } else if (/android/.test(ua)) {

    }
}

// 检查手机号码
function checkFormat_phoneNumber(phoneNumber){
    if (phoneNumber == '') {
        alert("手机号码不能为空");
        return false;
    } else if (!(/^1[3|4|5|6|7|8|9]\d{9}$/.test(phoneNumber))) {
        alert("请输入正确的手机号码");
        return false;
    }else{
        return true;
    }
}
// 检查 银行卡卡号
function checkFormat_bankCardNumber(bankCardNumber){
    var reg = /^([1-9]{1})(\d{15}|\d{16}|\d{17}|\d{18})$/;
    if (bankCardNumber == "") {
        alert("银行卡号不能为空");
        return false;
    }
    //else if(bankCardNumber.length != 16 || bankCardNumber.length != 19){
    //    alert("银行卡号长度");
    //    return false;
    //}
    else if(reg.test(bankCardNumber) == false){
        alert("银行卡号格式不正确");
        return false;
    }else{
        return true;
    }
}
// 检查身份证号码
function checkFormat_idCardNumber(idCardNumber){
    var reg = /(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
    if (idCardNumber == "") {
        alert('请输入您的身份证号码');
        return false;
    } //校验长度，类型
    else if (reg.test(idCardNumber) === false) {
        alert('请输入正确的身份证号码');
        return false;
    } else if (checkIDCard_province(idCardNumber) === false) {
        alert('请输入正确的身份证号码');
        return false;
    } else if (checkIDCard_birthday(idCardNumber) === false) {
        //校验生日
        alert('请输入正确的身份证号码');
        return false;
    } else if (checkParity(idCardNumber) === false) {
        //检验位的检测
        alert('请输入正确的身份证号码');
        return false;
     }
    return true;
}
// 检查交易密码
function checkFormat_enterPassword(tradePassword){
    var pasReg = /^[0-9a-zA-Z]{6,16}$/;
    if (tradePassword == ''){
        alert("登录密码不能为空");
        return false;
    }else if(!pasReg.test(tradePassword)){
        alert("登录密码为6~16位数字或字母");
        return false;
    }else{
        return true;
    }
}

// 检查交易密码
function checkFormat_tradePassword(tradePassword){
    // var pasReg = /\d{6}/;
    if (tradePassword == ''){
        alert("交易密码不能为空");
        return false;
    }
        // else if(!pasReg.test(tradePassword)){
    //     alert("交易密码为6位数字");
    //     return false;
    // }
    else{
        return true;
    }
}
// 检查验证码
function checkFormat_dynamicNumber(dynamicNumber){
    var pasReg = /\d{6}/;
    if (dynamicNumber == ''){
        alert("动态验证码不能为空");
        return false;
    }else if(!pasReg.test(dynamicNumber)){
        alert("动态验证码为6位数字");
        return false;
    }else{
        return true;
    }
}

//身份证省的编码
var idCityCode = {
    11: "北京", 12: "天津", 13: "河北", 14: "山西", 15: "内蒙古",
    21: "辽宁", 22: "吉林", 23: "黑龙江", 31: "上海", 32: "江苏",
    33: "浙江", 34: "安徽", 35: "福建", 36: "江西", 37: "山东", 41: "河南",
    42: "湖北", 43: "湖南", 44: "广东", 45: "广西", 46: "海南", 50: "重庆",
    51: "四川", 52: "贵州", 53: "云南", 54: "西藏", 61: "陕西", 62: "甘肃",
    63: "青海", 64: "宁夏", 65: "新疆", 71: "台湾", 81: "香港", 82: "澳门", 91: "国外"
};
//取身份证前两位,校验省份
function checkIDCard_province(card) {
    var province = card.substr(0, 2);
    if (idCityCode[province] == undefined) {
        return false;
    }
    return true;
}

//检查生日是否正确
function checkIDCard_birthday(card) {
    var len = card.length;
    //身份证15位时，次序为省（3位）市（3位）年（2位）月（2位）日（2位）校验位（3位），皆为数字
    if (len == '15') {
        var re_fifteen = /^(\d{6})(\d{2})(\d{2})(\d{2})(\d{3})$/;
        var arr_data = card.match(re_fifteen);
        var year = arr_data[2];
        var month = arr_data[3];
        var day = arr_data[4];
        var birthday = new Date('19' + year + '/' + month + '/' + day);
        return verifyBirthday('19' + year, month, day, birthday);
    }
    //身份证18位时，次序为省（3位）市（3位）年（4位）月（2位）日（2位）校验位（4位），校验位末尾可能为X
    if (len == '18') {
        var re_eighteen = /^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X|x)$/;
        var arr_data = card.match(re_eighteen);
        var year = arr_data[2];
        var month = arr_data[3];
        var day = arr_data[4];
        var birthday = new Date(year + '/' + month + '/' + day);
        return verifyBirthday(year, month, day, birthday);
    }
    return false;
}


//校验日期
function verifyBirthday(year, month, day, birthday) {
    var now = new Date();
    var now_year = now.getFullYear();
    //年月日是否合理
    if (birthday.getFullYear() == year && (birthday.getMonth() + 1) == month && birthday.getDate() == day) {
        //判断年份的范围（3岁到100岁之间)
        var time = now_year - year;
        if (time >= 3 && time <= 100) {
            return true;
        }
        return false;
    }
    return false;
}

//校验位的检测
function checkParity(card) {
    //15位转18位
    card = changeFivteenToEighteen(card);
    if (card.length == 18) {
        card = card.split('');
        //∑(ai×Wi)(mod 11)
        //加权因子
        var factor = [ 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2 ];
        //校验位
        var parity = [ 1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2 ];
        var sum = 0;
        var ai = 0;
        var wi = 0;
        for (var i = 0; i < 17; i++) {
            ai = card[i];
            wi = factor[i];
            sum += ai * wi;
        }
        var last = parity[sum % 11];
        if(last == card[17].toUpperCase()){
            return true;
        }
    }
    return false;
}

//15位转18位身份证号
function changeFivteenToEighteen(card) {
    if (card.length == '15') {
        var arrInt = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
        var arrCh = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'];
        var cardTemp = 0, i;
        card = card.substr(0, 6) + '19' + card.substr(6, card.length - 6);
        for (i = 0; i < 17; i++) {
            cardTemp += card.substr(i, 1) * arrInt[i];
        }
        card += arrCh[cardTemp % 11];
        return card;
    }
    return card;
}
function formatBankCarNumber (BankNo){
    if (BankNo.value == "") return;
    var account = new String (BankNo.value);
    account = account.substring(0,30); /*帐号的总数, 包括空格在内 */
    if (account.match (".[0-9]{4}-[0-9]{4}-[0-9]{4}-[0-9]{7}") == null){
        /* 对照格式 */
        if (account.match (".[0-9]{4}-[0-9]{4}-[0-9]{4}-[0-9]{7}|" + ".[0-9]{4}-[0-9]{4}-[0-9]{4}-[0-9]{7}|" +
                ".[0-9]{4}-[0-9]{4}-[0-9]{4}-[0-9]{7}|" + ".[0-9]{4}-[0-9]{4}-[0-9]{4}-[0-9]{7}") == null){
            var accountNumeric = accountChar = "", i;
            for (i=0;i<account.length;i++){
                accountChar = account.substr (i,1);
                if (!isNaN (accountChar) && (accountChar != " ")) accountNumeric = accountNumeric + accountChar;
            }
            account = "";
            for (i=0;i<accountNumeric.length;i++){    /* 可将以下空格改为-,效果也不错 */
                if (i == 4) account = account + " "; /* 帐号第四位数后加空格 */
                if (i == 8) account = account + " "; /* 帐号第八位数后加空格 */
                if (i == 12) account = account + " ";/* 帐号第十二位后数后加空格 */
                if (i == 16) account = account + " ";/* 帐号第十六位后数后加空格 */
                account = account + accountNumeric.substr (i,1)
            }
        }
    } else {
        account = " " + account.substring (1,5) + " " + account.substring (6,10) + " " + account.substring (14,18) + "-" + account.substring(18,25);
    }
    if (account != BankNo.value) {
        BankNo.value = account;
    }
}
function ajax(opt) {
    opt = opt || {};
    opt.method = opt.method.toUpperCase() || 'POST';
    opt.url = opt.url || '';
    opt.async = opt.async || true;
    opt.data = opt.data || null;
    opt.success = opt.success || function() {};
    jsonpFunction = opt.success;
    var xmlHttp = null;
    if(XMLHttpRequest) {
        xmlHttp = new XMLHttpRequest();
    } else {
        xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
    }
    var params = [];
    for(var key in opt.data) {
        params.push(key + '=' + opt.data[key]);
    }
    xmlHttp.onreadystatechange = function() {
        if(xmlHttp.readyState == 4) {
            dissmissLoding();
            if(xmlHttp.status == 200) {
                eval(xmlHttp.responseText);
            } else {
                requestFailTips();
            }
        }
    };

    var postData = params.join('&');
    if(opt.method.toUpperCase() === 'POST') {
        xmlHttp.open(opt.method, opt.url, opt.async);
        xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded;charset=utf-8');
        xmlHttp.send(postData);
    } else if(opt.method.toUpperCase() === 'GET') {
        xmlHttp.open(opt.method, opt.url + '?' + postData, opt.async);
        xmlHttp.send(null);
    }
}
function checkBankCardType(bankCard){
    var oneselfBankCardArray = ["622279","622468","622892","621050","940021","620522","623183","438600","623185","621005","622172","622985","622987","622267","622278","621243"];
    var bankCardPrefix = bankCard.substr(0,6);
    var returnStr = "2"; // 1本行卡 2他行卡
    for (var i = 0;i<oneselfBankCardArray.length ;i++){
        var item = oneselfBankCardArray[i];
        if (item == bankCardPrefix){
            returnStr = '1';
            break;
        }
    }
    return returnStr;
}
