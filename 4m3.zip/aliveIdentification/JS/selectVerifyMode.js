/**
 * Created by wangshengkui on 2017/5/15.
 */
var dataSelectModeDict = {};
var strUserId = undefined;
var resultBusType ;
var cardNo ;


    $(function(){
    setCheckPage("false");
    setTimeout(function() {
        IsNeedClear();
        getTransferData("login_key");
        var isInManualAudit = undefined; // 记录是否正在进行人工审核
        var Request = new Object();
        Request = GetRequest();
        var result = (Request["txt"]);
        var resultSelectDict = JSON.parse(result);
        resultBusType = resultSelectDict.busType; // 业务类型   返回4
        strUserId = resultSelectDict.userId;
        dataSelectModeDict.userId = resultSelectDict.userId;
        dataSelectModeDict.busType = resultBusType;
        if (resultBusType == "0"){
            dataSelectModeDict.newPhoneNumber = resultSelectDict.newPhoneNumber;
            cardNo=resultSelectDict.newPhoneNumber;

        }
        if(resultBusType == '2'){
            dataSelectModeDict.backHtmlPage = resultSelectDict.backHtmlPage;
        }
        if (resultBusType == "3"){
            dataSelectModeDict.backHtmlPage = resultSelectDict.backHtmlPage;
            dataSelectModeDict.newBankCard = resultSelectDict.newBankCard;
            cardNo=resultSelectDict.newBankCard;
        }
        setTimeout(function(){
            var jsonObject = getJsonObject();
            jsonObject["busType"] = resultBusType;
            jsonObject["userId"] = strUserId;
            var methodString = undefined;
            if(resultBusType == '0'){
                methodString = "dbk.changeMobile.getIdConfirmSwitch";
            }else {
                methodString = "dbk.account.getIdConfirmSwitch";
            }
            jsonObject["method"] = methodString;

            var jsonObject2 = secondaryIndilling(jsonObject);
            jsonObject2["method"] = methodString;
            $.ajax({
                type: "POST",
                url: address,
                dataType: "json",
                data: jsonObject2,
                contentType: "application/x-www-form-urlencoded;charset=utf-8",
                beforeSend: function () {
                    showLoding();
                },
                success: function (data) {
                    dissmissLoding();
                    var selectData = secondaryde(data);
                    if (selectData != null && selectData.retCode == "000000") {
                        isInManualAudit = selectData.isValidate; // 01审核中,02未审核
                        var isSwitchAlive = undefined;
                        var isSwitchManual = undefined;
                        var isSubSwitchManual = undefined;
                        if (resultBusType == '0'){
                            // 修改登录手机号
                            isSwitchAlive = selectData.ID_Confirm_SW_Change_Mobile_Face_Switch;
                            isSwitchManual = selectData.ID_Confirm_SW_Change_Mobile_Labour_Switch;
                            isSubSwitchManual = selectData.ID_Confirm_SW_Change_Mobile_Face_Sub_Switch;
                        }else if(resultBusType == '1'){
                            // 重置该交易密码
                            isSwitchAlive = selectData.ID_Confirm_SW_Change_Psd_Face_Switch;
                            isSwitchManual = selectData.ID_Confirm_SW_Change_Psd_Labour_Switch;
                            isSubSwitchManual = selectData.ID_Confirm_SW_Change_Psd_Face_Sub_Switch;
                        }else if(resultBusType == '2'){
                            // 交易认证业务
                            isSwitchAlive = selectData.ID_Confirm_SW_Trade_Face_Switch;
                            isSwitchManual = selectData.ID_Confirm_SW_Trade_Labour_Switch;
                            isSubSwitchManual = selectData.ID_Confirm_SW_Trade_Face_Sub_Switch;
                        }else if(resultBusType == '3'){
                            // 更改绑定卡
                            isSwitchAlive = selectData.ID_Confirm_SW_Change_Card_Face_Switch;
                            isSwitchManual = selectData.ID_Confirm_SW_Change_Card_Labour_Switch;
                            isSubSwitchManual = selectData.ID_Confirm_SW_Change_Card_Face_Sub_Switch;
                        }else if(resultBusType == '4'){
                            // 公安实名认证
                            isSwitchAlive = selectData.ID_Confirm_SW_Police_Confirm_Face_Switch;
                            isSwitchManual = selectData.ID_Confirm_SW_Police_Confirm_Labour_Switch;
                            isSubSwitchManual = selectData.ID_Confirm_SW_Police_Confirm_Sub_Switch ;
                        }
                        setUpLi(isSwitchAlive,isSwitchManual,isSubSwitchManual);
                    }else if (selectData.retCode == "Login9999") {
                        logout();
                        doKickOutAction("", "");
                    }else if (selectData.retCode == "Login9998") {
                        logout();
                        logout1("home");

                    }else {
                        tipsError(selectData.retMsg);
                    }
                },
                error: function () {
                    requestFailTips();
                },
                complete: function () {
                    dissmissLoding();
                }
            });
        },100);
        // 点击选择页面的返回按钮
        // $('#id_selectVerify_backButton').click(function(e){
        //     e.preventDefault();
        //     if (resultBusType === "4"){
        //         // window.location.href = '../../openAccent/bang-oneselfbank1.html';
        //         window.location.href = '../../settingNew/idCheck.html';
        //     }
        //    else if(confirm("返回需要重新输入信息,确定是否返回")){
        //         window.location.href = "tradeCertification.html?txt$"+JSON.stringify(dataSelectModeDict);
        //     }
        // });
        // 去人工
        $("#manualButton").click(function(){
            if (isInManualAudit == '01'){
                tipsError("正在人工审核中，预计需要两个工作日");
                return false;
            }else {
                window.location.href = "manualAuditLead.html?txt$"+JSON.stringify(dataSelectModeDict);
            }
        });
        // 调用活体
        $("#aliveButton").click(function(){
            if (isInManualAudit === '01'){
                tipsError("正在人工审核中，预计需要两个工作日");
                return false;
            }else {
                var newNumber = undefined;
                if (resultBusType === "0"){
                    newNumber = dataSelectModeDict.newPhoneNumber;
                }
                if (resultBusType === "3"){
                    newNumber = dataSelectModeDict.newBankCard;
                }
                // clickStartAliveIdentification('0',resultBusType,strUserId,newNumber);
                /**
                 * 人脸识别   IOS 调用宜签人脸  android 调用商汤人脸
                 */
                if (/iphone|ipad|ipod/.test(ua)) {
                    clickStartAliveIdentification('0',resultBusType,strUserId,newNumber);
                } else if (/android/.test(ua)) {
                    window.android.goToSTSilentLiveness();
                }
            }
        });
    },100);
});
function setUpLi(aliveSwitch,manualSwitch,subManualSwitch){

    if (aliveSwitch == "0" && manualSwitch == "0"){
        tipsError("功能正在维护中，请联系我行客服95594");
        setTimeout(function () {
            // shClose('');
            window.location.href = '../../featuredNew/featuredIndex.html';
        }, 3000);
        return;
    }else {

    }
    // 0关闭;1打开
    // 活体
    if (aliveSwitch == '0'){
        $("#aliveButton").hide();
    }else{
        $("#aliveButton").show();
        if (manualSwitch == '0'){
            $("#aliveButton").removeClass("partitionBottomLine_wsk");
        }
    }
    // 人工
    if (manualSwitch == '0'){
        $("#manualButton").hide();
    }else{
        $("#manualButton").show();
    }
    $('#id_select_mode_ul').show();
    // 人工 子开关
    if (subManualSwitch == '0'){
        dataSelectModeDict.isShowSubAuditButton = "false"; //是否显示人工审核
    }else{
        dataSelectModeDict.isShowSubAuditButton = "true"; //是否显示人工审核
    }
}
isgoback(true);
function onBackPressed(){
    isgoback(true);
    if (canGoBack) {
        if (resultBusType === "4") {
            window.location.href = '../../settingNew/idCheck.html';
        }
        else if (confirm("返回需要重新输入信息,确定是否返回")) {
            window.location.href = "tradeCertification.html?txt$" + JSON.stringify(dataSelectModeDict);
        }
    } else {
        return;
    }
}
// 人脸识别_采集成功_点击下一步
function clickAliveIdentificationNextButton(aliveData){
    setTimeout(function(){
        var jsonObject2_alive = getJsonObject();
        var methodString = undefined;
        if(dataSelectModeDict.busType == "0"){
            methodString = "dbk.changeMobile.secondRequest";
        }else {
            methodString = "dbk.account.secondRequest";
        }
        jsonObject2_alive["userId"] = strUserId;
        if (/iphone|ipad|ipod/.test(ua)) {
            jsonObject2_alive["reqData"] = aliveData.data;
            jsonObject2_alive["reqHash"] = aliveData.hash;
            jsonObject2_alive["reqExtra"] = aliveData.extra;
            jsonObject2_alive["transId"] = aliveData.transId;
        } else if (/android/.test(ua)) {

            jsonObject2_alive["reqData"] = JSON.parse(aliveData).data;
            jsonObject2_alive["reqHash"] = JSON.parse(aliveData).hash;
            jsonObject2_alive["reqExtra"] = JSON.parse(aliveData).extra;
            jsonObject2_alive["transId"] = JSON.parse(aliveData).transId;
        }
        jsonObject2_alive["method"] = methodString;
        var jsonObject2_alive2 = secondaryIndilling(jsonObject2_alive);
        jsonObject2_alive2["method"] = methodString;
        jsonObject2_alive2.securityData = jsonObject2_alive2.securityData.replace(/\+/g, "%2B");
        jsonObject2_alive2.securityData = jsonObject2_alive2.securityData.replace(/\&/g, "%26");
        jsonObject2_alive2.digitalEnvelope = jsonObject2_alive2.digitalEnvelope.replace(/\+/g, "%2B");
        jsonObject2_alive2.digitalEnvelope = jsonObject2_alive2.digitalEnvelope.replace(/\&/g, "%26");
        jsonObject2_alive2.dataSummary = jsonObject2_alive2.dataSummary.replace(/\+/g, "%2B");
        jsonObject2_alive2.dataSummary = jsonObject2_alive2.dataSummary.replace(/\&/g, "%26");
        setCheckPage("true");
        showLoding();
        ajax({
            method: "POST",
            url: address.replace("=?","=jsonpFunction"),
            data: jsonObject2_alive2,
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            timeout: requestTimeOut,
            dataType: "json",
            success: function(data1) {
                dissmissLoding();
                var aliveData = secondaryde(data1);
                if (aliveData != null && aliveData.retCode == "000000") {
                    if (isBeta){
                        if (aliveData.resConfirm == "true"){
                            aliveSuccessNextStop(dataSelectModeDict.busType,aliveData.transId);
                        }else {
                            aliveSuccessNextStop(dataSelectModeDict.busType,aliveData.transId);
                            //dataSelectModeDict.aliveIsSuccess = "false"; // 活体认证结果
                            //window.location.href = "aliveAuthenticationResult.html?txt$"+JSON.stringify(dataSelectModeDict);
                        }
                    }else {
                        if (aliveData.resConfirm == "true"){
                            aliveSuccessNextStop(dataSelectModeDict.busType,aliveData.transId);
                        }else {
                            dataSelectModeDict.aliveIsSuccess = "false"; // 活体认证结果
                            window.location.href = "aliveAuthenticationResult.html?txt$"+JSON.stringify(dataSelectModeDict);
                        }
                    }

                }else {
                    setCheckPage("false");
                    tipsError(aliveData.retMsg);
                }
            },
            error: function () {
                setCheckPage("false");
                requestFailTips();
            }
        });
    },100);
}

function aliveSuccessNextStop(busTypeNumber,transId){
    if (busTypeNumber == "0"){
        // 修改登录手机号
        var jsonObject = getJsonObject();
        //请求参数追加自定义参数
        jsonObject["method"] = "dbk.changeMobile.changeMobileNo";
        jsonObject["newMobileNo"] = dataSelectModeDict.newPhoneNumber;//手机号
        jsonObject["userId"] = strUserId;
        var jsonObject2 = secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.changeMobile.changeMobileNo";
        $.ajax({
            type: "POST",
            url: address,
            data: jsonObject2,
            timeout: requestTimeOut,
            dataType: "json",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            beforeSend: function () {
                showLoding();
            },
            success: function (data1) {
                var data = secondaryde(data1);
                if (data.retCode == "000000") {
                    dataSelectModeDict.aliveIsSuccess = "true"; // 活体认证结果
                    window.location.href = "aliveAuthenticationResult.html?txt$"+JSON.stringify(dataSelectModeDict);
                }else if (data.retCode == "Login9999") {
                    logout();
                    doKickOutAction("", "");
                }else if (data.retCode == "Login9998") {
                    logout();
                    logout1("home");

                }else{
                    setCheckPage("false");
                    tipsError(data.retMsg);
                }
            },
            error: function () {
                requestFailTips();
            },
            complete: function () {
                dissmissLoding();
            }
        });
    }
    if (busTypeNumber == "1"){
        // 重置交易密码页面
        dataSelectModeDict.transId = transId;
        dataSelectModeDict.aliveIsSuccess = "true"; // 活体认证结果
        window.location.href = "resetTradePassword.html?txt$"+JSON.stringify(dataSelectModeDict);
        dissmissLoding();
    }
    if (busTypeNumber == "2"){
        var jsonObject = getJsonObject();
        //请求参数追加自定义参数
        jsonObject["method"] = "dbk.account.dealTDLimit";
        jsonObject["userId"] = strUserId;
        var jsonObject2 =secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.account.dealTDLimit";
        $.ajax({
            type: "POST",
            url: address,
            data: jsonObject2,
            timeout: requestTimeOut,
            dataType: "json",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            beforeSend: function () {
                showLoding();
            },
            success: function (data1) {
                var data= secondaryde(data1);
                if (data.retCode == "000000") {
                    dataSelectModeDict.aliveIsSuccess = "true"; // 活体认证结果
                    window.location.href = "aliveAuthenticationResult.html?txt$"+JSON.stringify(dataSelectModeDict);
                }else if (data.retCode == "Login9999") {
                    logout();
                    doKickOutAction("", "");
                }else if (data.retCode == "Login9998") {
                    logout();
                    logout1("home");

                }else {
                    setCheckPage("false");
                    tipsError(data.retMsg);
                }
            },
            error: function () {
                requestFailTips();
            },
            complete: function () {
                dissmissLoding();
            }
        });
    }
    if (busTypeNumber == "4"){
        dataSelectModeDict.aliveIsSuccess = "true"; // 活体认证结果
        window.location.href = "aliveAuthenticationResult.html?txt$"+JSON.stringify(dataSelectModeDict);
        dissmissLoding();
    }
}

var canGoBack = true;
function setCheckPage(isShow){
    if (isShow == "true"){
        $('#id_select_mode_ul').hide();
        canGoBack = false;
        // $(".more_header").hide();
        $('#id_selectVerify_backButton').hide();
        $("#id_p_check").show();
        return;
    }
    if (isShow == 'false'){
        $('#id_select_mode_ul').show();
        canGoBack = true;
        // $(".more_header").show();
        // 点击选择页面的返回按钮
        $('#id_selectVerify_backButton').show();
        $('#id_selectVerify_backButton').click(function (e) {
            e.preventDefault();
            if (resultBusType === "4") {
                // window.location.href = '../../openAccent/bang-oneselfbank1.html';
                window.location.href = '../../settingNew/idCheck.html';
            }
            else if (confirm("返回需要重新输入信息,确定是否返回")) {
                window.location.href = "tradeCertification.html?txt$" + JSON.stringify(dataSelectModeDict);
            }
        });
        $("#id_p_check").hide();
    }
}
// 商汤人脸识别回调
function stLivenessCallback(faceBase64) {
    uploadImg(faceBase64);
}

function uploadImg(faceData) {
    var imageData = [];
    var img = {};
    img["fileType"] = "P0003";
    img["ImageName"] = MathRand() + ".JPG";
    img["Image"] = faceData;
    img["businessType"] = "BS001";
    imageData[0] = img;

    var methodSt = undefined;
    if(resultBusType == '0'){
        methodSt = "dbk.idConfirmWithoutLogin.checkIdentityConfirm";
    }else {
        methodSt = "dbk.idConfirm.checkIdentityConfirm";
    }

    var jsonObject = getJsonObject();
    jsonObject["ImageList"] = JSON.stringify(imageData);
    jsonObject["userId"] = strUserId;
    jsonObject["accountNo"] = cardNo;
    jsonObject["valType"] = "0";// 验证方式 0:人脸  1:人工
    jsonObject["busType"] = resultBusType;// 业务类型 0:修改登录手机号  1:重置该交易密码 2:4 3:更改绑定卡 6:自营贷 7:扫码
    jsonObject["method"] = methodSt;
    if (/iphone|ipad|ipod/.test(ua)) {
        jsonObject["appType"] = "IOS"; // 客户端类型
    } else if (/android/.test(ua)) {
        jsonObject["appType"] = "ST"; // 客户端类型
    }
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = methodSt;
    jsonObject2.securityData = jsonObject2.securityData.replace(/\+/g, "%2B");
    jsonObject2.securityData = jsonObject2.securityData.replace(/\&/g, "%26");
    jsonObject2.digitalEnvelope = jsonObject2.digitalEnvelope.replace(/\+/g, "%2B");
    jsonObject2.digitalEnvelope = jsonObject2.digitalEnvelope.replace(/\&/g, "%26");
    jsonObject2.dataSummary = jsonObject2.dataSummary.replace(/\+/g, "%2B");
    jsonObject2.dataSummary = jsonObject2.dataSummary.replace(/\&/g, "%26");
    setCheckPage("true");

    ajax({
        method: "POST",
        url: address.replace("=?", "=jsonpFunction"),
        data: jsonObject2,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        timeout: requestTimeOut,
        dataType: "json",
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var aliveData = secondaryde(data1);
            if (aliveData != null && aliveData.retCode == "000000") {
                if (isBeta){
                    aliveSuccessNextStop(dataSelectModeDict.busType,aliveData.transId);//更换绑定卡（有资产） dataSelectModeDict.busType 返回值 3
                }else {
                    if (aliveData.resConfirm == "true"){
                        aliveSuccessNextStop(dataSelectModeDict.busType,aliveData.transId);
                    }else {
                        dataSelectModeDict.aliveIsSuccess = "false"; // 活体认证结果
                        window.location.href = "aliveAuthenticationResult.html?txt$"+JSON.stringify(dataSelectModeDict);
                    }
                }

            }else {
                setCheckPage("false");
                tipsError(aliveData.retMsg);
            }
        },
        error: function () {
            setCheckPage("false");
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}
