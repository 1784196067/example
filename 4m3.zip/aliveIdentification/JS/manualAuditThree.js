/**
 * Created by wangshengkui on 2017/5/15.
 */
var busType = undefined;
var backHtmlPage = undefined;
$(function() {
    setTimeout(function() {
        IsNeedClear();
        getTransferData("login_key");
        var Request = new Object();
        Request = GetRequest();
        var result = (Request["txt"]);
        var resultDict = JSON.parse(result);
        var tailsNumber = resultDict.phoneTailsNumber;
        var strUserId = resultDict.userId;
        busType = resultDict.busType;
        if (busType == '2' || busType == '3'){
            backHtmlPage = resultDict.backHtmlPage;
        }
        var tipsMessage = '您的信息已提交，请等待系统审核，审核结果预计2个工作日内会以短信通知您，短信发送至您尾号为'+tailsNumber+'的手机号，请注意查收。';
        $('#tailNumberTipsMessage').text(tipsMessage);

        var manualThreeDataDict = {};
        manualThreeDataDict.busType = busType;
        manualThreeDataDict.userId = strUserId;
        // 返回按钮
        //$('#id_audit_three_back').click(function(){
        //    window.location.href = 'selectVerifyMode.html?txt$'+JSON.stringify(manualThreeDataDict);
        //});
        // 完成按钮
        $('#id_audit_three_finishButton').click(function(){
            if (busType == "0"){
                shClose();
            }
            if (busType == "4"){
                shClose();
            }
            if (busType == "2" || busType == '3') {
                // 交易认证
                window.location.href = backHtmlPage;
            }
        });
    },100);
});
isgoback(true);
function onBackPressed(){
    if (busType == "4"){
        shClose();
    }
    if (busType == "0"){
        shClose();
    }
    if (busType == "2" || busType == '3') {
        // 交易认证
        window.location.href = backHtmlPage;
    }
}