/**
 * Created by wangshengkui on 2017/5/15.
 */
var manualAuditOneImageArray = []; // 身份证正反面图片数组
var dataOneDic ={};
$(function(){
    setTimeout(function() {
        IsNeedClear();
        getTransferData("login_key");
        var Request = new Object();
        Request = GetRequest();
        var result = (Request["txt"]);
        var resultOneDict = JSON.parse(result);
        var busType = resultOneDict.busType;
        var transId = resultOneDict.transId;
        //var idCardNumber = resultOneDict.idCardNumber;
        var strUserId = resultOneDict.userId;
        dataOneDic.busType = busType;
        dataOneDic.transId = transId;
        dataOneDic.userId = strUserId;
        if (busType == "0"){
            dataOneDic.newPhoneNumber = resultOneDict.newPhoneNumber;
        }
        if (busType == "2"){
            dataOneDic.backHtmlPage = resultOneDict.backHtmlPage;
        }
        if (busType == "3"){
            dataOneDic.backHtmlPage = resultOneDict.backHtmlPage;
            dataOneDic.newBankCard = resultOneDict.newBankCard;
        }
        if (busType == "3"){
            $('#id_audit_table_span').text('上传相关信息');
        }else{
            $('#id_audit_table_span').text('上传手持身份证');
        }
        // 返回
        $('#id_audit_one_back').click(function(){
            if (confirm("返回需要重新进行人脸采集,确认是否返回")){
                window.location.href = "manualAuditLead.html?txt$"+JSON.stringify(dataOneDic);
            }
        });
        // 下一步
        $('#id_audit_one_nextButton').click(function(){
            if (manualAuditOneImageArray.length == 2){
                //var ocrIDCardNumber =  manualAuditOneImageArray[0].idNumber;
                //dataOneDic.idCardNumber = idCardNumber;
                //if(idCardNumber == ocrIDCardNumber){
                uploadManualAuditImageData(manualAuditOneImageArray,transId,busType,strUserId);
                //}else {
                //    alert("经识别，身份证信息不匹配，请您重新验证。");
                //}
            }else {
                alert("请上传完整的身份证照片信息");
            }
        });

        // 点击获取身份证 头像面
        $("#id_audit_firstImg").click(function() {
            if(/iphone|ipad|ipod/.test(ua)) {
                window.iOS.goToOCRwithStatusBusinessTypeEacctNo("1",busType,strUserId);
            } else if(/android/.test(ua)) {
                window.android.gointoOCR();
            }
        });
        // 点击获取身份证 国徽面
        $("#id_audit_nextImg").click(function() {
            if(/iphone|ipad|ipod/.test(ua)) {
                window.iOS.goToOCRwithStatusBusinessTypeEacctNo("0",busType,strUserId);
            } else if(/android/.test(ua)) {
                window.android.gointoOCR1();
            }
        });
    },100);

});
isgoback(true);
function onBackPressed(){
    if (confirm("返回需要重新进行人脸采集,确认是否返回")){
        window.location.href = "manualAuditLead.html?txt$"+JSON.stringify(dataOneDic);
    }
}
// IOS 获取 头像图片
function getfirstImg(ocrImageData) {
    if(/iphone|ipad|ipod/.test(ua)) {
        if(ocrImageData.fileType == "P0001") {
            $("#id_audit_firstImg").attr("src", ocrImageData.imagePath);
            ocrImageData["businessType"] = "BS002";
            for (var i = 0;i<manualAuditOneImageArray.length;i++){
                var imageItem = manualAuditOneImageArray[i];
                if (imageItem.fileType == "P0001"){
                    manualAuditOneImageArray.splice(i,1);
                    break;
                }
            }
            manualAuditOneImageArray.push(ocrImageData);
        } else {
            alert("请扫描识别身份证头像面");
        }
    }
}

// IOS 获取国徽面
function getnextImg(ocrImageData) {
    if(/iphone|ipad|ipod/.test(ua)) {
        if (ocrImageData.fileType == "P0002") {
            $("#id_audit_nextImg").attr("src", ocrImageData.imagePath);
            ocrImageData["businessType"] = "BS002";
            for (var i = 0;i<manualAuditOneImageArray.length;i++){
                var imageItem = manualAuditOneImageArray[i];
                if (imageItem.fileType == "P0002"){
                    manualAuditOneImageArray.splice(i,1);
                    break;
                }
            }
            manualAuditOneImageArray.push(ocrImageData);
        } else {
            alert("请扫描识别身份证国徽面");
        }
    }
}

function getfirstImg1(imagepath) {
    if (/android/.test(ua)) {
        $("#id_audit_firstImg").attr("src", "data:image/png;base64," + imagepath);
        var ima = {};
        ima["fileType"] = "P0001";
        ima["ImageName"] = MathRand() + ".JPG";
        ima["Image"] = imagepath;
        ima["businessType"] = "BS002";
        for (var i = 0;i<manualAuditOneImageArray.length;i++){
            var imageItem = manualAuditOneImageArray[i];
            if (imageItem.fileType == "P0001"){
                manualAuditOneImageArray.splice(i,1);
                break;
            }
        }
        manualAuditOneImageArray.push(ima);
    }
}
function getnextImg1(imagepath) {
    if (/android/.test(ua)) {
        $("#id_audit_nextImg").attr("src", "data:image/png;base64," + imagepath);
        var ima = {};
        ima["fileType"] = "P0002";
        ima["ImageName"] = MathRand() + ".JPG";
        ima["Image"] = imagepath;
        ima["businessType"] = "BS002";
        for (var i = 0;i<manualAuditOneImageArray.length;i++){
            var imageItem = manualAuditOneImageArray[i];
            if (imageItem.fileType == "P0002"){
                manualAuditOneImageArray.splice(i,1);
                break;
            }
        }
        manualAuditOneImageArray.push(ima);
    }
}
function MathRand() {
    var Num="";
    for(var i=0;i<6;i++) {
        Num+=Math.floor(Math.random()*10);
    }
    return Num;
}
function uploadManualAuditImageData(imageList,transId,busType,userId){
    setTimeout(function(){
        var jsonObject = getJsonObject();
        var methodString = undefined;
        if(busType == "0"){
            methodString = "dbk.changeMobile.uploadIdConfirmImg";
        }else {
            methodString = "dbk.account.uploadIdConfirmImg";
        }
        jsonObject["userId"] = userId;
        jsonObject['transId'] = transId;
        jsonObject["busType"] = busType;
        jsonObject["ImageList"] = imageList;
        jsonObject["method"] = methodString;
        var jsonObject2 = secondaryIndilling(jsonObject);
        jsonObject2["method"] = methodString;
        jsonObject2.securityData = jsonObject2.securityData.replace(/\+/g, "%2B");
        jsonObject2.securityData = jsonObject2.securityData.replace(/\&/g, "%26");
        jsonObject2.digitalEnvelope = jsonObject2.digitalEnvelope.replace(/\+/g, "%2B");
        jsonObject2.digitalEnvelope = jsonObject2.digitalEnvelope.replace(/\&/g, "%26");
        jsonObject2.dataSummary = jsonObject2.dataSummary.replace(/\+/g, "%2B");
        jsonObject2.dataSummary = jsonObject2.dataSummary.replace(/\&/g, "%26");
        showLoding();
        ajax({
            method: "POST",
            url: address.replace("=?","=jsonpFunction"),
            data: jsonObject2,
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            timeout: requestTimeOut,
            dataType: "json",
            success: function(data1) {
                var data = secondaryde(data1);
                if(data.retCode == "000000") {
                    alert("身份证信息上传成功");
                    window.location.href = "manualAuditTwoPage." +
                        "html?txt$" + JSON.stringify(dataOneDic);
                } else {
                    // alert(alert.retMsg);
                    alert(data.retMsg);
                }
            },
            error: function () {
                requestFailTips();
            },
            complete: function () {
                dissmissLoding();
            }
        });
    },100);
}
