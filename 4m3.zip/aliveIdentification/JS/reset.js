/*
* 计算1rem对应的高度，为后边的动画的样式数值设置实现奠定基础*/
var str = '<div style="height:1rem;visibility: hidden;" id="computeHeight"></div>';
$('body').append(str);
var h = $('#computeHeight').height();
$('#computeHeight').remove();
var inputs = $('input.input');
var l = inputs.length;

function inputError(sel) {
    $(sel).closest('ul').addClass('errorInput');
    $(sel).closest('div').addClass('errorInput');
}

function inputFinish(sel) {
    $(sel).closest('ul').removeClass('errorInput');
    $(sel).closest('div').removeClass('errorInput');
}
/*
* 初始化页面样式，针对回退时输入框有值时的样式，防止文字重叠*/
for (var i = 0; i < l; i++) {
    var label = $('label[for=' + $(inputs[i]).attr('id') + ']');
    if (label.length == 0) {
        label = $(inputs[i]).closest('li').find('p:first-of-type');
    }
    if (!$(inputs[i]).hasClass('readonly')) {
        if ($(inputs[i]).val()) {
            label.css({
                'top': '0px',
                'font-size': (h * 0.12) + 'px',
                'left': '0px'
            }).text(label.attr('data-focus'));
        } else {
            /*针对金额输入框动画实现的效果*/
            if (label.attr('data-blur') && label.next().find('span:first-of-type').hasClass('currentToken')) {
                label.css({
                    'top': (h * 0.266) + 'px',
                    'font-size': (h * 0.16) + 'px',
                    'left': (h * 0.2) + 'px'
                }).text(label.attr('data-blur'));
            } else {
                label.css({
                    'top': (h * 0.266) + 'px',
                    'font-size': (h * 0.16) + 'px',
                    'left': '0px'
                }).text(label.attr('data-blur'));
            }

        }
    }
}
/*
* 针对获取验证码时输入验证码的输入框聚焦*/
/*$('.revise p .input:nth-of-type(2)').click(function () {
    var ua = navigator.userAgent.toLowerCase();
    if (/iphone|ipad|ipod/.test(ua)) {
        return;
    }
    $(this).closest('div').find('.input:nth-of-type(1)').trigger('focus');
});*/

/*
* 手动调用判断某个选择器下的class=input的输入框有无值时的动画实现，有值时为聚焦时的状态，无值就是失焦时的状态*/
function hasValueClass(sel) {
    // setTimeout(function () {
    var inputs = $(sel + ' input.input');
    var l = inputs.length;
    for (var i = 0; i < l; i++) {
        var label = $('label[for=' + $(inputs[i]).attr('id') + ']');
        if (label.length == 0) {
            label = $(inputs[i]).closest('li').find('p:first-of-type');
        }
        if ($(inputs[i]).val()) {
            /*针对金额输入框动画实现的效果*/
                label.css({
                    'top': '0px',
                    'font-size': (h * 0.12) + 'px',
                    'left': '0px'
                }).text(label.attr('data-focus'));
        } else {
            /*针对金额输入框动画实现的效果*/
            if (label.attr('data-blur') && label.next().find('span:first-of-type').hasClass('currentToken')) {
                label.css({
                    'top': (h * 0.266) + 'px',
                    'font-size': (h * 0.16) + 'px',
                    'left': (h * 0.2) + 'px'
                }).text(label.attr('data-blur'));
            } else {
                label.css({
                    'top': (h * 0.266) + 'px',
                    'font-size': (h * 0.16) + 'px',
                    'left': '0px'
                }).text(label.attr('data-blur'));
            }

        }
    }
    // }, 200);
}

/*
* 某个/些元素聚焦动画实现*/
function focusAnimation(sel) {
    var p = $(sel).closest('li').find('p:first-of-type');
    if (p.length == 0) {
        p = $(sel).closest('div').find('label');
    }
    p.css({
        'top': '0px',
        'font-size': (h * 0.12) + 'px',
        'left': '0px'
    }).text(p.attr('data-focus'));
}

/*
* 某个/些元素失焦动画实现*/
function blurAnimation(sel) {
    var p = $(sel).closest('li').find('p:first-of-type');
    if (p.length == 0) {
        p = $(sel).closest('div').find('label');
    }
    if (p.attr('data-focus') && p.next().find('span:first-of-type').hasClass('currentToken')) {
        p.css({
            'top': (h * 0.266) + 'px',
            'font-size': (h * 0.16) + 'px',
            'left': (h * 0.2) + 'px'
        }).text(p.attr('data-blur'));
    } else {
        p.css({
            'top': (h * 0.266) + 'px',
            'font-size': (h * 0.16) + 'px',
            'left': '0px'
        }).text(p.attr('data-blur'));
    }

}


function getOffsetTop(ele) {
    var top = 0;
    if (ele == undefined) {
        return 0;
    }
    if (ele && ele.nodeName == '#document') {
        return 0;
    } else {
        top = ele.offsetTop;
    }
    if (ele.parentNode) {
        if (top == getOffsetTop(ele.parentNode)) {
            top += 0;
        } else {
            top += getOffsetTop(ele.parentNode);
        }

        return top;
    } else {
        return top;
    }
}


var clientHeight = document.documentElement.clientHeight || document.body.clientHeight;
/*
* 输入框聚焦之后的动画实现*/
$('input:not(:button):not(:radio):not(:checkbox), textarea').focus(function () {
    if (!$(this).prop('readonly')) {
        var label = $('label[for=' + $(this).attr('id') + ']');
        if (label.length > 0) {
            label.animate({
                'top': '0px',
                'font-size': (h * 0.12) + 'px',
                'left': '0px'
            }, 200, 'linear').text(label.attr('data-focus'));
            label.closest('div').addClass('focus');
        }
        var ele = $(this).closest('div')[0];
        var input = $(this);
        // console.log(getOffsetTop(ele));
        try {
            if (getOS() == 'Android') {
                /*setTimeout(function () {
                    var nowClientHeight = document.documentElement.clientHeight || document.body.clientHeight;
                }, 1000);*/
                $($('.main')[0]).css('margin-bottom', '300px');
                if (input.attr('id') == 'StayTime') {
                    $('.main')[0].scrollTo(0, 400);
                } else {
                    $('.main')[0].scrollTo(0, getOffsetTop(ele) - 3 * h);
                }
            }
        } catch (e) {

        } finally {
            input.css('caret-color', '#1069da');
            $(window).off('resize');
            $(window).on('resize', function () {
                var style = $($('.main')[0]).attr('style').split(';');
                var l = style.length;
                for (var i = l - 1; i > 0; i--) {
                    if (style[i].indexOf('margin-bottom') > -1) {
                        break;
                    }
                }
                style.splice(i, 1);
                $($('.main')[0]).attr('style', style.join(';'));
                var nowClientHeight = document.documentElement.clientHeight || document.body.clientHeight;
                if (input.attr('id') == 'StayTime') {
                    $('.main')[0].scrollTo(0, 400);
                } else {
                    if (clientHeight > nowClientHeight) {
                        var top = getOffsetTop(ele);
                        if (top < nowClientHeight - 1 * h) {
                            return;
                        } else {
                            $('.main')[0].scrollTo(0, top - (clientHeight - nowClientHeight));
                        }
                    }
                }
            });
        }
    }
});
/*
* 输入框失焦之后的动画实现*/
$('input:not(:button):not(:radio):not(:checkbox),textarea').blur(function () {
    if (!$(this).prop('readonly')) {
        var label = $('label[for=' + $(this).attr('id') + ']');
        if (label.length > 0) {
            if (!$(this).val()) {

                if (label.attr('data-focus') && label.next().find('span:first-of-type').hasClass('currentToken')) {
                    label.animate({
                        'top': (h * 0.266) + 'px',
                        'font-size': (h * 0.16) + 'px',
                        'left': (h * 0.2) + 'px'
                    }, 200, 'linear').text(label.attr('data-blur'));
                } else {
                    label.animate({
                        'top': (h * 0.266) + 'px',
                        'font-size': (h * 0.16) + 'px',
                        'left': '0px'
                    }, 200, 'linear').text(label.attr('data-blur'));
                }
            }
            label.closest('div').removeClass('focus').removeClass('errorInput');
        }
        try {
            if (getOS() == 'Android') {
                var style = $($('.main')[0]).attr('style').split(';');
                var l = style.length;
                for (var i = l - 1; i > 0; i--) {
                    if (style[i].indexOf('margin-bottom') > -1) {
                        break;
                    }
                }
                style.splice(i, 1);
                $($('.main')[0]).attr('style', style.join(';'));
                $('.main')[0].style.height = clientHeight + 'px';
            } else {
                $('.main')[0].style.height = clientHeight + 'px';
            }
        } catch (e) {
            // console.log(e.message);
        }
    }
});

var nodeName, inputEle;
$('.main').on('touchstart', function () {
    nodeName = document.activeElement.nodeName.toLowerCase();
    if (nodeName == 'input') {
        inputEle = document.activeElement;
        inputEle && $(inputEle).css('caret-color', 'transparent');
    } else {
        inputEle = null;
    }
});

$('.main').on('touchmove', function () {
    if (nodeName == 'input') {
        inputEle && $(inputEle).css('caret-color', 'transparent')
    }
});

$('.main').on('touchend', function () {
    if (nodeName == 'input') {
        inputEle && $(inputEle).css('caret-color', '#1069da');
    }
});



/*
* 密码框禁止复制、粘贴、剪切*/
$("input:password").bind("copy cut paste", function (e) {
    return false;
});

// 获取当前操作系统
function getOS() {
    var os;
    if (navigator.userAgent.indexOf('Android') > -1 || navigator.userAgent.indexOf('Linux') > -1) {
        os = 'Android';
    } else if (navigator.userAgent.indexOf('iPhone') > -1) {
        os = 'iOS';
    } else if (navigator.userAgent.indexOf('Windows Phone') > -1) {
        os = 'WP';
    } else {
        os = 'Others';
    }
    return os;
}

// 获取操作系统版本
function getOSVersion() {
    var OSVision = '1.0';
    var u = navigator.userAgent;
    var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Linux') > -1; //Android
    var isIOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
    if (isAndroid) {
        OSVision = navigator.userAgent.split(';')[1].match(/\d+\.\d+/g)[0];
    }
    if (isIOS) {
        OSVision = navigator.userAgent.split(';')[1].match(/(\d+)_(\d+)_?(\d+)?/)[0];
    }
    return OSVision;
}


/*
* <div class=" revise border-bottom" id="account01">
        <!--<li>-->
            <label class="font-12 font-666 overlayText" id="account02" data-blur="请输入账号/卡号" data-focus="账号/卡号" for="account2">

            </label>
            <p class="font-12 font-666 overlayText" id="account03" data-blur="请输入账号" data-focus="账号" style="display: none;"></p>
            <p>
                <input type="text" class="font-18 input font-111" value="" id="account2">
            </p>
        <!--</li>-->
    </div>
    <div class="revise border-bottom">
			<label class="font-16 font-666 overlayText" data-blur="请输入账号" data-focus="账号"
				   for="account3" style="width:70%;"></label>
			<p>
				<input type="text" class="font-18 input font-111" value="" id="account3" maxlength="30" style="width:70%;" />
				<input type="text" value="获取验证码" class="font-12 font-blue input" style="" readonly/>
			</p>
	</div>
	<div class="revise border-bottom">
            <label class="font-12 font-888 overlayText" data-focus="金额" style="width:90%;left: 0.2rem;" data-blur="请输入金额" for="money"></label>
            <p>
                <span id="currentToken01" style="margin-right: 0.15rem;width:auto;">&yen;</span>
                <input type="number" class="font-16 input current" id="money" style="width:90%;">
            </p>
    </div>
* */
