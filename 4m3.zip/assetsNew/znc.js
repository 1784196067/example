var newData = {};
var fo = "";
var dat = "";
var showFlag = "";
var isClosedProduct = "";
var isRegularFund = "";
var fromld = "";
var PurchaseRedeemStatus = "";
$(function () {
    setTimeout(function () {
        var Request = new Object();
        Request = GetRequest();
        fo = (Request["txt"]);
        dat = JSON.parse(fo);
        var aa = dat.aa;
        var porList = dat["porList01"];
        newData = JSON.parse(porList)[aa];
        showFlag = newData.product.properties.buttonFlag;
        $("#name01").text(newData.product.prodName);

        var prodSecCatId = newData.product.prodSecCatId;
        isRegularFund = newData.product.properties.isRegularFund;//长信德邦判断字段
        isClosedProduct = newData.product.properties.isClosedProduct;//长信德邦判断字段
        fromld = newData.product.properties.biipNewFlag;

        PurchaseRedeemStatus = newData.product.properties.purchaseRedeemStatus;
        if (PurchaseRedeemStatus) {
            switch (PurchaseRedeemStatus) {
                case "00":
                    $(".ld_invest").css({
                        "background-color": "#999",
                        "pointer-events": "none",
                        "cursor": "default"
                    }).text("暂停申购");
                    $(".ld_zhq").css({
                        "background-color": "#999",
                        "pointer-events": "none",
                        "cursor": "default"
                    }).text("暂停赎回");
                    break;
                case "01":
                    $(".ld_invest").css({
                        "background-color": "#999",
                        "pointer-events": "none",
                        "cursor": "default"
                    }).text("暂停申购");
                    break;
                case "10":
                    $(".ld_zhq").css({
                        "background-color": "#999",
                        "pointer-events": "none",
                        "cursor": "default"
                    }).text("暂停赎回");
                    break;
                case "11":
                    break;
                case "0":
                    break;
            }
        }

        var detailList = newData.detailList;
        var txnInfoList = newData.txnInfoList;

        //智能存页面数据渲染
        var html = "";
        if (fromld == "1") {
            $("#ld_invest").show();
            $("#ld_zhq").show();
            $.each(newData.product.properties.MarDateList, function (index, item) {
                html += '<li class="clearfix border-bottom">' +
                    '<p class="left text_color">' + item.showName +
                    '</p>' +
                    '<p class="right title_color"><span class="">' + item.showValue + '</span></p>' +
                    '</li>';
            });
        } else {
            $.each(detailList, function (index, item) {
                html += '<li class="border-bottom">' +
                    '<span class="font-888 font-14">' + item.showName + '</span>' +
                    '<span class="font-16 font-111">' + item.showValue + '</span>' +
                    '</li>'
            });
        }
        $("#jijin").html(html);

        //智能存本金明细数据渲染
        if (prodSecCatId == "02001") {
            $("#HoldDetail").bind('click',function(){
                $("#znc_main").hide();
                $("#znc_detail").show();
                var htmlList = "";
                $.each(txnInfoList, function (index, item) {
                    htmlList += '<li class="border-bottom">' +
                        '<span class="font-888 font-14">' + item.setUpdate + '</span>' +
                        '<span class="font-16 font-111">' + item.amount + '</span>' +
                        '</li>'
                });
                //明细列表
                $("#zncList").html(htmlList);
            });
        }
    }, 100)
});

//智能存支取
$("#zhinengcun").click(function () {
    window.location.href = 'withdrawal.html?txt$' + encodeURI(JSON.stringify(newData));
});
//智能存购买
$("#zhinengcun_invest").click(function () {
    window.location.href = '../productDetailsNew/intelligentBuy.html';
});

//智能存主页返回按钮
$("#shback").bind('click',function(){
    window.location.href = 'myAssets.html';
});

//智能存本金明细详情返回按钮
$("#shback0").bind('click',function(){
    $("#znc_main").show();
    $("#znc_detail").hide();
});

//监控手机按键
isgoback(true);
function onBackPressed(){
    window.history.go(-1);
}
