var fo, dat, insuranceSocial;

function wrarantyInfoList() {
    if (getIsLogined()) {
        var jsonObject = getJsonObject();
        jsonObject["method"] = "dbk.insurance.xyInsuranceInfoList";
        jsonObject["prodId"] = 'XY20170501';
        var jsonObject2 = secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.insurance.xyInsuranceInfoList";
        getForData(jsonObject2, function (data) {
            setVal(data);
        });
    } else {
        startToLogin();
    }
}



function setVal(data) {
    var list = data.insuredInfo;
    if (list == "") {
        tipsError("您暂未购买过保险产品");
    } else {
        // alert(JSON.stringify(data));
        location.href = '../assetsNew/warrantyInfo-list.html?txt$' + JSON.stringify(data);
    }
};

function renderData(data) {
    var aside = "";
    list = data.insuredInfo;
    $.each(list, function (index, item) {
        if (item.status == "0") {
            type = "承保失败"
        } else if (item.status == "1") {
            type = "承保成功"

        } else if (item.status == "4") {
            type = "已撤单"

        } else if (item.status == "3") {
            type = "已满期"
        }
        aside += '<div class="order" data-index="' + item.orderId + '" >' +
            '      <div class="clearfix myAssetsETb border-bottom">' +
            '        <div class="myAssetsET">' +
            '          <span class="font-16 font-111 prodName" id="' + item.insuranceSocial + '">' + data.prodName + '</span>' +
            '          <p class="font-12 font-888">' + item.chargeTime.replace('T', '  ') + '</p>' +
            '        </div>' +
            '        <div  class="font-12 font-888 myAssetsEb">' +
            '          <span class="font-20 font-111">' + item.coverageAmnt + '</span>' +
            '          <p class="font-12 font-888 status">' + type + '</p>' +
            '        </div>' +
            '      </div>' +
            '    </div>';
    });
    $('.policyList').html(aside);
    $('.order').click(function () {
        var orderId = $(this).attr('data-index');
        var status = $(this).find(".status").text();
        insuranceSocial = $(this).find('span.prodName').attr('id');
        var jsonObject = getJsonObject();
        jsonObject["method"] = "dbk.insurance.xyInsuranceInfos";
        jsonObject["orderId"] = orderId;
        jsonObject["status"] = status;
        jsonObject["socialInsuranceStatus"] = insuranceSocial;
        var jsonObject2 = secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.insurance.xyInsuranceInfos";
        getForData(jsonObject2, function (data) {
            var dataN = JSON.stringify(data);
            window.location.href = "warrantyInfo.html?txt$" + dataN;
        }, true);
    });
}

function initData() {
    /*IsNeedClear();
    getTransferData("login_key");
    var type = "";
    Request = GetRequest();
    fo = (Request["txt"]);
    var data = JSON.parse(fo);
    alert(fo);
    if(fo && data.insuredInfo){
        renderData(data);
    }else{*/
    IsNeedClear();
    getTransferData("login_key");
    rightEnter(function () {
        Request = GetRequest();
        fo = (Request["txt"]);
        if (fo) {
            dat = JSON.parse(fo);
        } else {
            dat = {};
        }
        var jsonObject = getJsonObject();
        jsonObject["method"] = "dbk.insurance.xyInsuranceInfoList";
        jsonObject["prodId"] = 'XY20170501';
        var jsonObject2 = secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.insurance.xyInsuranceInfoList";
        getForData(jsonObject2, function (data) {
            renderData(data);
        }, true);
    });
    // }
}

