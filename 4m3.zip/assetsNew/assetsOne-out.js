var list = "";
var currCard = "";//当前卡
var reg = /^(\d{4})\d+(\d{4})$/;
var cards = [];
var moneyFormat = "";
var dat = "";
var dis = 0;
var branchCd;//快线宝是几号 标志
var fundCode;
var Request = new Object(1);
Request = GetRequest();
fo = (Request["txt"]);
dat = JSON.parse(fo);
branchCd = dat.product.properties.branchCd;
fundCode = dat.product.prodId;
$(function () {
    setTimeout(function () {
        getTransferData("login_key");
        $("#typeTitle").html(dat.product.prodName);
        queryRedeemInfo();

        $("#balance").text(formatMoney(dat.product.properties.avShare));

        //卡号
        $('#user').text(getEAcct().replace(reg, "$1****$2"));
        //点击确认转出按钮
        $('#money').bind('input propertychange', function () {
            if ($('#money').val() != "") {
                $('.assetsOne-btn').css("background", "#007ae0");
            }
        });
    }, 100);
});
$('.assetsOne-btn').click(function () {
    $('.assetsOne-btn').removeAttr('onclick');
    dis++;

    if (dis != 1) {
        tipsError("请不要点击那么快！");
        dis = 0;
    } else {
        var len = $('#money').val().length;
        var alertMessage = ''; // 提示信息
        var residue = $("#residue").html();
        var share;
        share = dat.product.properties.avShare;
        var sta2 = $('#quickIn').prop('checked');
        if (len == 0) {
            alertMessage = '请输入赎回份额';
            tipsError(alertMessage);
            dis = 0;
            $('.assetsOne-btn').attr('onclick');
            return;
        } else if ($("#money").val() < 0.01) {
            alertMessage = '转出份额不能小于0.01份';
            tipsError(alertMessage);
            dis = 0;
            $('.assetsOne-btn').attr('onclick');
            return;
        } else if (-(-$("#money").val()) > share) {
            alertMessage = '您的转出份额大于可转出余额，请修改赎回份额后再试';
            //
            tipsError(alertMessage);
            dis = 0;
            $('.assetsOne-btn').attr('onclick');
            return;
        } else if (sta2) {
            if (residue != "") {
                if (parseFloat($('#money').val()) > parseFloat(residue)) {
                    if (residue == 0) {
                        alertMessage = '您今日的快速赎回额度已用罄，请明天再试';
                    } else {
                        alertMessage = '快速转出份额超过当日可赎回额，请调整后再试';
                    }
                    tipsError(alertMessage);
                    dis = 0;
                    $('#money').val(residue);
                    $('.assetsOne-btn').attr('onclick');
                    return;
                }
            }
        }
        if (sta2) {
            transType = 0;
        } else {
            transType = 1;
        }
        getlddata();
    }
});

var isopen = true;

function getbalance() {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.account.queryShbSwitchStatus";
    jsonObject["userId"] = getMid();
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.account.queryShbSwitchStatus";
    $.ajax({
        type: "POST",
        url: address,
        data: jsonObject2,
        dataType: "json",
        timeout: requestTimeOut,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        beforeSend: function () {
            // showLoding();
        },
        success: function (data1) {
            var data = secondaryde(data1);
            var kxbLimitStatus = data.kxbLimitStatus;
            if (data.retCode == "000000") {
                if (kxbLimitStatus == "0") {
                    isopen = false;
                } else {
                    if (data.biipSwitchStatus == "1") {
                        isopen = true;
                    } else {
                        isopen = false;
                    }
                }
            } else {
                alert(data.retMsg);
                return;
            }

        },
        error: function () {
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}

function sh() {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.lidebiip.queryCsAndFundTxc";
    if (dat.product.prodId == "000359") {
        jsonObject["fundCode"] = "000359";
        jsonObject["branchCd"] = "EFUND";//固定

    } else {
        jsonObject["fundCode"] = fundCode;
        jsonObject["branchCd"] = branchCd;
    }
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.lidebiip.queryCsAndFundTxc";
    $.ajax({
        type: "POST",
        url: address,
        data: jsonObject2,
        dataType: "json",
        timeout: requestTimeOut,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var data = secondaryde(data1);
            if (data.retCode == "000000") {
                var jsonObject = getJsonObject();
                jsonObject["method"] = "dbk.lidebiip.fundRedeem";
                jsonObject["cstSignNo"] = data.cstSignNo;
                if (transType == "0") {
                    jsonObject["redeemBizCode"] = "098";
                } else {
                    jsonObject["redeemBizCode"] = "024";
                }
                jsonObject["fundAcc"] = data.fundAcc;
                jsonObject["fundTxnAcc"] = data.fundTxnAcc;
                jsonObject["fundCode"] = fundCode;
                jsonObject["amount"] = $("#money").val();
                var jsonObject2 = secondaryIndilling(jsonObject);
                jsonObject2["method"] = "dbk.lidebiip.fundRedeem";
                getForData(jsonObject2, function (data) {
                    data["fromld"] = "2";
                    data["moneyFormat"] = $("#money").val();
                    window.location.href = "assetsOneBuy-res.html?txt$" + JSON.stringify(data);
                });
            } else if (data.retCode == "Login9999") {
                logout();
                doKickOutAction("", "");
            } else if (data.retCode == "Login9998") {
                logout();
                startActivity("MainPage", "");
            } else {
                Alert(data.retMsg);
            }
        },
        error: function () {
            dissmissLoding();
            requestFailTips();
        },
        complete: function () {
            $('.assetsOne-btn').attr('onclick');
            dis = 0;
        }
    })
}

function getlddata() {
    dis = 0;
    $('.assetsOne-btn').attr('onclick');
    if (!isopen) {
        showPopAffirm("温馨提示", "请确认是否赎回？", "取消", "确定", null, sh)
    } else {
        showPopAffirm("温馨提示", "为避免到账资金自动申购快线宝,建议赎回后关闭自动余额理财开关,请确认是否赎回？", "取消", "确定", null, sh);
    }
}

function queryRedeemInfo() {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.lidebiip.biipQuickReedemLimit";
    jsonObject["fundCode"] = fundCode;
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.lidebiip.biipQuickReedemLimit";
    getForData(jsonObject2, function (data) {
        $('#quota').text(data.limitShare);
        $('#residue').text(data.remainShare);
        var TradeDate = data.tradeDate;
        $('#predict').text(TradeDate.substring(0, 4) + '-' + TradeDate.substring(4, 6) + '-' + TradeDate.substring(6, 8));
        getbalance();
    })
}

function look() {
    if ($("#look").css("display") == "none") {
        $("#look").show();
        $('body').scrollTop(100);
    } else {
        $("#look").hide();
    }
}

isgoback(true);
function onBackPressed(){
    window.history.go(-1);
}

