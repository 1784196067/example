var year = new Date().getFullYear();
var month = new Date().getMonth();
var day = new Date().getDate();
console.log(year, month, day);
var dateList = [];
var monthGroup = [];

function getDayNum(month, year) {
    switch (month) {
        case 4:
            ;
        case 6:
            ;
        case 9:
            ;
        case 11:
            return 30;
            break;
        case 2:
            return ((year % 4 == 0) && (year % 100 != 0 || year % 400 == 0)) ? 29 : 28;
            break;//判断闰年
        default:
            return 31;
    }
}

var dayGroup = [];
//12个月，注释的部分是三级联动的日期选择器的实现
for (var j = 1; j < 13; j++) {
    dayGroup = [];
    /*  var days = getDayNum(j, year);
      for (var l = 1; l < days + 1; l++) {
        var dayObj = {
          "id": l,
          "name": l > 9 ? l : ('0' + l)
        }
        dayGroup.push(dayObj);
      }*/
    monthGroup.push({
        "id": j,
        "name": j > 9 ? j : ('0' + j),
        "child": dayGroup.concat()
    });
}
//显示的年份长度，从今年计算
var num = 2;
for (var i = 1; i < num + 1; i++) {
    var year2 = year - (num - i);
    /*var dayGroup2 = [];
    var days = getDayNum(2, year2);
    for (var l = 1; l < days + 1; l++) {
      var dayObj = {
        "id": l,
        "name": l > 9 ? l : ('0' + l)
      }
      dayGroup2.push(dayObj);
    }
    monthGroup[1] = {
      "id": 2,
      "name": '02',
      "child": []
    }
    monthGroup[1].child = dayGroup2;*/
    dateList.push({
        id: i,
        name: year2,
        child: monthGroup.concat()
    });
    if(year2 == year){
        dateList[dateList.length-1].child.splice(month+1);
    }
}