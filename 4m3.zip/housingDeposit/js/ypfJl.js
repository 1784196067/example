Request = GetRequest();
var fo = (Request["txt"]);
dat = JSON.parse(fo);
var channel = dat.type;
setTimeout(function () {
    if (channel === "ypf") {
        $("#typeTitle").text("购房保证金（壹平方）");
    } else if (channel === "JL") {
        $("#typeTitle").text("购房保证金（嘉联）");
    }
    searchInfo(channel);
}, 200);

function searchInfo(channel) {
    // alert(11111111111111);
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.lianlian.ypfQueryCustomerData";
    jsonObject["channelId1"] = channel;
    //jsonObject["appVersion"] = "4.4.0";
    //alert(JSON.stringify(channel));
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.lianlian.ypfQueryCustomerData";
    showLoding();
    getForData(jsonObject2, function (res) {
        var data = res.ypfList;
        var html = '';
        if (data.length === 0) {
            // $('.noRecord').show();
            tipsError("您暂未开通此业务！");
            // $(".container").css({"padding": "0"});
        }
        $.each(data, function (i) {
            html +='<div class=" pd-tp-15">'+
                '<ul class="border-bottom clearfix housing">'+
                '<li>'+
                '<p class="font-12 font-666">户名</p>'+
                '<p class="font-16 font-111">'+data[i].custName+'</p>'+
                '</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">账号</li>'+
                '<li class="font-111 font-18">'+data[i].subAccount+'</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">账号余额</li>'+
                '<li class="font-111 font-18">'+data[i].availableBalance+'</li>'+
            '</ul>'+
            '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">认筹金额</li>'+
                '<li class="font-111 font-18">'+data[i].txnAmt+'</li>'+
            '</ul>'+
            '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">存款日期</li>'+
                '<li class="font-111 font-18">'+data[i].posDepositTime+'</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">退款日期</li>'+
                '<li class="font-111 font-18 date">'+data[i].posRollOut+'</li>'+
                '</ul>'+
                '</div>';
        });
        $(".container").html(html);
        var dateArr = $(".date");
        $.each(dateArr, function (i) {
            if (dateArr[i].innerText === '') {
                $(this).closest(".info").hide();
            }
        })
    })
}

isgoback(true);

function onBackPressed() {
    window.history.go(-1);
}