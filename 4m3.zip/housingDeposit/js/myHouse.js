var isrue = "1";
$(function () {
    setTimeout(function () {
        // 查询我的
        queryOrder();
    },100);
});

function queryOrder() {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.lianlian.queryOrder";
    jsonObject["userId"] = getMid();
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.lianlian.queryOrder";
    getForData(jsonObject2, function (data) {
        effectList = data.effect;
        // alert(JSON.stringify(effectList));
        var effectHtml = '';
        $.each(effectList, function (index, item) {
            effectHtml += '<ul class="border-bottom clearfix housing" onclick="ydjEffectClick(' + index + ')">' +
                '<li>' +
                '<p class="font-12 font-888">' + item.merchantName + '</p>' +
                '<p class="font-16 font-111">' + item.projectName + '</p>' +
                '</li>' +
                '<li class="icon-set"><img src="../img/recommendNew/setting_list@2x.png" alt=""></li>' +
                '<li class="icon-left font-888 font-12">' + item.orderStatus + '</li>' +
                '</ul>'
        });
        // $('#myOrder').html(effectHtml);
        failureList = data.failure;
        $.each(failureList, function (index, item) {
            effectHtml += '<ul class="border-bottom clearfix housing" onclick="zfthEffectClick(' + index + ')">' +
                '<li>' +
                '<p class="font-12 font-888">' + item.merchantName + '</p>' +
                '<p class="font-16 font-111">' + item.projectName + '</p>' +
                '</li>' +
                '<li class="icon-set"><img src="../img/recommendNew/setting_list@2x.png" alt=""></li>' +
                '<li class="icon-left font-888 font-12">' + item.orderStatus + '</li>' +
                '</ul>'
        })
        $('#myOrder').html(effectHtml);
    });
}

function ydjEffectClick(index) {
    var thisInfo = effectList[index];
    var lastData = {
        isAdministrators: 0,
        info: thisInfo
    }
    window.location.href = "freezingHouse.html?txt$" + encodeURI(JSON.stringify(lastData));
}

function zfthEffectClick(index) {
    var thisInfo = failureList[index];
    var lastData = {
        isAdministrators: 0,
        info: thisInfo
    }
    window.location.href = "houseCheck.html?txt$" + encodeURI(JSON.stringify(lastData));
}

isgoback(true);

function onBackPressed() {
    window.history.go(-1);
}