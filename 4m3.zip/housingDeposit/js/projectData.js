var level1Num = 5;
var level2Num = 5;
var level3Num = 8;
var projectData = [];

for(var i=0; i<level1Num; i++){
  var obj1 = {
    "id": i,
    "name": i + '室',
    "child":[]
  }
  for(var j=0; j<level2Num; j++){
    var obj2 = {
      "id": j,
      "name": j + '厅',
      "child":[]
    }
    for(var k=0; k<level3Num; k++){
      var obj3 = {
        "id": k,
        "name": k + '卫',
        "child":[]
      }
      obj2['child'].push(obj3);
    }
    obj1['child'].push(obj2);
  }
  projectData.push(obj1);
}
console.dir(projectData);

