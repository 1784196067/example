var zyList='';
$(function () {
    setTimeout(function () {
        // 查询我的
        querymyZYOrder();
    },100);
});

function querymyZYOrder() {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.lianlian.zyQueryOrderListData";
    jsonObject["userId"] = getMid();
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.lianlian.zyQueryOrderListData";
    getForData(jsonObject2, function (data) {
        // alert(JSON.stringify(data));
        zyList = data.zyList;
        // alert(JSON.stringify(effectList));
        if (zyList.length === 0) {
            // $('.noRecord').show();
            tipsError("您暂未开通此业务！");
        }
        var zyHtml = '';
        $.each(zyList, function (index, item) {
            zyHtml += '<ul class="border-bottom clearfix housing" onclick="zhongYuanList(' + index + ')">' +
                '<li>' +
                '<p class="font-12 font-888">' + item.addRess + '</p>' +
                '<p class="font-16 font-111">' + item.projectName + '</p>' +
                '</li>' +
                '<li class="icon-set"><img src="../img/recommendNew/setting_list@2x.png" alt=""></li>' +
                '<li class="icon-left font-888 font-12">' + item.depositStatus + '</li>' +
                '</ul>'
        });
        $('#myZYOrder').html(zyHtml);
    });
}

function zhongYuanList(index) {
    var thisInfo = zyList[index];
    var lastData = {
        info: thisInfo
    }
    window.location.href = "zhongYuanXq.html?txt$" + encodeURI(JSON.stringify(lastData));
}

isgoback(true);

function onBackPressed() {
    window.history.go(-1);
}