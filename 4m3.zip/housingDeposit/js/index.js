
// 管理住房保证金
 //代提回
$("#three").on("click", '.allUser', function (){
   
    if($(this).attr('data-isChecked') == ''){
        $(this).attr('data-isChecked','true');
        // $('#three .button').removeClass('unclick')
       $(this).find('img').attr('src','../img/riskAssessment/dxlb-xz.png');
    }else{
        $(this).attr('data-isChecked','');
        $(this).find('img').attr('src','../img/riskAssessment/dxlb-wx.png');
    };
    if($(this).attr('data-isChecked') || $(this).siblings().attr('data-isChecked')){
        $('#three .button').removeClass('unclick')
    }else if(!$(this).attr('data-isChecked') && !$(this).siblings().attr('data-isChecked')){
        $('#three .button').addClass('unclick');
    }

    
});

//已冻结
$("#two").on("click", '.allUser', function (){
   
    if($(this).attr('data-isChecked') == ''){
        $(this).attr('data-isChecked','true');
        // $('#three .button').removeClass('unclick')
       $(this).find('img').attr('src','../img/riskAssessment/dxlb-xz.png');
    }else{
        $(this).attr('data-isChecked','');
        $(this).find('img').attr('src','../img/riskAssessment/dxlb-wx.png');
    };
    if($(this).attr('data-isChecked') || $(this).siblings().attr('data-isChecked')){
        $('#two .button').removeClass('unclick')
    }else if(!$(this).attr('data-isChecked') && !$(this).siblings().attr('data-isChecked')){
        $('#two .button').addClass('unclick');
    }
});

//按钮

$("#three").on("click", '.button', function (){
    var dtid = "#" +  $(this).parents('.remitResultAll').attr('id');
if($('#three .button').hasClass('unclick') == false){
    $(this).parents('.remitResultAll').removeClass('active').siblings('#two').addClass('active');
    $('[data-id=' + dtid + ']').parents('li').removeClass('active').prev().addClass('active');
    $('#two').children('.listAll').append( $(this).siblings().children('[data-isChecked=true]')).find('[data-isChecked=true]').find('img').attr('src','../img/riskAssessment/dxlb-wx.png').parents('[data-isChecked=true]').attr('data-isChecked','');
    
 }
});

$("#two").on("click", '.button', function (){
    var dtid = "#" +  $(this).parents('.remitResultAll').attr('id');
    if($('#two .button').hasClass('unclick') == false){
        $(this).parents('.remitResultAll').removeClass('active').siblings('#three').addClass('active');
        $('[data-id=' + dtid + ']').parents('li').removeClass('active').next().addClass('active');
        $('#three').children('.listAll').append( $(this).siblings().children('[data-isChecked=true]')).find('[data-isChecked=true]').find('img').attr('src','../img/riskAssessment/dxlb-wx.png').parents('[data-isChecked=true]').attr('data-isChecked','');
     }
    })
