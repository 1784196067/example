var btnType = '', canIncreaseFlag = '', withdrawalFlag = '', canpayFlag = ''
$(function () {
    setTimeout(function () {
        FastClick.attach(document.body);
        var Request = new Object();
        Request = GetRequest();
        fo = (Request["txt"]);
        dat = JSON.parse(fo);
        TxnAmt = '';
        info = dat.info;
        // alert(JSON.stringify(info));
        var isAdministrators = dat.isAdministrators;
        if (isAdministrators == '1') {
            $('.depositMoney').text(moneyOfFormat(info.txnAmt));
            var infoHtml ='<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">已认筹金额（元）</li>'+
                '<li class="font-111 font-16">' + moneyOfFormat(info.projectAmt) +'</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">项目名称</li>'+
                '<li class="font-111 font-16">' + info.projectName + '</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">客户名称</li>'+
                '<li class="font-111 font-16">'+ info.custName +'</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">项目类型</li>'+
                '<li class="font-111 font-16">' + info.houseType + '</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">开户日期</li>'+
                '<li class="font-111 font-16">'+ info.openAccountTime.substring(0, 10) +'</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">币种</li>'+
                '<li class="font-111 font-16">人名币</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">备注</li>'+
                '<li class="font-111 font-16">'+ info.remark +'</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">编号</li>'+
                '<li class="font-111 font-16">'+ info.depositId +'</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">开立日期</li>'+
                '<li class="font-111 font-16">'+ info.periodStartDate + '</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">截至日期</li>'+
                '<li class="font-111 font-16">'+ info.periodEndDate.substring(0, 4) + '-' + info.periodEndDate.substring(4, 6) + '-' + info.periodEndDate.substring(6, 8) +'</li>'+
                '</ul>';
            $('.verificationList').html(infoHtml);
            $('.noAdministrators').show();//保证金金额
        } else {
            $('.noAdministrators').show();//保证金金额
            $('.depositMoney').text(moneyOfFormat(info.txnAmt));
            var infoHtml = '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">项目名称</li>'+
                '<li class="font-111 font-16">' + info.projectName + '</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">客户名称</li>'+
                '<li class="font-111 font-16">'+ info.custName +'</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">项目类型</li>'+
                '<li class="font-111 font-16">' + info.houseType + '</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">开户日期</li>'+
                '<li class="font-111 font-16">'+ info.openAccountTime.substring(0, 10) +'</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">币种</li>'+
                '<li class="font-111 font-16">人民币</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">备注</li>'+
                '<li class="font-111 font-16">'+ info.remark +'</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">编号</li>'+
                '<li class="font-111 font-16">'+ info.depositId +'</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">开立日期</li>'+
                '<li class="font-111 font-16">'+ info.periodStartDate + '</li>'+
                '</ul>'+
                '<ul class="info border-bottom clearfix" style="width:auto;">'+
                '<li class="font-888 font-14">截至日期</li>'+
                '<li class="font-111 font-16">'+ info.periodEndDate.substring(0, 4) + '-' + info.periodEndDate.substring(4, 6) + '-' + info.periodEndDate.substring(6, 8) +'</li>'+
                '</ul>';
            $('.verificationList').html(infoHtml);
        }

        $("#depositback").click(function () {
            shClose("");
        });
        canIncreaseFlag = info.canIncreaseFlag;
        withdrawalFlag = info.withdrawalFlag;
        canpayFlag = info.canpayFlag;

        if (withdrawalFlag == '00') {
            $(".footButton2").css('background-color', '#eaeaea')
        } else {
            $(".footButton2").css('background-color', '#1773d0')
        }

        $('.footButton2').click(function () {
            if (withdrawalFlag == '00' || $(this).attr('data-flag') == 1) {

            } else {
                showPopAffirm('温馨提示', '您确定要做此操作吗？', '取消', '确定');
                $(".confirm").bind('click', function () {
                    btnType = 2;
                    hidePopAffirm();//隐藏弹窗
                    codeAlert();//验证码弹框
                })
            }
        });

    }, 100)
})

        function thaw() {
            var jsonObject = getJsonObject();
            jsonObject["method"] = "dbk.lianlian.releaseDeposit";
            jsonObject["ChannelId"] = '000000';
            jsonObject["DepositId"] = info.depositId;
            jsonObject["userId"] = getMid();
            var jsonObject2 = secondaryIndilling(jsonObject);
            jsonObject2["method"] = "dbk.lianlian.releaseDeposit";
            getForData(jsonObject2, function (data) {
                // withdrawalFlag == '00';
                $(".footButton2").css('background-color', '#eaeaea');
                $(".footButton2").attr('data-flag', '1')
                $('#bg_color').remove();
                i=0;
                tipsWell('交易成功');
            })
        }

        function getCodeM(){
            msgCodeEvent('点击发送验证码-购房保证金','tihuiHouse.html','1');
            var jsonObject = getJsonObject();
            jsonObject["method"] = "dbk.auth.shortMsgLoginCheck";
            //请求参数追加自定义参数
            jsonObject["sendType"] = "0";
            jsonObject["queryEacctFlag"] = "0";
            jsonObject["mobile"] = getMobile();
            var jsonObject2 = secondaryIndilling(jsonObject);
            jsonObject2["method"] = "dbk.auth.shortMsgLoginCheck";
            $.ajax({
                type: "POST",
                url: address,
                data: jsonObject2,
                dataType: "json",
                timeout: requestTimeOut,
                contentType: "application/x-www-form-urlencoded;charset=utf-8",
                beforeSend: function () {
                    showLoding();
                },
                success: function (data1) {
                    var data = secondaryde(data1);

                    if (null != jsonObject.timeStamp) {
                        if (data != null) {
                            var retSign = getRetSign(data.retSign);
                            if (jsonObject.timeStamp == retSign) {
                                if (data.retCode == "000000") {
                                    dissmissLoding();
                                    if (isBeta) {
                                        // Alert("验证码为" + data.dymcode);
                                        var codeM=data.dymcode;
                                        var rs=[];
                                        if(codeM<1){
                                            rs[0]=codeM;
                                        }else{
                                            var reg=/.{1}/g;
                                            rs=codeM.match(reg);
                                            rs.push(codeM.substring(rs.join('').length));
                                        }
                                        for(var i=0;i<rs.length;i++){
                                            $(".codeCom li").eq(i).text(rs[i]);
                                        }
                                        getMsgCode(data.dymcode);

                                    } tipsWell(data.retMsg);
                                } else if (data.retCode == "Login9999") {
                                    logout();

                                    doKickOutAction("", "");
                                } else if (data.retCode == "Login9998") {
                                    logout();
                                    logout1("home");
                                } else {
                                    // 动态密码输入错误，请重新尝试
                                    alert(data.retMsg);
                                }
                            } else {
                                // alert("校验签名失败1");
                                tipsError("校验签名失败1");
                            }
                        }
                    } else {
                        // alert("校验签名失败2");
                        tipsError("校验签名失败2");
                    }
                },
                error: function () {
                    requestFailTips();
                },
                complete: function () {
                    dissmissLoding();
                }
            });
        };

    function getMsgCode(data){
        var jsonObject = getJsonObject();
        //请求参数追加自定义参数
        jsonObject["method"] = "dbk.auth.shortMsgValidate";
        jsonObject["dymCode"] = data;
        jsonObject["isRegFlag"] = "1";
        jsonObject["mobile"] = getMobile();
        var jsonObject2 = secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.auth.shortMsgValidate";
        $.ajax({
            type: "POST",
            url: address,
            data: jsonObject2,
            dataType: "json",
            timeout: requestTimeOut,
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            beforeSend: function () {
                showLoding();
            },
            success: function (data1) {
                var data = secondaryde(data1);
                if (data.retCode == "000000") {
                    if (btnType == '1') {
                        // 增资
                        // doDepositAdd();
                    } else if (btnType == '2') {
                        thaw();
                    } else {
                        // depositExchange();
                    }
                }else if (data.retCode == "Login9999") {
                    logout();
                    doKickOutAction("", "");
                }else if (data.retCode == "Login9998") {
                    logout();
                    logout1("home");
                }else {
                    dissmissLoding();
                    Alert(data.retMsg);
                }
            },
            error: function () {
                dissmissLoding();
                requestFailTips();
            },
            complete: function () {
                dissmissLoding();
            }
        });
    }

isgoback(true);

function onBackPressed() {
    window.history.go(-1);
}

