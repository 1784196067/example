$(function () {
    setTimeout(function () {
        // 删除后面页面存入的数据，和以下代码没关系
        localStorage.removeItem('dataHouse');
        $("#queryProject").blur(function () {
            $('.area1').html('');
            queryAreas();
        })
        $("#searchPro").click(function () {
            $('.area1').html('');
            queryAreas();
        })
    }, 100)
});

// 查询项目，然后返回到页面上
function queryAreas() {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.lianlian.queryDepositByAera";
    jsonObject["ProjectName"] = $("#queryProject").val();
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.lianlian.queryDepositByAera";
    getForData(jsonObject2, function (data) {
        var projectList = data.List;
        // alert(JSON.stringify(projectList));
        var projectHtml = '';
        $.each(projectList, function (index, item) {
            projectHtml +='<ul class="border-bottom clearfix  housing">'+
                '<li class="projectName" data-projectId=' + item.projectId + '>'+
                '<p class="font-12 font-888">'+item.address+'</p>'+
                '<p class="font-16 font-111">'+item.projectName+'</p>'+
                '</li>'+
                '<li class="icon-set">'+'<img src="../img/recommendNew/setting_list@2x.png" alt="">'+'</li>'+
                '</ul>'
        });
        $('.area1').html(projectHtml);
        $('.area1 ul').click(function () {
            var projectNo = $(this).find('.projectName').attr('data-projectId');
            var lastData = {
                projectId: projectNo
            };
            window.location.href = "myHouseSec.html?txt$" + encodeURI(JSON.stringify(lastData));
        })

    });
}

isgoback(true);

function onBackPressed() {
    window.history.go(-1);
}
