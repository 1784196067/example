var info='';
$(function () {
    setTimeout(function () {
        var Request = new Object();
        Request = GetRequest();
        fo = (Request["txt"]);
        dat = JSON.parse(fo);
        info = dat.info;
        // alert(JSON.stringify(info));
        $('.marginAmount').text(moneyOfFormat(info.projectAmt));//保证金金额
        $('.identifyAmount').text(moneyOfFormat(info.txnAmt));//已认筹金额
        $('.projectName').text(info.projectName);//项目名称
        $('.customeName').text(info.custName);//客户名称
        if(info.houseType==''){
            $('#projectTp').hide();
        }else{
            $('#projectTp').show();
            $('.projectType').text(info.houseType);//项目类型
        }
        $('.openAccount').text(info.openAcctDate.substring(0, 4) + '-' + info.openAcctDate.substring(4, 6) + '-' + info.openAcctDate.substring(6, 8));//开户日期
        $('.currency').text('人民币');//币种
        $('.remarks').text(info.remark);//备注
        $('.number').text(info.depositId);//编号
        $('.openDate').text(info.startDate.substring(0, 4) + '-' + info.startDate.substring(4, 6) + '-' + info.startDate.substring(6, 8));//开立日期
        $('.endDate').text(info.endDate.substring(0, 4) + '-' + info.endDate.substring(4, 6) + '-' + info.endDate.substring(6, 8));//截止日期

    }, 100)
});

isgoback(true);

function onBackPressed() {
    window.history.go(-1);
}