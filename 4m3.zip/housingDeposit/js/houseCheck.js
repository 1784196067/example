$(function () {
    setTimeout(function () {
        var Request = new Object();
        Request = GetRequest();
        fo = (Request["txt"]);
        dat = JSON.parse(fo);
        TxnAmt = '';
        info = dat.info;
        // alert(JSON.stringify(info));
        $('.depositMoney').text(moneyOfFormat(info.txnAmt));
        var infoHtml ='<ul class="info border-bottom clearfix" style="width:auto;">'+
            '<li class="font-888 font-14">已认筹金额（元）</li>'+
            '<li class="font-111 font-16">' + moneyOfFormat(info.txnAmt) +'</li>'+
            '</ul>'+
            '<ul class="info border-bottom clearfix" style="width:auto;">'+
            '<li class="font-888 font-14">项目名称</li>'+
            '<li class="font-111 font-16">' + info.projectName + '</li>'+
            '</ul>'+
            '<ul class="info border-bottom clearfix" style="width:auto;">'+
            '<li class="font-888 font-14">客户名称</li>'+
            '<li class="font-111 font-16">'+ info.custName +'</li>'+
            '</ul>'+
            '<ul class="info border-bottom clearfix" style="width:auto;">'+
            '<li class="font-888 font-14">项目类型</li>'+
            '<li class="font-111 font-16">' + info.houseType + '</li>'+
            '</ul>'+
            '<ul class="info border-bottom clearfix" style="width:auto;">'+
            '<li class="font-888 font-14">开户日期</li>'+
            '<li class="font-111 font-16">'+ info.openAccountTime.substring(0, 10) +'</li>'+
            '</ul>'+
            '<ul class="info border-bottom clearfix" style="width:auto;">'+
            '<li class="font-888 font-14">币种</li>'+
            '<li class="font-111 font-16">人民币</li>'+
            '</ul>'+
            '<ul class="info border-bottom clearfix" style="width:auto;">'+
            '<li class="font-888 font-14">备注</li>'+
            '<li class="font-111 font-16">'+ info.remark +'</li>'+
            '</ul>'+
            '<ul class="info border-bottom clearfix" style="width:auto;">'+
            '<li class="font-888 font-14">编号</li>'+
            '<li class="font-111 font-16">'+ info.depositId +'</li>'+
            '</ul>'+
            '<ul class="info border-bottom clearfix" style="width:auto;">'+
            '<li class="font-888 font-14">开立日期</li>'+
            '<li class="font-111 font-16">'+ info.periodStartDate + '</li>'+
            '</ul>'+
            '<ul class="info border-bottom clearfix" style="width:auto;">'+
            '<li class="font-888 font-14">截至日期</li>'+
            '<li class="font-111 font-16">'+ info.periodEndDate.substring(0, 4) + '-' + info.periodEndDate.substring(4, 6) + '-' + info.periodEndDate.substring(6, 8) +'</li>'+
            '</ul>';
        $('.verificationList').html(infoHtml);

        $("#depositback").click(function () {
            shClose("");
        });

    }, 100)
})

isgoback(true);

function onBackPressed() {
    window.history.go(-1);
}