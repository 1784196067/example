var projectData1 = [];
var MerchantId ='';
var obj={};
$(function () {
    setTimeout(function () {
        FastClick.attach(document.body);
        var Request = new Object();
        Request = GetRequest();
        fo = (Request["txt"]);
        dat = JSON.parse(fo);

        // 这一段是为了解决点击协议返回的时候，类型中有值但是金额上没值的情况，
        // 另外点击跳转的按钮时都要将缓存删掉，
        var dataHouse=localStorage.getItem('dataHouse');
        if(dataHouse==''||dataHouse==undefined||dataHouse==null){
            houseId = '';//商品类型id
            TxnAmount='';//商品类型金额
        }else{
            dataHouse=JSON.parse(dataHouse);
            houseId = dataHouse.houseId;//商品类型id
            TxnAmount=dataHouse.TxnAmount;//商品类型金额
            if($("#demo1").val()!=''){
                $('.pay').html('￥'+moneyOfFormat2(dataHouse.TxnAmount));
            }
            MerchantId=dataHouse.MerchantId;
        }

        // newHouse.html 那里带过来的Id，看点击的是哪一个
        projectId = dat.projectId;
        // houseId = '';//商品类型id
        // TxnAmount='';//商品类型金额
        // 渲染页面的信息
        queryInfo();
        // 判断是否同意协议
        // agree();
    }, 100)
})

// 这个是点击协议时存入的字段，下面可用
$("#agreement").click(function(){
    obj={
        TxnAmount:TxnAmount,
        MerchantId:MerchantId,
        projectId:projectId,
        houseId:houseId,
        remark:$('.remarks').val()
    }
    localStorage.setItem('dataHouse',JSON.stringify(obj));
    window.location.href=$(this).attr("data-href");

})
// var projectData1=[
//     {
//         id:1,
//         name:'三室两厅',
//         houseId:'1',
//         jine:'2233'
//     },
//     {
//         id:2,
//         name:'三室一厅',
//         houseId:'2',
//         jine:'113'
//     },
//     {
//         id:3,
//         name:'两室两厅',
//         houseId:'3',
//         jine:'234'
//     }
// ]

function call(txt, ids){
    // console.log('txt=',txt);
    // console.log('ids=',ids);
    $('.pay').html('￥'+moneyOfFormat2(projectData1[ids].txnAmount));
    houseId=projectData1[ids].houseId;
    TxnAmount=projectData1[ids].txnAmount;

    // 判断类型框和选中框是否有值来点亮按钮
    change();

}

// function selectType(){
function selectType(projectData1){
    var area1 = new LArea();
    area1.init({
        'trigger': '#demo1', //触发选择控件的文本框，同时选择完毕后name属性输出到该位置
        'valueTo': '#value1', //选择完毕后id属性输出到该位置
        'keys': {
            id: 'id',
            name: 'name'
        }, //绑定数据源相关字段 id对应valueTo的value属性输出 name对应trigger的value属性输出
        'type': 1, //数据源类型
        'data': projectData1, //数据源
        'level': 1,
        "callback": call
    });
    area1.value=[1];//控制初始位置，注意：该方法并不会影响到input的value
}
// selectType();//测试的

// 查询信息函数，将数据显示在页面上的
function queryInfo() {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.lianlian.queryDeposit";
    jsonObject["ProjectId"] = projectId;
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.lianlian.queryDeposit";
    getForData(jsonObject2, function (data) {
        // alert(JSON.stringify(data));
        var selectHtml = ''
        selcetList = data.List;
        // alert(JSON.stringify(selcetList));
        // 这个类型也是从后台返回过来的，可是我们这边用的是插件，所以将数据push到页面中
        projectData1 = [];
        $.each(selcetList, function (index, item) {
            projectData1.push({
                id:index,
                name:item.houseType,
                houseId:item.houseId,
                txnAmount:item.txnAmount
            })
        })
        // 选择类型的函数传参数数据到插件数据上
        // alert(JSON.stringify(projectData1));
        selectType(projectData1);
        $('.developer').text(data.MerchantName);//这是开发商
        $('.project').text(data.ProjectName);//这是项目名称
        // $('#agreement').attr('href', data.url)//这是协议
        $('#agreement').attr('data-href', data.url)//这是协议

        // 这是结束日期
        $('.endDate').html(data.PeriodEndDate.substring(0, 4) + '-' + data.PeriodEndDate.substring(4, 6) + '-' + data.PeriodEndDate.substring(6, 8))
        MerchantId = data.MerchantId;//开发商id
    });
}

$(".buy").click(function () {
    if (!$('#agreeInput').is(':checked')) {
        // Alert("请勾选协议");
        tipsError("请勾选协议");
        return;
    } else if ($("#demo1").val()=='') {
        // Alert("请选择项目类型");
        tipsError("请选择项目类型");
        return;
    } else {
        // 动态验证码弹框
        codeAlert();
    }
})

function getCodeM() {
    msgCodeEvent('点击发送验证码-购房保证金','addProject.html','1');
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.auth.shortMsgLoginCheck";
    //请求参数追加自定义参数
    jsonObject["sendType"] = "0";
    jsonObject["queryEacctFlag"] = "0";
    jsonObject["mobile"] = getMobile();
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.auth.shortMsgLoginCheck";
    $.ajax({
        type: "POST",
        url: address,
        data: jsonObject2,
        dataType: "json",
        timeout: requestTimeOut,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var data = secondaryde(data1);

            if (null != jsonObject.timeStamp) {
                if (data != null) {
                    var retSign = getRetSign(data.retSign);
                    if (jsonObject.timeStamp == retSign) {
                        if (data.retCode == "000000") {
                            dissmissLoding();
                            if (isBeta) {
                                // Alert("验证码为" + data.dymcode);
                                var codeM=data.dymcode;
                                var rs=[];
                                if(codeM<1){
                                    rs[0]=codeM;
                                }else{
                                    var reg=/.{1}/g;
                                    rs=codeM.match(reg);
                                    rs.push(codeM.substring(rs.join('').length));
                                }
                                for(var i=0;i<rs.length;i++){
                                    $(".codeCom li").eq(i).text(rs[i]);
                                }
                                getMsgCode(data.dymcode);
                            } tipsWell(data.retMsg);
                        } else if (data.retCode == "Login9999") {
                            logout();

                            doKickOutAction("", "");
                        } else if (data.retCode == "Login9998") {
                            logout();
                            logout1("home");
                        } else {
                            // 动态密码输入错误，请重新尝试
                            alert(data.retMsg);
                        }
                    } else {
                        // alert("校验签名失败1");
                        tipsError("校验签名失败1");
                    }
                }
            } else {
                // alert("校验签名失败2");
                tipsError("校验签名失败2");
            }
        },
        error: function () {
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}

function getMsgCode(data){
    msgCodeEvent('提交验证码-购房保证金','addProject.html','2');
    var jsonObject = getJsonObject();
    //请求参数追加自定义参数
    jsonObject["method"] = "dbk.auth.shortMsgValidate";
    jsonObject["dymCode"] = data;
    jsonObject["isRegFlag"] = "1";
    jsonObject["mobile"] = getMobile();
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.auth.shortMsgValidate";
    $.ajax({
        type: "POST",
        url: address,
        data: jsonObject2,
        dataType: "json",
        timeout: requestTimeOut,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var data = secondaryde(data1);
            if (data.retCode == "000000") {
                signApply();
            }else if (data.retCode == "Login9999") {
                logout();
                doKickOutAction("", "");
            }else if (data.retCode == "Login9998") {
                logout();
                logout1("home");
            }else {
                dissmissLoding();
                Alert(data.retMsg);
            }
        },
        error: function () {
            dissmissLoding();
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}
function signApply() {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.lianlian.signApply";
    jsonObject["ChannelId"] = '000000';
    jsonObject["userId"] = getMid();
    jsonObject["TxnAmt"] = TxnAmount;//金额
    jsonObject["MerchantId"] = MerchantId;
    jsonObject["ProjectId"] = projectId;
    jsonObject["houseId"] = houseId;//类型id
    jsonObject["remark"] = $('.remarks').val();//备注
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.lianlian.signApply";
    getForData(jsonObject2, function (data) {
        var lastData = {
            TxnAmt: TxnAmount
        }
        localStorage.removeItem('dataHouse');
        $('#bg_color').remove();
        i=0;
        window.location.href = "newHouseResult.html?txt$" + encodeURI(JSON.stringify(lastData))
    }, true, function (data) {
        if (data.retCode == "I2F01") {
            $('#bg_color').remove();
            i=0;
            showPopAffirm('温馨提示', '您的余额不足，不能进行交易，是否现在进入存入流程？', '暂时不做', '立即开始')
            $(".confirm").bind('click', goRollIn);
        }else {
            $('#bg_color').remove();
            i=0;
            // 项目时间已过，不予开售
            Alert(data.retMsg);
        }
    })
}

function goRollIn() {
    obj={
        TxnAmount:TxnAmount,
        MerchantId:MerchantId,
        projectId:projectId,
        houseId:houseId,
        remark:$('.remarks').val()
    }
    localStorage.setItem('dataHouse',JSON.stringify(obj));
    window.location.href = "../assetsNew/assets-ecome.html";
}

isgoback(true);
function onBackPressed() {
    localStorage.removeItem('dataHouse');
    window.history.back(-1);
}