var card_tel='';//手机号
var i=0;//验证码的

function codeAlert() {
    var html = '<div class="bg_color" id="bg_color">'+
                    '<div class="cardCom2 baisi_footer">'+
                        '<div class="cardTitle font-16 font-111 padding">'+
                            '<div id="mmClose"><img src="../img/trade_close@2x.png"/></div>'+
                            '请输入动态密码'+
                        '</div>'+
                        '<div class="trendsCont1 padding">'+
                            '<div class="phoneHao border-bottom">'+
                                '<div id="phone_num"></div>'+
                            '</div>'+
                            '<div class="code">'+
                                '<ul class="codeCom">'+
                                    '<li></li><li></li><li></li><li></li><li></li><li></li>'+
                                    '<div class="titCode">请输入验证码</div>'+
                                    '<div class="cursor-link"></div>'+
                                '</ul>'+
                                '<input type="button" class="get font-12" value="获取验证码">'+
                            '</div>'+
                        '</div>'+
                        '<div class="numb_box">'+
                            '<ul class="nub_ggg">'+
                                '<li><a href="javascript:void(0);" class="zf_num">1</a></li>'+
                                '<li><a href="javascript:void(0);" class="zj_x zf_num">2</a></li>'+
                                '<li><a href="javascript:void(0);" class="zf_num">3</a></li>'+
                                '<li><a href="javascript:void(0);" class="zf_num">4</a></li>'+
                                '<li><a href="javascript:void(0);" class="zj_x zf_num">5</a></li>'+
                                '<li><a href="javascript:void(0);" class="zf_num">6</a></li>'+
                                '<li><a href="javascript:void(0);" class="zf_num">7</a></li>'+
                                '<li><a href="javascript:void(0);" class="zj_x zf_num">8</a></li>'+
                                '<li><a href="javascript:void(0);" class="zf_num">9</a></li>'+
                                '<li><a href="javascript:void(0);" class="zf_empty font-16">清空</a></li>'+
                                '<li><a href="javascript:void(0);" class="zj_x zf_num">0</a></li>'+
                                '<li><a href="javascript:void(0);" class="zf_del">'+
                                '<img src="../img/images/keyboard_del.png"/></a>'+
                                '</li>'+
                            '</ul>'+
                        '</div>'+
                    '</div>'+
                '</div>';
    $("body").append(html);
    card_tel=$('#phone_num').text(getMobile());
    $("#bg_color").animate({"bottom": 0}, 200);
    // $('.cardCom2').show();
    $(".codeCom li").text("");
    /*关闭弹窗*/
    $("#mmClose").click(function () {
        $("#bg_color").animate({"bottom": "-100%"}, 200);
        setTimeout(function () {
            $("#bg_color").remove();
            $(".codeCom li").attr("data","");
            $(".codeCom li").text('');
            $('.titCode').text('请输入验证码');
            i = 0;
        }, 200);
    });

    // 判断输入的验证码到达六位的时候
    $(".nub_ggg li .zf_num").click(function() {

        $('.titCode').text('');//点击每个li的时候，请输入验证码也要消失
        $('.cursor-link').hide();//验证码光标隐藏
        if (i < 6) {
            $(".codeCom li").eq(i).attr("data", $(this).text());
            $(".codeCom li").eq(i).text($(this).text());
            i++;
            if (i == 6) {
                setTimeout(function () {
                    var data = "";
                    $(".codeCom li").each(function () {
                        data += $(this).attr("data");
                    });
                    getMsgCode(data);
                }, 100);
            }
            ;
        }
    });

    // 点击删除的时候，使数字为空
    $(".nub_ggg li .zf_del").click(function(){
        if(i>0){
            i--;
            $(".codeCom li").eq(i).attr("data","");
            $(".codeCom li").eq(i).text('');

            if(i==0){
                $('.titCode').show();
                $('.titCode').text('请输入验证码');//删除到0位的时候，要使请输入验证码显示
            }
        }
    });

    //点击清空的时候，使所有数字为空
    $(".nub_ggg li .zf_empty").click(function(){
        $(".codeCom li").attr("data","");
        $(".codeCom li").text('');
        $('.cursor-link').hide();//光标隐藏
        i = 0;
        $('.titCode').show();
        $('.titCode').text('请输入验证码');
    });

    //点击获取验证码的时候还有点击每个li的时候显示键盘,flag为0
    $('.get').click(function(){
        $('.numb_box').show();
        if(i!=0){
            $(".titCode").hide();
            $('.cursor-link').hide();//光标隐藏
        }else{
            $(".titCode").text('');
            $('.cursor-link').show();//光标出现
        }
        $(".get").attr("disabled", true);
        var count_down = parseInt(60);
        $(".get").val("60s后重新发送");
        $(".get").css("color", "#999");
        var time = setInterval(function () {
            $(".get").attr("disabled", true);
            $(".get").css("color", "#999");
            count_down--;
            $(".get").val(count_down + "s");
            if (count_down < 0) {
                clearInterval(time);
                $(".get").val("重新发送");
                $(".get").css("color", "#007AE0");
                $(".get").attr("disabled", false);
            }
        }, 1000);
        getCodeM();
    });

    // 点击每个li的时候
    $('.codeCom').click(function(){
        $('.numb_box').show();
        if(i!=0){
            $(".titCode").hide();
            $('.cursor-link').hide();//光标隐藏
        }else{
            $(".titCode").text('');
            $('.cursor-link').show();//光标出现
        }
    });

//    点击请输入验证码
    $('.titCode').click(function(){
        $(this).text('');
        $('.cursor-link').show();//光标出现
    })

}
