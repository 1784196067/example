$(function () {
    setTimeout(function () {
        // 渲染管理员的所有项目
        AdministratorsQueryAreas();
    }, 100);
});
function AdministratorsQueryAreas() {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.lianlian.queryDepositByAera";
    jsonObject["MobilePhone"] = getMobile();
    // console.log(jsonObject);
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.lianlian.queryDepositByAera";
    getForData(jsonObject2, function (data) {
   // alert(JSON.stringify(data));
        projectList = data.List;
        // alert(JSON.stringify(projectList));
        var projectHtml = '';
        $.each(projectList, function (index, item) {
            projectHtml +='<ul class="border-bottom clearfix housing" onclick="goNext(' + index + ')">'+
                '<li>'+
            '<p class="font-12 font-888">'+ item.address +'</p>'+
            '<p class="font-16 font-111" data-projectId=' + item.projectId + '>'+ item.projectName +'</p>'+
            '</li>'+
            '<li class="icon-set"><img src="../img/recommendNew/setting_list@2x.png" alt=""></li>'+
            ' </ul>';
        });
        $('#myProject').html(projectHtml);
    });
}

function goNext(index) {
    var projectNo = projectList[index].projectId;
    var projectName = projectList[index].projectName;
    var lastData = {
        projectId: projectNo,
        projectName:projectName
    }

    window.location.href = "manageHouse.html?txt$" + encodeURI(JSON.stringify(lastData))

}

isgoback(true);

function onBackPressed() {
    window.history.go(-1);
}
