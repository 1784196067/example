var clicktype = '';
var changDu='';
var allMoney='';
$(function () {
    setTimeout(function () {
        var Request = new Object();
        Request = GetRequest();
        fo = (Request["txt"]);
        dat = JSON.parse(fo);
        projectId = dat.projectId;
        projectName = dat.projectName;
        type = '';
        $('#typeTitle').text(projectName);
        queryInfo();
    }, 100)
})

$("#depositback").click(function () {
    shClose("");
});
$('.button11 span').click(function () {
    if ($(this).index() == '0') {
        $('.checkboxFour').hide();
    } else {
        $('.checkboxFour').show();
    }
})

function queryInfo() {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.lianlian.houseBusinessQuery";
    jsonObject["ProjectId"] = projectId;
    jsonObject["ChannelId"] = '000000';
    jsonObject["CondQuery"] = type;
    console.log(jsonObject)
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.lianlian.houseBusinessQuery";
    showLoding();
    getForData(jsonObject2, function (data) {
        infoList = data.list;
        changDu=infoList.length;
        allMoney=0;
        // alert(JSON.stringify(infoList));
        var infoHtml = '';
        if (type == '') {
            $.each(infoList, function (index, item) {
                Info = infoList;
                infoHtml += '<div class="divTable" onclick="goNext(' + index + ')">'+
                                '<table>'+
                                    '<tr>'+
                                        '<td class="checkboxFour" onclick="event.stopPropagation()" rowspan="3" valign="middle"></td>'+
                                        '<td><span class="font-888 font-12">客户姓名：</span><span class="font-111 font-12">'+ item.custName +'</span></td>'+
                                        '<td><span class="font-888 font-12">编号：</span><span class="font-111 font-12">'+ item.depositId +'</span></td>'+
                                    '</tr>'+
                                    '<tr>'+
                                        '<td><span class="font-888 font-12">身份证号：</span><span class="font-111 font-12">'+ item.idNo.substring(0, 4) + '****' + item.idNo.slice(-4) +'</span></td>'+
                                        '<td><span class="font-888 font-12">状态：</span><span class="font-111 font-12">'+ item.depositStatus +'</span></td>'+
                                    '</tr>'+
                                    '<tr>'+
                                        '<td><span class="font-888 font-12">认筹金额：</span><span class="font-111 font-12">'+ item.txnAmt + '元' +'</span></td>'+
                                        '<td><span class="font-888 font-12">保证金金额：</span><span class="font-111 font-12">'+ item.projectAmt + '元' +'</span></td>'+
                                    '</tr>'+
                                '</table>'+
                             '</div>';
                allMoney+=parseFloat(item.txnAmt);
            })

        } else if (type == 'D') {
            $.each(infoList, function (index, item) {
                Info = infoList;//这是失效的
                infoHtml += '<div class="divTable divD">'+
                    '<table>'+
                    '<tr>'+
                    '<td class="checkboxFour" rowspan="3" valign="middle"></td>'+
                    '<td><span class="font-12">客户姓名：</span><span class="font-12">'+ item.custName +'</span></td>'+
                    '<td><span class="font-12">编号：</span><span class="font-12">'+ item.depositId +'</span></td>'+
                    '</tr>'+
                    '<tr>'+
                    '<td><span class="font-12">身份证号：</span><span class="font-12">'+ item.idNo.substring(0, 4) + '****' + item.idNo.slice(-4) +'</span></td>'+
                    '<td><span class="font-12">状态：</span><span class="font-12">'+ item.depositStatus +'</span></td>'+
                    '</tr>'+
                    '<tr>'+
                    '<td><span class="font-12">认筹金额：</span><span class="font-12">'+ item.txnAmt + '元' +'</span></td>'+
                    '<td><span class="font-12">保证金金额：</span><span class="font-12">'+ item.projectAmt + '元' +'</span></td>'+
                    '</tr>'+
                    '</table>'+
                    '</div>';
                allMoney+=parseFloat(item.txnAmt);
            })
        } else {
            $.each(infoList, function (index, item) {
                Info = infoList;
                infoHtml += '<div class="divTable" onclick="goNext(' + index + ')">'+
                    '<table>'+
                    '<tr>'+
                    '<td class="checkboxFour" data-depositId="' + item.depositId + '" id="checkboxFour' + index + '" onclick="event.stopPropagation()" rowspan="3" valign="middle">'+
                    '<img src="../img/images/dxlb-wx.png" alt="">' +
                    '<img class="g2" src="../img/images/dxlb-xz.png" style="display: none;"></td>' +
                    '<td><span class="font-888 font-12">客户姓名：</span><span class="font-111 font-12">'+ item.custName +'</span></td>'+
                    '<td><span class="font-888 font-12">编号：</span><span class="font-111 font-12">'+ item.depositId +'</span></td>'+
                    '</tr>'+
                    '<tr>'+
                    '<td><span class="font-888 font-12">身份证号：</span><span class="font-111 font-12">'+ item.idNo.substring(0, 4) + '****' + item.idNo.slice(-4) +'</span></td>'+
                    '<td><span class="font-888 font-12">状态：</span><span class="font-111 font-12">'+ item.depositStatus +'</span></td>'+
                    '</tr>'+
                    '<tr>'+
                    '<td><span class="font-888 font-12">认筹金额：</span><span class="font-111 font-12">'+ item.txnAmt + '元' +'</span></td>'+
                    '<td><span class="font-888 font-12">保证金金额：</span><span class="font-111 font-12">'+ item.projectAmt + '元' +'</span></td>'+
                    '</tr>'+
                    '</table>'+
                    '</div>';
                allMoney+=parseFloat(item.txnAmt);
            })
        }
        $('.table').html(infoHtml);
        $('.numShu').text(changDu);//条数
        $('.allMoney').text(allMoney.toFixed(2));//金额
        $('.checkboxFour img').bind('click', function (event) {
            $(this).hide()
            $(this).siblings('img').toggle();
        });
    },true,function (data) {
        if (data.retCode == "0002") {
            $('.table').html('<p style="text-align: center;text-align: center;background: transparent; border: none;">'+data.retMsg+'</p>')
        }else {
            alert(data.retMsg)
        }
    })

}

function authorize() {
    hidePopAffirm();
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.lianlian.houseBusinessGave";
    jsonObject["ChannelId"] = '000000';
    jsonObject["depositIds"] = arrList.substring(0, arrList.length - 1);
    jsonObject["AuthoriseSign"] = clicktype;
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.lianlian.houseBusinessGave";
    getForData(jsonObject2, function (data) {
        // Alert('变更成功');
        tipsWell('变更成功');
        $('.button11 span').removeClass('active2');
        if (type == 'F') {
            $('.btn2').addClass('active2');
        } else if (type == 'A') {
            $('.btn3').addClass('active2');
        } else if (type == 'B') {
            $('.btn4').addClass('active2');
        }
        queryInfo();
    });
}
$('.button11 span').click(function () {
    $('.button11 span').removeClass('active2');
    $(this).addClass('active2')
})
$('.btn1').click(function () {
    type = '';
    $('.foot4').html('');
    queryInfo();

})
$('.btn2').click(function () {
    $('.foot4').html('' +
        '<span class="btn-foot2">提回</span>');
    type = 'F';
    queryInfo();

    $('.btn-foot1').on('click', function () {
        clicktype = 'B';
        doTis();
    })
    $('.btn-foot2').on('click', function () {
        clicktype = 'A';
        doTis();
    })
})
$('.btn3').click(function () {
    $('.foot4').html('' +
        '<span class="btn-foot2">冻结</span>')
    type = 'A';
    queryInfo();
    $('.btn-foot1').on('click', function () {
        clicktype = 'B';
        doTis();
    })
    $('.btn-foot2').on('click', function () {
        clicktype = 'F';
        doTis();
    })
})
// 这是支付的
// $('.btn4').click(function () {
//     $('.foot4').html('<span class="btn-foot1">提回</span><span class="btn-foot2">冻结</span>');
//     type = 'B';
//     queryInfo();
//     $('.btn-foot1').on('click', function () {
//         clicktype = 'A';
//         doTis();
//     })
//     $('.btn-foot2').on('click', function () {
//         clicktype = 'F';
//         doTis();
//     })
// })
$('.btn5').click(function () {
    $('.foot4').html('')
    type = 'D';
    queryInfo();
    $('.checkboxFour').hide();
})

function doTis() {
    var divTableIndex = $('.divTable').length;
    arrList = '';
    var selectList = [];
    for (i = 0; i < divTableIndex; i++) {
        var sta = $('#checkboxFour' + i).find('.g2').css('display');
        if (sta == 'none') {

        } else {
            arrList += $('#checkboxFour' + i).attr('data-depositId') + ','
//                selectList
        }
    }
    if (arrList == '') {
        // Alert('请选择您要操作的订单')
        tipsError('请选择您要操作的订单');
        return
    } else {
        showPopAffirm('温馨提示', '您确定要做此变更吗？', '取消', '确定');
        $(".confirm").bind('click', authorize);
    }
}

function goNext(index) {
    var thisInfo = Info[index];
    var lastData = {
        isAdministrators: 1,
        info: thisInfo
    }
    // window.location.href = "freezingHouse.html?txt$" + encodeURI(JSON.stringify(lastData));
    // 管理员只有操作变更的状态，不能给他做其他操作，所以点击过去只查看详情
    window.location.href = "manageInPage.html?txt$" + encodeURI(JSON.stringify(lastData));

}

isgoback(true);

function onBackPressed() {
    window.history.go(-1);
}