/**
 *@FileName:indexIQY.js
 *@Author:LiQi
 *@Date:2019/4/10/16:45
 */
setTimeout(function () {
    var Request = new Object(1);
    Request = GetRequest();
    var fo = (Request["txt"]);
    var dat = JSON.parse(fo);
    $(".moneyAmt").text("1999");
    _dep.init(dat);
    try {
        var UMSAObject = getUMSAObject();
        UMSAObject["eventDesc"] = "爱奇艺购买页";
        postEventActivityJsonUMSA("event_iqy0004", 'aiQiYiIndex.html', UMSAObject);
    } catch (e) {
        Alert(e.message);
    }
}, 100);

var _dep = {
    params: {
        "money": 0
    },
    init: function (data) {
        _dep.getData(data);
        _dep.buyClick();
    },
    getData:function (data) {
        $("#vipCount").text(data.vipCount);
        $(".charge").text(data.charge);
        $("#iqyStatus").text("立享爱奇艺VIP");
        $(".moneyAmt").text(data.money);
        $("#money1").text(moneyOfFormat2(data.money));
        _dep.params.money = data.money;
    },
    /*购买*/
    buyClick: function () {
        var jsonObject = getJsonObject();
        jsonObject["method"] = "dbk.account.qryUserPayType";
        jsonObject["qryType"] = "3";
        var jsonObject2 = secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.account.qryUserPayType";
        getForData(jsonObject2, function (res) {
            var balance = res.amt;
            $("#yuE").text(moneyOfFormat2(balance));
            var cardList = res.payCardList;
            $("#buy").on("click", function () {
                try {
                    var UMSAObject = getUMSAObject();
                    UMSAObject["eventDesc"] = "立即存入";
                    postEventActivityJsonUMSA("event_iqy0005", 'aiQiYiIndex.html', UMSAObject);
                } catch (e) {
                    Alert(e.message);
                }
                var state = $('#agreeInput').is(':checked');
                if (!state) {
                    tipsError("请勾选协议");
                    return;
                }
                goBuy(function () {
                    var eCount = getEAcct();//e账号
                    var eNum = eCount.substring(eCount.length - 4);//后四位
                    payAlert(cardList, _dep.params.money, eNum, balance, "e账户可用余额");
                })
            })
        });
    }
};

function getNative(pwd) {
    try {
        var UMSAObject = getUMSAObject();
        UMSAObject["eventDesc"] = "爱奇艺e账户支付";
        postEventActivityJsonUMSA("event_iqy0006", 'aiQiYiIndex.html', UMSAObject);
    } catch (e) {
        Alert(e.message);
    }
    var moneyFormat = moneyOfFormat(_dep.params.money);
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.order.payOrder";
    jsonObject["recommCust"] = '';
    jsonObject["pwd"] = pwd;
    jsonObject["buyMethod"] = "1";
    jsonObject["orderId"] = "null";
    jsonObject["prodId"] = "IQIYI";
    jsonObject["accountType"] = "E";
    jsonObject["isChangeMobile"] = "0";
    jsonObject["cardNo"] = "null";
    jsonObject["mobile"] = "null";
    jsonObject["dymCode"] = "null";
    jsonObject["buyAmt"] = moneyFormat;
    jsonObject["signTranData"] = getSignTranData(moneyFormat);
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.order.payOrder";
    getForData(jsonObject2, function (data) {
        var array = ['SH_ACTION_ASSETS_CHANGE', ''];
        notifyNativeEvent(array);
        window.location.href = "depResult.html?txt$" + encodeURI(JSON.stringify(data));
    });
}

function fastDeposit(yzm, mobile, cardno, money, isBindCard) {
    var moneyFormat = moneyOfFormat(money);
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.order.payOrder";
    jsonObject["pwd"] = "null";
    jsonObject["recommCust"] = '';
    jsonObject["buyMethod"] = "1";
    jsonObject["orderId"] = "null";
    jsonObject["prodId"] = "IQIYI";
    jsonObject["accountType"] = "C";
    jsonObject["isChangeMobile"] = "0";
    jsonObject["cardNo"] = cardno;
    jsonObject["mobile"] = mobile;
    jsonObject["dymCode"] = yzm;
    jsonObject["buyAmt"] = moneyFormat;
    jsonObject["signTranData"] = getSignTranData(money);
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.order.payOrder";
    getForData(jsonObject2, function (data) {
        var array = ['SH_ACTION_ASSETS_CHANGE', ''];
        notifyNativeEvent(array);
        window.location.href = "depResult.html?txt$" + encodeURI(JSON.stringify(data));
    });
}

function getSMSCode(phone) {
    $('.get').on('click', function () {
        try {
            var UMSAObject = getUMSAObject();
            UMSAObject["eventDesc"] = "爱奇艺卡支付获取验证码";
            postEventActivityJsonUMSA("event_iqy0007", 'aiQiYiIndex.html', UMSAObject);
        } catch (e) {
            Alert(e.message);
        }
        var phone_num = $("#phone_num").val() || phone;
        if (!(/^1[3|4|5|6|7|8|9]\d{9}$/.test(phone_num))) {
            tipsError("请输入正确手机号");
            return;
        }
        $(".get").attr("disabled", true);
        var count_down = parseInt(60);
        $(".get").val("60s后重新发送");
        $(".get").css("color", "#999");
        var time = setInterval(function () {
            $(".get").attr("disabled", true);
            $(".get").css("color", "#999");
            count_down--;
            $(".get").val(count_down + "s");
            if (count_down < 0) {
                clearInterval(time);
                $(".get").val("重新发送");
                $(".get").css("color", "#007AE0");
                $(".get").attr("disabled", false);
            }
        }, 1000);
        //    获取验证码
        var jsonObject = getJsonObject();
        jsonObject["method"] = "dbk.auth.shortMsgLoginCheck";
        jsonObject["queryEacctFlag"] = "0";
        jsonObject["mobile"] = phone_num;
        jsonObject["sendType"] = "1";
        var jsonObject2 = secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.auth.shortMsgLoginCheck";
        getForData(jsonObject2, function (data) {
            if (null != jsonObject.timeStamp) {
                if (data != null) {
                    var retSign = getRetSign(data.retSign);
                    if (jsonObject.timeStamp == retSign) {
                        if (data.retCode == "000000") {
                            if (isBeta) {
//                                    Alert("验证码为" + data.dymcode);
                                $("#code").val(data.dymcode);
                                fastDeposit(data.dymcode, phone_num , cardno, $(".moneyAmt").html(), isBindCard)
                            }
                            tipsWell(data.retMsg);
                        } else if (data.retCode == "Login9999") {
                            logout();
                            doKickOutAction("", "");
                        } else if (data.retCode == "Login9998") {
                            logout();
                            startActivity("MainPage", "");
                        } else {
                            Alert(data.retMsg)
                        }
                    } else {
                        tipsError("校验签名失败");
                    }
                }
            } else {
                tipsError("校验签名失败");
            }
        });
    });
}

$("#more").on("click", function () {
    $("#mask").show();
    $(".main").css("overflow", "hidden");
});
$("#know").on("click", function () {
    $("#mask").hide();
    $(".main").css("overflow", "auto");
});

$("#shback").on("click", function () {
    window.history.go(-1);
});
isgoback(true);

function onBackPressed() {
    window.history.go(-1);
}