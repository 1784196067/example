function goBuy(fn, isBind) {
    if (getIsLogined()) {
        if (getEAcct() == "" || getEAcct() == "0" || getEAcct() == null) {
            showPopAffirm('温馨提示', '绑定银行卡即可使用本服务。您可绑定上海银行或其他银行的银行卡。', '下次再说', '立即绑定', null, goToEac);
        } else {
            if (isBind != false) {
                //判断有没有身份验证
               /* if (getIsIdentitySure() == '0') {
                    showPopAffirm('温馨提示', '您的e账户未完成身份认证，为保障账户安全，需完成身份证资料上传后使用本服务。', '下次再说', '立即上传', null, goToId);
                    return;
                }*/
                if (isReSetTranPwd() == "1") {
                    window.location.href = "../openAccent/setEPass.html";
                } else if (isReSetTranPwd() == "2") {
                    Alert("您的资产不为0，请致电95594客户服务电话重置交易密码");
                } else {
                    if (getIsInputPwd()) {
                        if ("01" != getIsBind()) {
                            var confirm = window.confirm("您的E账户还没有绑定银行卡！请立即绑定银行卡");
                            if (confirm) {
                                //跳往身份认证页面
                                window.location.href = "../settingNew/idCheck.html";
                            }
                        } else {
                            fn();
                        }
                    } else {
                        startToLogin();
                    }
                }
            } else {
                fn();
            }
        }
    } else {
        startToLogin();
    }

}
