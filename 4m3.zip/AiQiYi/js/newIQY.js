/**
 *@FileName:newIQY.js
 *@Author:LiQi
 *@Date:2019/4/10/17:17
 */
setTimeout(function () {
    try {
        var UMSAObject = getUMSAObject();
        UMSAObject["eventDesc"] = "进入爱奇艺海报页";
        postEventActivityJsonUMSA("event_iqy0001", 'aiQiYiNew.html', UMSAObject);
    } catch (e) {
        Alert(e.message);
    }

    var userId = '';
    try {
        if (getIsLogined()) {
            userId = getMid() == 'undefined' ? '' : getMid();
        }
        getInfo(userId);
    } catch (e) {
        alert(e.message);
    }
}, 200);

function getInfo(userId) {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.rights.getActiviTyInfo";
    jsonObject["userId"] = userId;
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.rights.getActiviTyInfo";
    getForData(jsonObject2, function (res) {
        if (res.iqiyiSwitch === "1") {
            var moneyAmt = res.iqiyiAmt;//活动金额
            var vipCount = res.vipCount ? res.vipCount : '0';//权益天数
            var status = res.status;//享受会员状态：1-享受中；0-未享受
            var charge = res.charge;//手续费
            $(".moneyAmt").text(moneyAmt);
            var that = $("#goEnjoy");
            if (status === '1') {
                $("#yes").show();
                $("#vipCount").text(vipCount);
                that.text("点 击 领 取 今 日 会 员");
                getStatus();
                //查看爱奇艺账户
                $("#watch").show().on("click", function () {
                    goBuy(function () {
                        getAssets();
                    })
                });
            } else if (status === '0') {
                $("#no").show();
                $("#watch").hide();
                if ("01" != getIsBind()) {
                    that.text("立 即 领 取");
                } else {
                    that.text("立 即 领 取 更 多 会 员");
                }
                var obj = {"money": moneyAmt, "vipCount": vipCount, "charge": charge};
                $("#goEnjoy").on("click", function () {
                    try {
                        var UMSAObject = getUMSAObject();
                        UMSAObject["eventDesc"] = "立即领取";
                        postEventActivityJsonUMSA("event_iqy0001", 'aiQiYiNew.html', UMSAObject);
                    } catch (e) {
                        Alert(e.message);
                    }
                    goBuy(function () {
                        window.location.href = 'aiQiYiIndex.html?txt$' + encodeURI(JSON.stringify(obj));
                    })
                });
            }
            /*推荐人列表*/
            var recommendList = res.refreeLsit;
            if (!recommendList) {
                $("#shareLists").hide()
            } else {
                $("#allShare").text(recommendList.length);
                var str = '';
                $.each(recommendList, function (i, v) {
                    var recomMobile = v.recomMobile.substring(0, 3) + '****' + v.recomMobile.substring(7, 11);
                    str += '<ul class="font-15 share_friend">' +
                        '     <li>' + recomMobile + '</li>' +
                        '     <li>' + v.recomActTime + '</li>' +
                        '     <li>' + v.refereeTime + '</li>' +
                        '  </ul>'
                });
                $("#shareLists").append(str);
            }
        } else {
            var errorMsg = res.errorMsg;
            Alert(errorMsg, function () {
                shClose('')
            })
        }

    });
}

function getAssets() {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.asset.newAssetsDetails";
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.asset.newAssetsDetails";
    getForData(jsonObject2, function (res) {
        var iqy = res.userRightsList;
        var obj = {
            "totalAmt": iqy.totalAmt,
            "totalRights": iqy.totalRights,
            "tradeTime": iqy.tradeTime
        };
        window.location.href = 'equityChi.html?txt$' + encodeURI(JSON.stringify(obj));
    });
}

function getStatus() {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.rights.checkUserUpToStandArdStatus";
    jsonObject["userId"] = getMid();
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.rights.checkUserUpToStandArdStatus";
    getForData(jsonObject2, function (res) {
        $(".main").show();
        var counts = res.rightsCount ? res.rightsCount : "0";
        $("#count").text(counts);
        $("#goEnjoy").bind("click", function () {
            if (res.status === "00") {
                Alert("资产达标实时自动发放，无需领取；次日起每天都可以点击此处领取噢！");
            } else if (res.status === "01") {
                receive(res.standardSerialNo);
            } else if (res.status === "02") {
                Alert("今日会员已领取，明天再来吧！");
            } else {
                Alert("未知错误，请稍后再试！")
            }
        });

    })
}

function receive(serialNo) {
    var jsonObject = getJsonObject();
    jsonObject["userId"] = getMid();
    jsonObject["standardSerialNo"] = serialNo;
    jsonObject["method"] = "dbk.rights.receiveUserUpToStandardRights";
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.rights.receiveUserUpToStandardRights";
    getForData(jsonObject2, function (res) {
        Alert("成功领取今日会员权益！", function () {
            window.location.reload();
        })
    })
}

/*生成二维码*/
function createQRC(phone) {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.wechatH5.forQRCode";
    jsonObject["scene"] = phone;
    jsonObject['qrCodeType'] = 'IQIYI';
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.wechatH5.forQRCode";
    getForData(jsonObject2, function (res) {
        $("#user").text('推荐人：' + phone.substring(0, 3) + '****' + phone.substring(7, 11));
        var imageUrl = '';
        if (isBeta) {
            imageUrl = 'http://testclient.mybosc.com:10088/portal4m120/files/wxxcxQRcode/1.jpg?timestamp=' + Math.random();
        } else {
            //生产
            imageUrl = 'https://client.mybosc.com/portal4m3/files/wxxcxQRcode/1.jpg?timestamp=' + Math.random();
        }

        $("#alertQRC").show();
        $("#alertQRC .image").html('<img src="' + imageUrl + '" alt="">');
        $("#esc").on("click", function () {
            $("#alertQRC").hide();
        })
    })
}

function shareWX() {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.share.introduceCut";
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.share.introduceCut";
    getForData(jsonObject2, function (res) {
        //title要获取的标题；desc要获取的内容；url要获取的分享链接；sharePlatform分享的渠道；imageUrl图片
        var phone = getMobile(), userId = getMid();
        var userInfo = {
            "phone": phone,
            "userId": userId
        };
        var url = '';
        if (isBeta) {
            url = 'http://testclient.mybosc.com:10088/portal4m120/WeChat/page/Iqiyi/IqiyiActivePage/IqiyiActivePage.html';
        } else {
            url = 'https://client.mybosc.com/portal4m3/WeChat/page/Iqiyi/IqiyiActivePage/IqiyiActivePage.html';
        }
        var obj = {
            "title": "上行快线免费送爱奇艺会员啦！",
            "desc": "爱奇艺会员天天免费送，热剧享不停！",
            "url": url + "?shareData=" + encodeURI(JSON.stringify(userInfo)),
            "imageUrl": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAASABIAAD/4QBMRXhpZgAATU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAXKADAAQAAAABAAAAXAAAAAD/7QA4UGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAAA4QklNBCUAAAAAABDUHYzZjwCyBOmACZjs+EJ+/8AAEQgAXABcAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMAAQEBAQEBAgEBAgMCAgIDBAMDAwMEBQQEBAQEBQYFBQUFBQUGBgYGBgYGBgcHBwcHBwgICAgICQkJCQkJCQkJCf/bAEMBAQEBAgICBAICBAkGBQYJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCf/dAAQABv/aAAwDAQACEQMRAD8A/qA/4KA/8FAdX+DmryfBb4LSRr4gWNW1HUWVZBZiQBliiVgVaZlIZmYEICAAWOU/Azxb4+8c+PdQfVvG+sXur3Mhy0l5PJMx/F2OAOw7UePvFmoePfHOseN9VcyXOr3s95Ix7tNIzn6DngdqpeG/CfirxlqI0fwhpl3qt2RkQWcMk8hHrsjDN+lfxpxRxRi81xUpSk+W/uxWyXTTv3Z/lJ4i+ImZcSZjOc5t07tQgr2S6adW1u92/KyXP0V9i+Ev2Af2u/GQWSw8FXdpGeS1+8Nnge6Tuj/kpNe76J/wSV/al1QBtQuND031FxdyMR/35hlH61y4bhDNKyvTw8vua/M83L/C/iPFJSo4Go0+rg0vvaSPzDor9e7P/gjp8anx9v8AFWiRevli5k/nElaB/wCCN/xW7eMNJP8A2yn/AMK9FeHedPX6u/vX+Z70fAvixq6wUvvj/wDJH46UV+yMX/BG74mn/XeMtLX/AHYJj/hWRf8A/BHT41xg/wBl+KdEmPbzftMef++Ynx+tOXh1nSV/q7+9f5jn4FcWRV3gpffH/wCSPyFqSKWWGQSwsUZeQynBH0NfpHr3/BKX9rLSFY6fBpOq7egtb0Ln6faEh/XFfP8A4q/Yj/aw8Go8ms+BdTdY+WNmi3oAHf8A0VpeK8rE8K5nR1qYea/7df5nzeYeG/EGE96vgqiXfklb70rfidD+z3+3L8efgBrVu1pq0+t6GrAT6VfytLC0fcRM+5oG9CmBnG5WHFf1D/CH4q+Evjb8OtL+JvgmUy6fqkW9Q3DxupKyRSAZw8bgq3UZGQSCCf4u76wvtLvJNO1KGS3uIWKSRSqUdGHUMrYIPsa+y/2dP2zviB+z34GuPBHhq5KW097JebSu7DSRxocZ6D930r7DgjxCr5c5UcS3KFtE3s/Ly8j9T8IfHLF5DKeFzCTqUbaJvWMrrZvZWvdbXta2t//Q9x0fS7vXNXtdEsADPeTJBGDwC8jBVz+Jr+xX4AfAbwH+zj8N7TwN4Ot44zFGrX15gCS6nC/vJpWPPJztBOEXCjAFfx5+G7XU77xFYWOiyeVeTXMSW75K7ZWcBGyORhsHPav6Dfjx8I/29PD/AMBvEureIPi5a6lZWOl3E95aw6ZBbSS28UZaZFuY4xICUB54LdCRk1/M3hZilho4jFKhKpKKWq5dFq3u1vbonsf58/RxzGOXwx2ZLBTrThFWlHk91Wk2nzSi1zWXwqTstu/pPjb/AIKrfsteENVudI046rrrWztH5un20ZhdlOCUeeWLcuejAEHqMjFeF61/wWV8AwE/8I74I1C6Hb7TdRW//oCTV+X/AOyh+xv8Q/2r9YvF8O3EOlaPpZRbzULgFwrSZKxxRqQZJMAkjKqB95gSoP6m6f8A8EbvhhHYiPVfGOqTXOOZIoYIo8+uxvMOPbf+Ne7l+f8AFmZ0/rGEioweztFfdzXbPssj408TOIKH13LKcIUneztBJ+nO232va3meQat/wWY8WTZ/sPwHaW/p599JN/6DDFXJy/8ABYz4zH/UeFNFX/ea4P8A7UFcV+07/wAEwfHHwP8ABl98SvBGtJ4k0jTUM13E8Jt7qGEfekADOkioOXIKkDnaQCR5F+yN+wt4o/ax0LVvE2na7baJZ6XcJa5lhad5JGTecKrIAACOSeSeleBiM24tWMWBnJ+0eqXuq67p2t+J8Vj+JfE2OaRyirUkq8k2klTSaV9U0lG2nfy3Ppi1/wCCx3xfT/j98JaPJ/uPcJ/N2rsdK/4LN69Fga34At5/Uwai0X6Nbyfzr41+I37C3ir4c/tKeG/2dNQ1+zkfxPHHLa6iUdI1V2kTa8eSQ+6MgAMQcryMnHqX7QP/AATB+IPwN+Fmo/FK18RWuuQaSFlubeOB4ZBCWCs6ks4bZkMwOPlBPbBKWccWxjVmpO1PSWkHayv89O1ww/FHibCGIqwqSaoNqd1SfK0uZ6NO+mul9D7N0H/gsj8Lrgj/AISbwdqtn6/ZZoLnH03+RmvsD4Cft6fs+ftD+Jk8FeD7u6sNYlRnhs9RhELzBAWYRsjyRsyqCSu/dgEgEA4/AL9kj9izxv8AtZTardaLqMGjaZo5jSa6nRpC8suSscaKV3EKuWJYYyOua7P40/sg/Eb9k34veBdG8J+Kbe+17xBeKNNmtle3lt51mijjdwxcBWeQAHJztYEYHPrZXxvxFChDH16anRuk3ZJvW2lmuu2lj6Xhzxe47pYOnnONoqrhHJJu0Ytpy5fds0730T5Wr+R+sX/BTn9nfwx8Q/gbf/FrT7OOPxH4XVLgXKKBJNabgs0UhH3lRT5i5+6VIGAzZ/mdr+if9o34Q/t1WP7PXii48VfFHT9a0+30yefUbRNLgtXltokLzok0aZ5QH+Fd3TIzX87FfN+KqjLHxrKi6blHW9tXd66N+h8D9JGMJ51TxawsqMpwXMpcvvNNq/uSktrJ3d9Fp3//0fefDmpXujeIbDV9Nj824tbiKaJME7nRwyjA5OSMYFf0M/Hv9oP9rzxF+z74p0/WvgpNo1jf6PdRXd++rwT/AGe3khZZpTarEsvyxljgnK9TnFfgJ8MwD8R/D4PT+0rT/wBHLX9d/wC08/l/s1fENx28M6t/6Ry1/NPhngatXBYuUKzgktko66S3un+Fj/P/AOj7lGIxOVZpOjiZ0koq6ioNS92e/NGTXb3XF677W+Ev+CPkUY/Zx1+YAbm8STqT3IFnaYH4ZNeHft/+LPE+k/t7/DCx0vULi3hgg0qVI45GVA8upzpI20HGXVFVvUAA8V7p/wAEff8Ak23Xf+xluP8A0js6+a/+CiAz/wAFAfhqP+nTRv8A063NfT4ybjwthnF9Yf8ApR+hZpUlDw4y9wdvepf+ln7T/GW1jvvg/wCK7KZQyTaPfIwPQhrdwRX5l/8ABHT/AJIx4q/7DQ/9Jo6/T/4rf8ku8Sf9gq8/9EPX5gf8EdP+SMeKv+w0P/SeOvs82X/C/hH/AHan5I/V+Jor/XbK3/07rfkj5r/4KxeI9W8JftP+DPE+hSGG90vSLa7t5B/DLFezujfgyg1+2Ph/VvC37RnwLt9TK7tK8Y6PiVAclUu4SskZ/wBpCzKfQivw4/4LEQsvx48NXHZtBVf++bqc/wBa+u/+CRfxak8U/BvV/hRqEm6fwvdiW3BP/Lre7nCj/dmWUn03j8flMgzZU+JsXganw1PzS/VXPzXgriWNHxAzPJq+sK+y/vRjf8YuV/RH1J+wp8BNS/Z4+Alv4P8AEMYj1e7vbq8vsdC7P5UeD6eTHGfqTX42fHv4u/8AC3v+Ck2h3dpL5un6H4k0rR7TByNtreIJSOxDTmRgR1BFfu3+1N8XB8DfgF4m+JMLBbuztDHZ573U5EMHHcLI4Yj+6DX8qH7PEss/7RPgaedi7v4j0xmZjkkm7jJJPcmuHxDxdPBxweTYfZOLfonZfe7t+aPI8c8xoZXDKuFcFpGMoSfe0Xyxv6vmb80f1d/tQjP7NHxDH/Us6t/6Ry1/G3X9k/7Tgz+zZ8Qh/wBSzq3/AKRy1/GxXk+Nn+9UP8L/ADPmfpc/8jHB/wCCX/pR/9L6X+GX/JSPD/8A2ErT/wBHJX9dP7Uv/Js3xD/7FrVf/SSWv4+/DGrnw/4l0/XgnmmyuYrjYON3luGx+OMV/Rb+0f8AtueF9f8A2efFWkad4L8XW8us6Rc2ay3ukyW9tD9riaLfLMzFQqh85Gc4wOua/mvwzzXD4fA4yNaVm1p90j+Afo+8SYHA5RmlPFVFFyirb6+7PyKH/BHx1P7N+vRg8jxLcEj62dn/AIV85f8ABQlGb/goN8MlA+9baKB/4NbivnP9gf8Abf0X9lttW8I+PbC4vdA1iZLkS2m1predV2M2x2UOjrt3fMCNowDnFfqc/wC1p/wTs+MPjXQfGvijUbNvEOkyINPn1GzuYnt33hkzKY/JAV/mUs5VGywIPNe9lWPwWYZFQwHt4wnFxupO2z/G62sfZ8OZ1lGecG4TJvrlOlWpyhdTly/DO+l97rVWv2dj7p+LLpH8K/E0khCqulXpJPAAED1+YX/BHT/kjHir/sND/wBJo6/Q39pDw3478cfAXxT4S+Fz2/8AbOrafJa25uH2RlJsJKN4BwxhLhCeAxUkgc1+Gn/BPD9tH4T/ALNXhHxD4P8Aigl6n2+8jvLeW1hEyn92I3VhuBBG1SDgg5PTHP1fEmZ0cLnuEqYh8sOWfvPa76X/AK3R+k8fcQ4bL+Mstr46Xs6ap1ffekbtbX7qyv6rubn/AAWK/wCS2eFv+wH/AO3Mtch/wSP8RXGl/tL3+hq37nVNEuEZf9uKWGRT9QAw/E15L/wUA/aY8CftOfFPSvEvw7hu47DTNNWzL3aLG8knmySEqqs/ygMACSCTngDGeQ/Ye+Pngr9nD45J8RfHttdXNgbGe0/0NUeVHlKYfa7oCoCkH5s85APSvyCvnOH/ANafrkZrk5173S1kmfy7jeKsF/xEVZrTrL2PtU+fpayTfpufsj/wVzvprT9l+wt4jhbrxBaRP7gW9zJj80Br8Ev2c/8Ak4TwJ/2MWl/+lcVfop/wUI/bi+Dn7R/ws0n4d/DKK/kmt9Uj1Gae5hEMarFBNEEA3FmYmbPTAA681+YHwv8AE3/CF/Evw74x8h7r+ydTtL3yY/vyeRMkmxfdtuB7mlx9m+HxGeRr0ZqUFy6rbTcXjVxRgcdxfTxmEqqdOPs9VqtHd/0j+u79pv8A5Nt+IX/Ytat/6Ry1/GvX9J/7Sf7cHhPUP2ffFOk2vg7xbay61pNzYRy3+kyWtvEbyJoQ8kzttAXfnjOTwOua/mwr0vF/M6GJxVH2Er2i/wAz3vpRcQ4LH5jhXg6ilywd7eb0P//T968N6v8A8I/4isNe8sS/YbmK42Ho3lOHwfrjFf2i+G/EPgv4w/D238QaO8Wp6F4gs8jOGSWGddro47HBKup5ByDyK/iklikglaGUbWQlSD2I6ivoP4KftVfHf9n3db/DHXpbWykfzJLGZVntXbufKkDBSe7JtY8c8V/Jvh9xrTyipUhiIOUJ2vbdWv0e++p/md4I+LVHhmtWpY2m50atr2tdNX6Oyaabur9vR/qT8QP+CN4n1W4vfhj4yWC0kYtDaajbFmjBPCmeN/mx0z5QP1r511v/AIJH/tO6azHTL3QtRQfd8q6mRiPcSwIAfxNdb4Y/4LDfG+w2p4s8N6NqSL1MHn2rn6kySrn6KPpXuOi/8FmtAlwviLwDcQerW2oLN+QeCP8AnX1MocF4l35nTb/xf5NH6PUo+E+Pbmpyot9P3i/ScV+R4FZfsq/8FRvCvh9vB3h+/wBR/ssRGBbaHXIRCIiNpRFknXYuD0AFfO0//BOH9tC3ba/gpz/u31g38rk1+pNl/wAFiPgQ+P7R8M69F6+WtrJ/OdK2P+HwX7NP/QD8Tf8AgLZf/Jta18h4XrJc2Nk0tryWn3xN8XwZ4dYqMVUzeo1HRJzTsvK9PQ/Kq2/4JrftoXGC3g8Rg931DTx+guCf0rqtL/4JafteX7AXWl2FiPWe+hP/AKKMlfpX/wAPgv2af+gH4m/8BbL/AOTaw9T/AOCxXwNiz/Y3hjXbj084W0P/AKDNJWK4Z4RhrLFt/NfpE5o+H3hhSXNPMpy/7eX6U7nyHoP/AAR9+P8AesG8Q+INCsUPURyXE7j8PJRf/Hq+2P2ZP+CXnh34H/EfT/ij4y8RnxBe6UxltbWO1EECTbSqyOzSSM5TO5cBMMAecYrxXW/+CzdmoKeHPh+7+j3Oohcf8AS3bP8A30K8D8Zf8Fdv2htbie28JaVo+hq3SQRSXMy/QyP5f5xmujD4rg7A1FWpXnKOq+J6r1sjtwGY+FeT1o4rD81WpBprSo9VqtHyxfz0P1L/AOCkPxX0j4a/sua5pFxKo1HxMo0uzhJG5xIQZ2x1wkO7J6Bio7iv5W69I+KHxf8AiX8afEZ8V/FDWLjWL7bsR5iAsaZztjjQKka552ooGa4mz0jU9QiM1lA0ig7SVHf0/Wvzzjjin+18Z7eEbRSsl173f3n4d4weI/8ArPmqxdKDjTjHlinva7bbt1bf3WP/1P0n/bl/Z71r4AfHjVrRrdl0PW55b/SpwP3bQytvaIHpugZthHXG1sYYZ+OK/tP+Kvwh+HXxs8JS+CfibpcWqafKdwV8q8bjpJFIpDxuP7ykHGQcgkH+Yb9s79nTwN+z58QLnw14IuL2e2QqV+2SRyMN3OMpHHwO1fyt4h8DvLqzxNKS9nNtpdV5enb+r/5veOng+8ixcsfhpp0ajbUdeaL3a2s0r6O97aNaXfxTRRRX5gfzwFFFFABRRRQAUUVpaRZxX+pwWUxIWRgpK9fw600r6DiruxnAEnA5Jr+kb9iL9h7wz4f+A1ne/GjSBJresTvqBhlysltDIqLFE47NtTewOCpcqRkGj9h39iL4DeH/AAxpPxovbOfWNbkAlhOoOssNs6nhoolRF3DqGcOVPKkGv1Rr+gfDvw6p+z+u41qSktF283trof274FeBWHeHebZs1UVRWjFXslfVt2Wulklpa+rvp//Z",
            "sharePlatform": [0, 1]
        };
        toshare(JSON.stringify(obj));
    })
}

function notifyJSEvent(key, params) {
    getTransferData("login_key");
    if (getIsLogined()) {
        if (getEAcct() != '' || getEAcct() != null || getEAcct() != undefined) {
            if (!getStorage('isFirstLog', getMobile())) {
                setStorage('isFirstLog', '0', getMobile());
            }
        }
    }
    if (key == "SH_LOGIN_STATUS_CHANGE") {
        if (params == "1") {
            getm(function () {
                window.location.reload();
            });
            //登录成功
            if (document.getElementById('title').innerHTML == '我的') {
                window.location.href = 'personalIndex.html';
            }
        }
    }
}

$("#QRC").on("click", function () {
    if (getIsLogined()) {
        var phone = getMobile();
        createQRC(phone)
    } else {
        startToLogin();
    }
});

$("#share").bind("click", function () {
    try {
        var UMSAObject = getUMSAObject();
        UMSAObject["eventDesc"] = "好友分享";
        postEventActivityJsonUMSA("event_iqy0003", 'aiQiYiNew.html', UMSAObject);
    } catch (e) {
        Alert(e.message);
    }
    if (getIsLogined()) {
        shareWX();
    } else {
        startToLogin();
    }
});

$("#rule").on("click", function () {
    $("#mask").show();
    $(".main").css("overflow", "hidden");
});
$("#know").click(function () {
    $("#mask").hide();
    $(".main").css("overflow", "auto");
});
$("#vip_day").on("click", function () {
    if (getIsLogined()) {
        window.location.href = 'myQYCenter.html';
    } else {
        startToLogin();
    }
});
$("#shback").on("click", function () {
    window.history.go(-1);
});
isgoback(true);

function onBackPressed() {
    window.history.go(-1);
}