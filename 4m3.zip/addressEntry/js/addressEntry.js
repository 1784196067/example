$(function () {
    setTimeout(function () {
        iosbox();
        getTransferData("login_key");
        getInformation()//获取用户信息
        loadDate();//加载mobilescroll插件
    }, 100)
})
var addFlag = "";
//    点击跳转新增地址页面
$("#add").click(function () {
    if (addFlag == 1) {
        return
    }
    if ($(".addressEntry>div").length > 2) {
        alert("地址列表已满，请您尝试删除后添加新地址");
        return;
    }
    var datas = {};
    datas["addressId"] = " ";
    datas["eaccount"] = eaccount
    window.location.href = "addAddress.html?txt$" + JSON.stringify(datas);
});

function loadDate() {
    $("#date").mobiscroll().date({
        theme: "mobiscroll",
        lang: "zh",
        minDate:new Date(2015, 6, 1),
        onShow:function () {
            // if (/iphone|ipad|ipod/.test(ua)) {
            //     $(".dwwr").css("bottom", "50px");
            // }
        },
        cancelText: "取消",
        dateFormat: 'yy/mm/dd', //返回结果格式化为年月格式
        headerText: function (valueText) { //自定义弹出框头部格式
            return '日期选择';
        }
    });
    $("#date2").mobiscroll().date({
        theme: "mobiscroll",
        lang: "zh",
        cancelText: "取消",
        minDate:new Date(2015, 6, 1),
        dateFormat: 'yy/mm/dd', //返回结果格式化为年月格式
        onShow:function () {
            // if (/iphone|ipad|ipod/.test(ua)) {
            //     $(".dwwr").css("bottom", "50px");
            // }
        },
        headerText: function (valueText) { //自定义弹出框头部格式
            return '日期选择';
        }
    });
}
/*
 获取用户信息
 */
function getInformation() {
    var jsonObject = getJsonObject();
    //请求参数追加自定义参数
    jsonObject["method"] = "dbk.account.queryEpayrollInfo";
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.account.queryEpayrollInfo";
    $.ajax({
        type: "POST",
        url: address,
        data: jsonObject2,
        dataType: "json",
        timeout: requestTimeOut,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var data = secondaryde(data1);
            if (data.retCode == "000000") {
                $("#name").text(data.name);
                $("#eaccount").text(data.eaccount);
                $("#phone").text(data.phone);
                eaccount = data.eaccount
                companyname = data.companyname;
                if (data.list == undefined) {
                    return;
                } else {
                    $(".foot").attr("disabled", false).css("background", "#17b4eb");
                    var address = data.list;
                    getUserAddress(address)
                }

            } else if (data.retCode == "Login9999") {
                logout();

                doKickOutAction("", "");
            } else if (data.retCode == "Login9998") {
                logout();

                logout1("home");
            } else {
                addFlag = 1;
                alert(data.retMsg);
                dissmissLoding();
            }
        },
        error: function () {
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}//获取用户信息结束
function getUserAddress(listData) {
    if (listData.length > 0) {
        var userAddress = '';
        $.each(listData, function (index, item) {
            userAddress += "<div id=" + item.addressid + ">" +
                "<ul><li><ul class='address clearfix'>" +
                "<li class='left select'><img class='selectImg' src='img/circlegrey.png'></li>" +
                "<li class='left'><table><tr><td>" +
                "<p><span class='province'>" + item.province + "</span><span class='city'>" + item.city + "</span><span class='area'>" + item.area + "</span><span class='street'>" + item.street + "</span></p>" +
                "<p><span>邮编:</span><span class='postcode'>" + item.postcode + "</span></p>" +
                "</td></tr></table></li></ul></li>" +
                "<li class='option'>" +
                "<span class='edit'><img src='img/edit.png' alt=''>编辑</span>" +
                "<span class='delete'><img src='img/delete.png' alt=''>删除</span>" +
                "</li></ul></div>"
        })
        $(".addressEntry").html(userAddress)
    }
    $(".edit").click(function () {
        var editAddressId = $(this).parent().parent().parent().attr('id');
        var province = $(this).parent().parent().find(".province").text();
        var city = $(this).parent().parent().find(".city").text();
        var area = $(this).parent().parent().find(".area").text();
        var street = $(this).parent().parent().find(".street").text();
        var postcode = $(this).parent().parent().find(".postcode").text()
        var datas = {};
        datas["addressId"] = editAddressId;
        datas["eaccount"] = eaccount;
        datas["province"] = province;
        datas["city"] = city;
        datas["area"] = area;
        datas["street"] = street;
        datas["postcode"] = postcode;
        window.location.href = "addAddress.html?txt$" + JSON.stringify(datas);
    });
    $(".delete").click(function () {
        var confirm = window.confirm("您确定要删除该地址吗?");
        if (confirm) {
            var deleteAddressId = $(this).parent().parent().parent().attr('id');
            $(this).parent().parent().parent().remove();
            deleteAddress(deleteAddressId)
        }

    });
    $('.select').on('click', getSelect);
    $(".foot").on('click', isSelect);
}
function deleteAddress(deleteAddressId) {
    var jsonObject = getJsonObject();
    //请求参数追加自定义参数
    jsonObject["method"] = "dbk.account.deletePostAddress";
    jsonObject["addressid"] = deleteAddressId;
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.account.deletePostAddress";
    $.ajax({
        type: "POST",
        url: address,
        data: jsonObject2,
        dataType: "json",
        timeout: requestTimeOut,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var data = secondaryde(data1);
//                alert("返回数据+" + JSON.stringify(data));
            if (data.retCode == "000000") {
                alert("删除成功")
            } else if (data.retCode == "Login9999") {
                logout();

                doKickOutAction("", "");
            } else if (data.retCode == "Login9998") {
                logout();

                logout1("home");
            } else {
                alert(data.retMsg);
                dissmissLoding();
            }
        },
        error: function () {
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}
function addressApplication(applyAddressId) {
    var time1 = $("#date").val().replace('/', '').replace('/', '');
    var time2 = $("#date2").val().replace('/', '').replace('/', '');
    var startTime=20150700;
    if (time1 == "") {
        alert("起始时间不能为空");
        return;
    }
    if (parseInt(time1)<startTime ) {
        alert("起始时间不能小于2015年7月");
        return;
    }
    if (time2 == "") {
        alert("结束时间不能为空");
        return;
    }
    if (time1 > time2) {
        alert("起始时间不能大于结束时间");
        return;
    }
    if ((parseInt(time2) - parseInt(time1)) > 30000) {
        alert("时间区间超过3年，请重新选择");
        return;
    }
    var jsonObject = getJsonObject();
    //请求参数追加自定义参数
    jsonObject["method"] = "dbk.account.postSalaryApply";
    jsonObject["addressid"] = applyAddressId;
    jsonObject["companyname"] = companyname;
    jsonObject["begindate"] = time1;
    jsonObject["enddate"] = time2;
    jsonObject["eaccount"] = eaccount;
//        alert("返回数据+" + JSON.stringify(jsonObject));
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.account.postSalaryApply";
    $.ajax({
        type: "POST",
        url: address,
        data: jsonObject2,
        dataType: "json",
        timeout: requestTimeOut,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var data = secondaryde(data1);
//                alert("返回数据+" + JSON.stringify(data));
            if (data.retCode == "000000") {
                alert("申请成功")
            } else if (data.retCode == "Login9999") {
                logout();

                doKickOutAction("", "");
            } else if (data.retCode == "Login9998") {
                logout();

                logout1("home");
            } else {
                alert(data.retMsg);
                dissmissLoding();
            }
        },
        error: function () {
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}
function getSelect() {
    $(".addressEntry").find(".selectImg").attr('src', 'img/circlegrey.png');
    $(".select").removeClass("selected");
    $(this).find(".selectImg").attr('src', 'img/circle.png');
    $(this).addClass("selected")
}
function isSelect() {
    if ($(".select").hasClass("selected")) {
        var applyAddressId = $(".selected").parent().parent().parent().parent().attr('id');
        addressApplication(applyAddressId)
    } else {
        alert("请选择地址")
    }
}
