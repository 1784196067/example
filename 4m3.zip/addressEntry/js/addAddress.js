$(function () {
    setTimeout(function () {
        iosbox();
        // if (/iphone|ipad|ipod/.test(ua)) {
        //     $(".foot").css("bottom", "49px");
        // }
        getTransferData("login_key");

        getParameter()//获取url传参
        var addressId = dat["addressId"];
        if (addressId != " ") {
            $("header h2").text("修改地址");
        }
        getAddress();
        $(".foot").click(function () {
            var city = $("#demo1").val();
            var street = $("#street").val();
            var postcode = $("#postcode").val();
            var z = /^[0-9]*$/;
            if (city == "") {
                alert("请选择邮寄城市");
                return;
            }
            if (street == "") {
                alert("请输入邮寄街道");
                return;
            }
            if (z.test(street)) {
                alert("地址不能为纯数字");
                return;
            }
            if (postcode.length != 6) {
                alert("请输入正确的邮编");
                return;
            }
            if (postcode == "") {
                alert("请输入邮编");
                return;
            }
            if (addressId != " ") {
                editAddress();//调用修改地址接口
            } else {
                addAddress();//调用添加地址接口
            }
        })
    }, 100)
});
function getParameter() {
    var Request = new Object();
    Request = GetRequest();
    fo = (Request["txt"]);
    dat = JSON.parse(fo);
    return dat;
}
function getAddress() {
    var jsonObject = getJsonObject();
    //请求参数追加自定义参数
    jsonObject["method"] = "dbk.account.queryAllDistrict";
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.account.queryAllDistrict";
    $.ajax({
        type: "POST",
        url: address,
        data: jsonObject2,
        dataType: "json",
        timeout: requestTimeOut,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var data = secondaryde(data1);
//                alert("返回数据+" + JSON.stringify(data));
            if (data.retCode == "000000") {
                var areaList = data.areaList;
                //加载地址插件
                var Area = new lArea();
                Area.init({
                    'trigger': '#demo1',
                    'data': areaList//'js/AreaData.json'
                });
                getParameter();
                var addressId = dat["addressId"];
                if (addressId != " ") {
                    province = dat["province"];
                    city = dat["city"];
                    area = dat["area"];
                    street = dat["street"];
                    postcode = dat["postcode"];
                    $("#demo1").val(province + " " + city + " " + area)
                    $("#street").text(street);
                    $("#postcode").val(postcode)
                }
            } else if (data.retCode == "Login9999") {
                logout();

                doKickOutAction("", "");
            } else if (data.retCode == "Login9998") {
                logout();

                logout1("home");
            } else {
                alert(data.retMsg);
                dissmissLoding();
            }
        },
        error: function () {
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}//获取用户信息结束
function addAddress() {
    var street = $("#street").val();
    var postcode = $("#postcode").val();
    var jsonObject = getJsonObject();
    getParameter()
    var eaccount = dat["eaccount"];
    //请求参数追加自定义参数
    jsonObject["method"] = "dbk.account.addPostAddress";
    jsonObject["eaccount"] = eaccount;
    jsonObject["province"] = province;
    jsonObject["city"] = city;
    jsonObject["area"] = area;
    jsonObject["street"] = street;
    jsonObject["postcode"] = postcode;
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.account.addPostAddress";
    $.ajax({
        type: "POST",
        url: address,
        data: jsonObject2,
        dataType: "json",
        timeout: requestTimeOut,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var data = secondaryde(data1);
            if (data.retCode == "000000") {
                alert('添加成功')
                setTimeout(function () {
                    window.location.href = "addressEntry.html"
                }, 2000)
            } else if (data.retCode == "Login9999") {
                logout();

                doKickOutAction("", "");
            } else if (data.retCode == "Login9998") {
                logout();

                logout1("home");
            } else {
                alert(data.retMsg);
                dissmissLoding();
            }
        },
        error: function () {
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}
function editAddress() {
    street = $("#street").val();
    var postcode = $("#postcode").val();
    var jsonObject = getJsonObject();
    getParameter()
    var addressid = dat["addressId"];
    var eaccount = dat["eaccount"];
    //请求参数追加自定义参数
    jsonObject["method"] = "dbk.account.updatePostAddress";
    jsonObject["addressid"] = addressid;
    jsonObject["eaccount"] = eaccount;
    jsonObject["province"] = province;
    jsonObject["city"] = city;
    jsonObject["area"] = area;
    jsonObject["street"] = street;
    jsonObject["postcode"] = postcode;
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.account.updatePostAddress";
    $.ajax({
        type: "POST",
        url: address,
        data: jsonObject2,
        dataType: "json",
        timeout: requestTimeOut,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var data = secondaryde(data1);
//                alert("返回数据+" + JSON.stringify(data));
            if (data.retCode == "000000") {
                alert('修改成功');
                setTimeout(function () {
                    window.location.href = "addressEntry.html"
                }, 2000)
            } else if (data.retCode == "Login9999") {
                logout();

                doKickOutAction("", "");
            } else if (data.retCode == "Login9998") {
                logout();

                logout1("home");
            } else {
                alert(data.retMsg);
                dissmissLoding();
            }
        },
        error: function () {
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}
