var bankno="";//银行卡号 直接从获取的元素内容
var bankno01;// 接收从sessionStorage 里面得到的卡号
var change="";
var fromtyoe="";
var bankCard = "";
var type = "";
var seltype = "";
var msg={};//带到下一个页面的数据
$(function(){
    setTimeout(function(){
        IsNeedClear();
        getTransferData("login_key");
        //此处存储 卡号的目的是 当点击 支持卡列表跳转页面时 再返回时 卡号依然存在
        bankno01=sessionStorage.getItem('bankMy');
        if(bankno01){
            $("#bankCard").val(bankno01);
            if (luhmCheck(bankno01)) {
                //获取卡信息；
                getBankType(bankno01);
            }
            $("#nextStepBtn").removeClass('unclick');
        }
    },100);
});

var Request = new Object(1);
Request = GetRequest();
var fo = (Request["txt"]);
var dat ="";
var bank = "";
if(fo==""||fo==undefined||fo=="undefined"){
    dat["cardNo"]="";
}else {
    //更换绑定卡 fo有值 进入此逻辑
    dat=JSON.parse(fo);//{'frommycard':'1','chgBindCard':'1'}
    fromtyoe= dat["from"];//undefined
}
if(dat["chgBindCard"]=="1"){//更换绑定卡  进入此逻辑
    change="1";
}

if (fromtyoe=="1"){


}else {
    if(dat.cardNo!=""){
        $('#bankCard').val(dat.cardNo);
    }
}

//获取验证码
$("#getCode").click(function () {
    phone_num = $("#phone_num").val();
    var reg01 = /^[1][3,4,5,6,7,8,9][0-9]{9}$/;
    if(phone_num == ''){
        tipsError("请输入预留手机号");
    }else if(!(reg01.test(phone_num))){
        tipsError("手机号格式不正确");
    }else{
        $("#getCode").attr("disabled", true);
        var count_down = parseInt(60);
        $("#getCode").val("60S");
        $("#getCode").css("color", "#999");
        var time = setInterval(function () {
            count_down--;
            $("#getCode").val(count_down + "S");
            if (count_down < 0) {
                clearInterval(time);
                $("#getCode").val("重新发送");
                $("#getCode").css("color", "#1673d0");
                $("#getCode").attr("disabled", false);
            }
        }, 1000);
        //获取验证码
        getCode();
    }
});

//获取验证码
function getCode() {
    msgCodeEvent('点击发送验证码-更换绑定卡','changeBindCard.html','1');
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.auth.shortMsgLoginCheck";
    //请求参数追加自定义参数
    jsonObject["sendType"] = "0";
    jsonObject["queryEacctFlag"] = "0";
    jsonObject["mobile"] = phone_num;
    // jsonObject["schFlag"] = "1";
    var jsonObject2 =secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.auth.shortMsgLoginCheck";
    getForData(jsonObject2,function(data){
        if (isBeta) {
            $("#codeNo").val(data.dymcode);
            focusAnimation('#codeNo')
        }
        tipsWell(data.retMsg);
    });
}
//验证什么银行的卡
$("#bankCard").blur(function (e) {
    //获取卡号
    bankno = this.value;
    msg.bankno = bankno ;
    if (bankno == "") {
        return;
    }
    if (luhmCheck(bankno)) {
        //获取卡信息；
        getBankType(bankno);
    }
    $("#nextStepBtn").removeClass('unclick');
});

//获取银行卡信息
function getBankType(bankno) {
    var jsonObject = getJsonObject();
    //请求参数追加自定义参数
    jsonObject["method"] = "dbk.account.getBindCardInfo";
    jsonObject["userId"] = getMid();
    jsonObject["cardNo"] = bankno;
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.account.getBindCardInfo";
    getForData(jsonObject2, function (data) {
        banks = data;
        $("#singleLimit").text(moneyOfFormat2(data.singlePenLimit));
        $("#dayLimit").text(moneyOfFormat2(data.dayTopLimit));
        $("#bankName").text(data.bankName);
        msg.bankName = data.bankName ;
        $("#bankType").text(data.card);
        $("#bankIcon").attr('src', checkCard(data.bankNo).icon);
        $(".card-info").show();
    });
}

//支持银行卡列表
$("#direct").click(function () {
    bankno = $("#bankCard").val();
    if(bankno){
        sessionStorage.setItem('bankMy',bankno);
    }
    localStorage.setItem("title", "可直接支付的银行卡");
    localStorage.setItem("url", "?method=dbk.statical.onlinepaybank");
    window.location.href = "../openAccent/bang_bank_list_canpay.html";
});

//点击下一步
$("#nextStepBtn").click(function () {
    var reg01 = /^[1][3,4,5,6,7,8,9][0-9]{9}$/;
    //验证码
    var val_get = $("#codeNo").val();
    //银行卡预留手机号
    var val = $("#phone_num").val();
    bankno = $("#bankCard").val();
    msg.bankno = bankno ;
    if(bankno === ''){
        tipsError("银行卡号不能为空");
        return;
    }
    if (!luhmCheck(bankno)) {
        return;
    }
    if (val == null || val == "") {
        tipsError("手机号不能为空");
        return;
    }else if(!(reg01.test(val)) ){
        tipsError("手机号格式错误");
    } else if (val_get == null || val_get == "") {
        tipsError("短信验证码不能为空");
        return;
    }else if(val_get.length < 6){
        tipsError("请输入正确的6位验证码");
        return;
    }else {
        msgCodeEvent('提交验证码-更换绑定卡','changeBindCard.html','2');
        var jsonObject = getJsonObject();
        jsonObject["appVersion"]="5.0.1";
        //请求参数追加自定义参数
        jsonObject["method"] = "dbk.account.validateMobileDymCode";//先验证短信验证码
        jsonObject["dymCode"] = val_get;
        jsonObject["cardNo"] = bankno;
        jsonObject["mobile"] = val;
        if (change == "1") {
           //更换绑定卡 进入此逻辑
            jsonObject["valType"] = "1";
        } else {
            jsonObject["valType"] = "0";
        }
        var jsonObject2 = secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.account.validateMobileDymCode";
        getForData(jsonObject2, function (data) {
            type = data.authStatus;
            if (dat.cardBankType != "02") {
                //更换绑定卡 进入此逻辑
                if (type == "1") {//当type值为 1时
                    if (dat.typefrom == "1") {
                        setIsBind("01");
                        var iosdata = {};
                        iosdata["isBindedCard"] = "01";
                        updateUserInfo(JSON.stringify(iosdata));
                        setTransferData();
                        data["fr"] = 1;
                        window.location.href = 'changeCardResult.html?txt$' + JSON.stringify(msg);
                    } else {
                        //更换绑定卡  进入此逻辑
                        goSelf();
                    }
                } else {
                    Alert(data.retMsg);
                }
            } else {
                if (type == "1") {
                    if (dat.typefrom == "1") {
                        dissmissLoding();
                        setIsBind("01");
                        var iosdata = {};
                        iosdata["isBindedCard"] = "01";
                        updateUserInfo(JSON.stringify(iosdata));
                        setTransferData();
                        data["fr"] = 1;
                        window.location.href = 'changeCardResult.html?txt$' + JSON.stringify(msg);
                    } else {
                        seltype = data.bankNoLeve;
                        goOther();
                    }
                } else {
                    dissmissLoding();
                    Alert(data.retMsg);
                }
            }
        });
    }
});

function goSelf() {
    // var pwd = $('#pwd').val();
    // var pwdEncry = getEncryptNum(true, pwd);
    var jsonObject = getJsonObject();
    //请求参数追加自定义参数
    if (change == "1") {
        jsonObject["method"] = "dbk.account.changeBindCard";
    } else {
        jsonObject["method"] = "dbk.account.eacctBindCard";
    }
    jsonObject["userId"] = getMid();
    jsonObject["cardNo"] = $("#bankCard").val();
    jsonObject["mobilePhone"] = $("#phone_num").val();
    jsonObject["authStatus"] = type;
    jsonObject["bankNoLeve"] = '1';

    jsonObject["bankType"] = dat.cardBankType;
    // jsonObject["pwd"] = pwdEncry;
    var jsonObject2 = secondaryIndilling(jsonObject);
    if (change == "1") {
        jsonObject2["method"] = "dbk.account.changeBindCard";
    } else {
        jsonObject2["method"] = "dbk.account.eacctBindCard";
    }
    $.ajax({
        type: "POST",
        url: address,
        dataType: 'json',
        timeout: requestTimeOut,

        data: jsonObject2,
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var data = secondaryde(data1);
            if (data.retCode == '000000') {
                dissmissLoding();
                setIsBind("01");
                var iosdata = {};
                iosdata["isBindedCard"] = "01";
                updateUserInfo(JSON.stringify(iosdata));
                setTransferData();
                localStorage.removeItem('firstIn');
                window.location.href = 'changeCardResult.html?txt$' +JSON.stringify(msg);
            }
            else if (data.retCode == "E888888051") {
                showPopAffirm("温馨提示", "交易失败，请您进行交易认证。", "取消", "交易认证");
                $(".confirm").click(function () {
                    setTimeout(function () {
                        var jsonObject = getJsonObject();
                        jsonObject["busType"] = "2";
                        jsonObject["userId"] = getMid();
                        var methodString = "dbk.account.getIdConfirmSwitch";
                        jsonObject["method"] = methodString;
                        var jsonObject2 = secondaryIndilling(jsonObject);
                        jsonObject2["method"] = methodString;
                        $.ajax({
                            type: "POST",
                            url: address,
                            dataType: "json",
                            data: jsonObject2,
                            contentType: "application/x-www-form-urlencoded;charset=utf-8",
                            beforeSend: function () {
                                showLoding();
                            },
                            success: function (data) {
                                dissmissLoding();
                                var selectData = secondaryde(data);
                                if (selectData != null && selectData.retCode == "000000") {
                                    // 重置该交易密码
                                    var isSwitchAlive = selectData.ID_Confirm_SW_Trade_Face_Switch;
                                    var isSwitchManual = selectData.ID_Confirm_SW_Trade_Labour_Switch;
                                    var isInManualAudit = selectData.isValidate; // 01审核中,02未审核
                                    if (isSwitchAlive == "0" && isSwitchManual == "0") {
                                        // alert("功能正在维护中，请联系我行客服95594");
                                        tipsError("功能正在维护中，请联系我行客服95594");
                                    } else if (isInManualAudit == '01') {
                                        // alert("正在人工审核中，预计需要两个工作日");
                                        tipsError("正在人工审核中，预计需要两个工作日");
                                    } else {
                                        var busType = "2";
                                        var dict = {};
                                        dict.busType = busType;
                                        dict.backHtmlPage = '../../openAccent/bankChecked.html';
                                        window.location.href = "../aliveIdentification/HTML/tradeCertification.html?txt$" + JSON.stringify(dict);
                                    }
                                }else if (selectData.retCode == "Login9999") {
                                    logout();
                                    doKickOutAction("", "");
                                }else if (selectData.retCode == "Login9998") {
                                    logout();
                                    logout1("home");
                                }else {
                                    Alert(selectData.retMsg);
                                }
                            },
                            error: function () {
                                requestFailTips();
                            },
                            complete: function () {
                                dissmissLoding();
                            }
                        });
                    }, 100);

                });
            }
            else if (data.retCode == "Login9999") {
                logout();

                doKickOutAction("", "");
            } else if (data.retCode == "Login9998") {
                logout();

                logout1("home");
            } else {
                dissmissLoding();
                Alert(data.retMsg);//当总资产不为0时 提示'总资产'不为0元，请您赎回所有投资并将e账户中的资金转回原绑定卡。
            }
        },
        error: function () {
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}

function goOther() {
    var jsonObject = getJsonObject();
    //请求参数追加自定义参数
    if (change == "1") {
        //更换绑定卡 进入此逻辑
        jsonObject["method"] = "dbk.account.changeBindCard";
    } else {
        jsonObject["method"] = "dbk.account.eacctBindCard";
    }
    jsonObject["userId"] = getMid();
    jsonObject["mobilePhone"] = $("#phone_num").val();
    jsonObject["authStatus"] = type;
    jsonObject["cardNo"] = bankno;
    jsonObject["bankType"] = dat.cardBankType;
    jsonObject["bankNoLeve"] = '1';
    var jsonObject2 = secondaryIndilling(jsonObject);
    if (change == "1") {
        //更换绑定卡 进入此逻辑
        jsonObject2["method"] = "dbk.account.changeBindCard";
    } else {
        jsonObject2["method"] = "dbk.account.eacctBindCard";
    }
    $.ajax({
        type: "POST",
        url: address,
        data: jsonObject2,
        dataType: "json",
        timeout: requestTimeOut,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        beforeSend: function () {
            showLoding();
            isgoback(false);
        },
        success: function (data1) {
            var data = secondaryde(data1);
            if (data.retCode == '000000') {
                dissmissLoding();
                isgoback(true);
                setIsBind("01");
                var iosdata = {};
                iosdata["isBindedCard"] = "01";
                updateUserInfo(JSON.stringify(iosdata));
                setTransferData();
                localStorage.removeItem('firstIn');
                window.location.href = 'changeCardResult.html?txt$' + JSON.stringify(msg);
            }else if (data.retCode == "E888888051") {
                showPopAffirm("温馨提示", "交易失败，请您进行交易认证。", "取消", "交易认证");
                $(".confirm").click(function () {
                    setTimeout(function () {
                        var jsonObject = getJsonObject();
                        jsonObject["busType"] = "2";
                        jsonObject["userId"] = getMid();
                        var methodString = "dbk.account.getIdConfirmSwitch";
                        jsonObject["method"] = methodString;
                        var jsonObject2 = secondaryIndilling(jsonObject);
                        jsonObject2["method"] = methodString;
                        $.ajax({
                            type: "POST",
                            url: address,
                            dataType: "json",
                            data: jsonObject2,
                            contentType: "application/x-www-form-urlencoded;charset=utf-8",
                            beforeSend: function () {
                                showLoding();
                            },
                            success: function (data) {
                                dissmissLoding();
                                var selectData = secondaryde(data);
                                if (selectData != null && selectData.retCode == "000000") {
                                    // 重置该交易密码
                                    var isSwitchAlive = selectData.ID_Confirm_SW_Trade_Face_Switch;
                                    var isSwitchManual = selectData.ID_Confirm_SW_Trade_Labour_Switch;
                                    var isInManualAudit = selectData.isValidate; // 01审核中,02未审核
                                    if (isSwitchAlive == "0" && isSwitchManual == "0") {
                                        // alert("功能正在维护中，请联系我行客服95594");
                                        tipsError("功能正在维护中，请联系我行客服95594");
                                    } else if (isInManualAudit == '01') {
                                        // alert("正在人工审核中，预计需要两个工作日");
                                        tipsError("正在人工审核中，预计需要两个工作日");
                                    } else {
                                        var busType = "2";
                                        var dict = {};
                                        dict.busType = busType;
                                        dict.backHtmlPage = '../../openAccent/bankChecked.html';
                                        window.location.href = "../aliveIdentification/HTML/tradeCertification.html?txt$" + JSON.stringify(dict);
                                    }
                                }else if (selectData.retCode == "Login9999") {
                                    logout();
                                    doKickOutAction("", "");
                                }else if (selectData.retCode == "Login9998") {
                                    logout();
                                    logout1("home");

                                }else {
                                    Alert(selectData.retMsg);
                                }
                            },
                            error: function () {
                                requestFailTips();
                            },
                            complete: function () {
                                dissmissLoding();
                            }
                        });
                    }, 100);

                });
            }else if (data.retCode == "Login9999") {
                logout();

                doKickOutAction("", "");
            }else if (data.retCode == "Login9998") {
                logout();

                logout1("home");
            } else {
                Alert(data.retMsg);
            }
        },
        error: function () {
            dissmissLoding();
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}
//当输入交易密码的时候
$('.password').keyup(function (event) {
    var number = $('.password').val();
    if (!/^[0-9]*$/.test(number)) {
        if ($('.password').length > 1) {
            var num = number.substr((number.length - 1), number.length);
            if (num != ".") {
                $('.password').val($('.password').val().substring(0, $('.password').val().length - 1));
                return;
            } else {
                if (number.match(/\./g).length > 1) {
                    $('.password').val($('.password').val().substring(0, $('.password').val().length - 1));
                    return;
                }
            }
        } else {
            $('.password').val($('.password').val().substring(0, $('.password').val().length - 1));
            return;
        }
    } else {
        return;
    }
});
screenshot(true);
isgoback(true);
function onBackPressed(){
    window.history.go(-1);
}