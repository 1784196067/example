/**
 * Created by wym on 2016/7/19.
 */
var list = [];
var li = "";
var addList = [];
var Request, txt, dataSign, bzjflag, suc, from;
var phone = "";
isNull();
Request = GetRequest();
txt = (Request["txt"]);
dataSign = JSON.parse(txt);
var canGoBack = true;

var year = new Date().getFullYear();
var month = new Date().getMonth();
var day = new Date().getDate();
var dateList = [];
var monthGroup = [];

$(function () {
    setTimeout(function () {
        try {
            IsNeedClear();
            getTransferData("login_key");
        } catch (e) {
            alert(e.message);
        }
        initWebData();
    }, 100)
});

//删除出游人
$(".user-info span.del").click(function () {
    $(this).closest("p").remove();
    if ($(".user-info").eq(0).children().length === 0) {
        $(".user-info").closest(".revise").addClass("border-bottom");
        $(".user-info").html("&nbsp;");
        $("#personMsg").css({'top':'0.266rem','font-size':'0.16rem'});
        $("#personMsg").parents('ul').css('height','0.72rem').addClass('border-bottom');
    }
});
isNull();

isgoback(true);
$('#shback').click(function () {
    if (dataSign['from'] == 'sign') {
        window.history.go(-2);
    } else {
        window.history.go(-1);
    }
});

function onBackPressed() {
    isgoback(true);
    if (canGoBack) {
        if (dataSign['from'] == 'sign') {
            window.history.go(-2);
        } else {
            window.history.go(-1);
        }
    } else {
        $('.bzj-xieyi, #addZ').hide();
        canGoBack = true;
    }
}

var reload = false;

function initWebData() {
    bzjflag = dataSign.bzjflag;
    suc = dataSign.flag;
    from = dataSign.from;
    if (bzjflag == "CQ") {
        $("#titName").text("春秋旅游保证金");
    }
    //TODO: 禁用各种输入框和按钮
    $("#toDate,#backDate,#money,#dingdanhao,#tuanhao").attr('disabled', true);
    $("#toDate,#backDate,#dingdanhao,#tuanhao,#money").attr("readonly", true);
    $('.users').off('click');
    $('#add').hide();
    $('.rotateV').hide();
    if (dataSign != null) {
        if (bzjflag == "CQ") {
            $(".CQ").show();
            $(".TC").hide();
            $("#tuanhao").val(dataSign.travelNo);
        } else {
            $(".CQ").hide();
            $(".TC").show();
            $("#dingdanhao").val(dataSign.travelNo);
        }
        if (dataSign.lockFlag == "1") {
            $("#change").hide();
            $('#rollIn').addClass("on");
        }
        $("#name").html(dataSign.userName);
        var idNumber = dataSign.idNumber;
        $("#cardNo").html(idNumber.substring(0, 3) + "*************" + idNumber.substring(idNumber.length - 2, idNumber.length));
        phone = dataSign.mobile;
        $("#phoneNum").html(phone.substring(0, 3) + "****" + phone.substring(phone.length - 4, phone.length));
        $('#agreement').text('《' + dataSign.agreementName + '》');
        $('#agreement').click(function () {
            $('#tcxy').show();
            canGoBack = false;
        });
        //var detail ={};
        //detail["title"]=dataSign.agreementName;
        //detail["url"]=dataSign.agreementUrl;
        //$('#agreement').click(function () {
        //    window.location.href = "../otherPage.html?txt$" + encodeURI(JSON.stringify(detail));
        //
        //});
        $('#headerName,#headerName1').text(dataSign.agreementName);
        /*if (/iphone|ipad|ipod/.test(ua)) {
            $('#agreement').click(function () {
                $('#tcxy').show();
                canGoBack = false;
            });
        }
        else if (/android/.test(ua)) {
            $('#agreementurl').attr('src', dataSign.agreementUrl);

            $('#agreement').click(function () {
                $('#xieyi-az').show();
                canGoBack = false;
            });
        }*/
        $("#toDate").val(dateType(dataSign.travelDate));
        $("#backDate").val(dateType(dataSign.travelBackDate));
        $("#money").val(dataSign.txnAmt);

        var travelUserInfoList = dataSign.travelUserInfoList;
        if (travelUserInfoList == "") {
            addList = [];
        } else {
            addList = travelUserInfoList;
        }
        $("#chu").html('');
        var sethtml = "";
        $.each(addList, function (index, item) {
            sethtml = '<p class="border-bottom users">\n' +
                '                    <span class="font-14">' + item.travelUserName + '</span>\n' +
                '                    <span class="font-666 font-16">' + item.travelUserIdNo.substr(0, 3) + item.travelUserIdNo.slice(3, -2).replace(/\d/ig, '*') + item.travelUserIdNo.substr(item.travelUserIdNo.length - 2, item.travelUserIdNo.length > 3 ? 2 : -1) + '</span>\n' +
                '                    <span><img src="../img/cityTourismNew/gb@2x.png" alt="" class="del" onclick="del(this)" style="display: none;"></span>\n' +
                '                </p>';
            $("#chu").append(sethtml);
        });
        isNull();
        hasValueClass('.main');
    }
    if (reload) {
        $('#codeNo').val('');
        blurAnimation('#codeNo');
        reload = false;
        $('#rollIn, #change').show();
        $('#cancel, #sures').hide();
        time && clearInterval(time);
        $("#getCodes").val("获取验证码");
        $('#getCodes').css({"color": "#1773D0"});
        $("#getCodes").attr("disabled", false);
    }
}

//样式
function isNull(){
    if($(".user-info").has('p').length==0){
        $("#personMsg").css({'top':'0.266rem','font-size':'0.16rem'});
        $("#personMsg").parents('ul').css('height','0.72rem').addClass('border-bottom');
    }else{
        $("#personMsg").css({'top':'0','font-size':'0.12rem'});
        $("#personMsg").parents('ul').css('height','auto').removeClass('border-bottom');
    }
}



/**
 * 获取短信验证码
 */
function getCode() {
    try{
        var jsonObject = getJsonObject();
        jsonObject["method"] = "dbk.auth.shortMsgLoginCheck";
        //请求参数追加自定义参数
        jsonObject["sendType"] = "0";
        jsonObject["queryEacctFlag"] = "0";
        jsonObject["mobile"] = phone;
        var jsonObject2 = secondaryIndilling(jsonObject);
        jsonObject2["method"] = "dbk.auth.shortMsgLoginCheck";
        $.ajax({
            type: "POST",
            url: address,
            dataType: "json",
            data: jsonObject2,
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            timeout: requestTimeOut,
            beforeSend: function () {
                showLoding();
            },
            success: function (data1) {
                var dataCode = secondaryde(data1);
                if (null != jsonObject.timeStamp) {
                    if (dataCode != null) {
                        var retSign = getRetSign(dataCode.retSign);
                        if (jsonObject.timeStamp == retSign) {
                            if (dataCode.retCode == "000000") {
                                if (isBeta) {
                                    $("#codeNo").val(dataCode.dymcode);
                                    // Alert("验证码为" + dataCode.dymcode);
                                }
                                tipsWell(dataCode.retMsg);
                            } else {
                                tipsError(dataCode.retMsg);
                            }
                        } else {
                            // alert("校验签名失败1");
                            tipsError("校验签名失败1");
                        }
                    }
                } else {
                    // alert("校验签名失败2");
                    tipsError("校验签名失败2");
                }
            },
            error: function () {
                requestFailTips();
            },
            complete: function () {
                dissmissLoding();
            }
        });
        msgCodeEvent('点击发送验证码-旅游保证金','signSuccess.html','1');
    }catch (e) {
        alert(e.message);
    }
}

/**
 * 短信验证码验证
 * @param code
 */
function checkCode(userlist) {
    // msgCodeEvent('提交验证码-旅游保证金','signSuccess.html','2');
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.auth.shortMsgValidate";
    //请求参数追加自定义参数
    jsonObject["dymCode"] = userlist.no;
    jsonObject["isRegFlag"] = "1";
    jsonObject["mobile"] = phone;
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.auth.shortMsgValidate";
    getForData(jsonObject2, function (data) {
        sureSign1(userlist);
    });
}

/**
 * 用户签约接口
 */

function sureSign1(userlist) {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.subeaccount.updateTravelUserInfo";
    //请求参数追加自定义参数
    jsonObject["userId"] = getMid();
    jsonObject["type"] = bzjflag;
    jsonObject["travelNo"] = userlist.travelNo;
    //var travelUserInfoList=list;
    // alert(JSON.stringify(addList));
    jsonObject["travelUserInfoList"] = addList;
    jsonObject["travelDate"] = userlist.travelDate;
    jsonObject["travelBackDate"] = userlist.travelBackDate;
    jsonObject["txnAmt"] = userlist.txnAmt;
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.subeaccount.updateTravelUserInfo";
    getForData(jsonObject2, function (data) {
        // alert(JSON.stringify(data));
        data["bzjflag"] = bzjflag;
        $("#chu").html('');
        dataSign = data;
        dataSign.from = dataSign.from;
        reload = true;
        $('.code-item').hide();
        initWebData();
        tipsWell('恭喜您，修改成功');
        $(".user-info").addClass('changed');
    });

}


//修改
$("#change").click(function(){
    $("#add").show();
    $(".del").show();
    $(".user-info").removeClass('changed');
    //TODO:把禁用取消还原
    $("#toDate,#backDate,#money,#dingdanhao,#tuanhao").attr('disabled',false);
    $("#dingdanhao,#tuanhao,#money").attr("readonly",false);
    $(".code-item").show();
    addEvent();

    $('#rollIn').hide();
    $('#cancel').show();
    $('#sures').show();
    $(this).hide();
    $('.rotateV').show();
    isNull();
});
//确认
$('#sures').click(function () {
    var no = $("#codeNo").val();
    //  var sta = $('img.g2').css('display'); // 协议
    var travelNo = "";
    var travelDate = $("#toDate").val();
    var travelBackDate = $("#backDate").val();
    var txnAmt = $("#money").val();

    if (bzjflag == "TC") {
        travelNo = $("#dingdanhao").val();
        if (travelNo == "") {
            // alert("请输入出游订单号");
            tipsError("请输入出游订单号");
            return;
        }
    } else {
        travelNo = $("#tuanhao").val();
        if (travelNo == "") {
            // alert("请输入出游团号");
            tipsError("请输入出游团号");
            return;
        }
    }
    ;
    if (travelDate == "") {
        // alert("请选择出游日期");
        tipsError("请选择出游日期");
        return;
    }
    ;
    if (travelBackDate == "") {
        // alert("请选择归来日期");
        tipsError("请选择归来日期");
        return;
    }
    ;
    if (travelDate > travelBackDate) {
        // alert('出游日期不能大于归来日期');
        tipsError('出游日期不能大于归来日期');
        return;
    }
    ;
    if (txnAmt == "") {
        // alert("请输入保证金金额");
        tipsError("请输入保证金金额");
        return;
    } else if (txnAmt <= 0) {
        // alert("保证金金额不能为0");
        tipsError("保证金金额不能为0");
        return;
    }
    ;
    if (no == "" || no == null) {
        // alert("请输入动态密码");
        // alert("请输入短信验证码");
        tipsError("请输入短信验证码");
        return;
    }
    ;
    if (addList.length < 1) {
        // alert("请添加出游人信息");
        tipsError("请添加出游人信息");
        return;
    }
    ;
    var userlist = {no: no, travelNo: travelNo, travelDate: travelDate, travelBackDate: travelBackDate, txnAmt: txnAmt};
    checkCode(userlist);

});
//取消
$('#cancel').click(function () {
    // window.location.reload();
    reload = true;
    $('.code-item').hide();
    $(".user-info").addClass('changed');
    initWebData();
});

//获取验证码点击事件
$("#getCodes").click(function () {
//		alert(1)
    $("#getCodes").attr("disabled", true);
    var count_down = parseInt(60);
    $("#getCodes").val("60s后重新发送");
    $('#getCodes').css({"color": "#999",});
    time = setInterval(function () {
        count_down--;
        // $("#getCodes").val(count_down + "s后重新发送");
        $("#getCodes").val(count_down + "s");
        if (count_down < 0) {
            clearInterval(time);
            $("#getCodes").val("重新发送");
            $('#getCodes').css({"color": "#1773D0"});
            $("#getCodes").attr("disabled", false);
        }
    }, 1000);
    getCode();
});

//添加出游人按钮点击事件
$('#add').click(function () {
    var len=$('.users').length;
    if(len>=10){
        // alert("最多只能添加10个出游人");
        tipsError("最多只能添加10个出游人");
        return ;
    }else{
        // $('#signCon').hide();
        $('#addZ').show();
        canGoBack = false;
        $('#enter').show().siblings('#enters').hide();
        $('#addOrEdit').text('新增出游人');
        $('#add-close').show().siblings('img').hide();
    }
});
//添加出游人确认按钮点击事件
$('#enter').click(function () {
    // $("#add").show();
    var sightseeing_name=$("#sightseeing_name").val();
    //todo:证件类型
    var  optionsType=$("#types_dummy").text();
    var sightseeing_number=$("#sightseeing_number").val();
    if(sightseeing_name==""){
        // alert("请输入姓名");
        tipsError("请输入姓名");
        return;
    }else if(optionsType==""){
        // alert("请选择证件类型");
        tipsError("请选择证件类型");
        return;
    }else if(sightseeing_number==""){
        // alert("请输入证件号码");
        tipsError("请输入证件号码");
        return;
    }
    else if(sightseeing_name!=""&&optionsType!="请选择证件类型"&&sightseeing_number!=""){
        var sethtml =   '<p class="border-bottom users">\n' +
            '            <span class="font-14">'+ sightseeing_name + '</span>\n' +
            '            <span class="font-666 font-16">' + sightseeing_number.substr(0, 3) + sightseeing_number.slice(3, -2).replace(/\d/ig, '*') + sightseeing_number.substr(sightseeing_number.length - 2, sightseeing_number.length > 3 ? 2 : -1) + '</span>\n' +
            '            <span><img src="../img/cityTourismNew/gb@2x.png" alt="" class="del" onclick="del(this)"></span>\n' +
            '            </p>';
        var len=$('.users').length;
        if(len<1){
            $("#chu").append(sethtml);
        }else{
            $("#chu .users:last-child").after(sethtml);
        }
        var ob={travelUserName:sightseeing_name,travelUserType:optionsType,travelUserIdNo:sightseeing_number}
        addList.push(ob);
        $('#sightseeing_name,#sightseeing_number').val('');
        $('#types_dummy').text('');
        hasValueClass('#addZ');
        blurAnimation('#dummy');
        $('#addZ').hide();
        addZ = true;
        isNull();
        addEvent();
        $('#add, #addPerson').css('top', '0%');
    }
});

//点击进入编辑状态添加事件
function addEvent(){
    $(".users").on('click', function () {
        user=$(this).index();
        $(".users").removeClass('active');
        $(this).addClass('active');
        $("#sightseeing_name").val(addList[user].travelUserName);
        $("#types_dummy").text(addList[user].travelUserType);
        $("#sightseeing_number").val(addList[user].travelUserIdNo);
        $('#addZ').show();
        canGoBack = false;
        // $('#signCon').hide();
        $('#addOrEdit').text('编辑出游人信息');
        $('#edit-close').show().siblings('img').hide();
        $('#enters').show().siblings('#enter').hide();
        hasValueClass('#addZ');
        focusAnimation('#dummy');
    });
}
//删除出游人
function del(t){
    window.event.stopPropagation();
    showPopAffirm('温馨提示', '是否删除出游人信息？', '取消', '确认');
    $(".confirm").on('click', function () {
        goCofirm(t);
    });
}
//删除出游人点击确认的回调
function goCofirm(t){
    addList.splice($(t).closest('p').index(), 1);
    $(t).closest("p").remove();
    if ($(".user-info").eq(0).children().length === 0) {
        $(".user-info").closest(".revise").addClass("border-bottom");
        // $(".user-info").html("&nbsp;");
        $("#personMsg").css({'top':'0.266rem','font-size':'0.16rem'});
        $("#personMsg").parents('ul').css('height','0.72rem').addClass('border-bottom');
        $('#add, #addPerson').css('top', '125%');
    }
}
//修改
$("#enters").click(function(){
    $("#add").show();
    var sightseeing_name=$("#sightseeing_name").val();
    var  optionsType=$("#types_dummy").text();
    var sightseeing_number=$("#sightseeing_number").val();
    if(sightseeing_name==""){
        // alert("请输入姓名");
        tipsError("请输入姓名");
        return;
    }else if(optionsType==""){
        // alert("请选择证件类型");
        tipsError("请选择证件类型");
        return;
    }else if(sightseeing_number==""){
        // alert("请输入证件号码");
        tipsError("请输入证件号码");
        return;
    } else if(sightseeing_name!=""&&optionsType!=""&&sightseeing_number!=""){
        //替换当前名字
        $('#chu').find('.active').find('.font-14').text(sightseeing_name);
        $('#chu').find('.active').find('.font-16').text(sightseeing_number.substr(0, 3) + sightseeing_number.slice(3, -2).replace(/\d/ig, '*') + sightseeing_number.substr(sightseeing_number.length - 2, sightseeing_number.length > 3 ? 2 : -1));
        //替换该条数据；
        var user = $('#chu').find('.active').index();
        addList[user].travelUserName=sightseeing_name;
        addList[user].travelUserType=optionsType;
        addList[user].travelUserIdNo=sightseeing_number;
        $("#sightseeing_number,#sightseeing_name").val('');
        $("#types_dummy").text('');
        hasValueClass('#addZ');
        blurAnimation('#dummy');
        $('#addZ').hide();
        canGoBack = true;
        // $('#signCon').show();
        $('#add').show();
        isNull();
    }
});
//去转入
$('#rollIn').click(function () {
    window.location.href = "../assetsNew/assets-ecome.html";
});

var user = "";
//添加出游人时的关闭按键事件
$('#add-close').click(function(){
    $('#addZ').hide();
    canGoBack = true;
    // $('#signCon').show();
});
//编辑出游人时的关闭按键事件
$('#edit-close').click(function(){
    $('#addZ').hide();
    canGoBack = true;
    $('#sightseeing_name,#sightseeing_number').val('');
    $('#types_dummy').text('');
    hasValueClass('#addZ');
    blurAnimation('#dummy');
    // $('#signCon').show();
});
$('.hide').click(function(){
    $('#tcxy,.bzj-xieyi').hide();
    canGoBack = true;
});