/**
 * Created by wym on 2016/7/18.
 */

var isSuccess = false;
var signData;
var from="";
var tips="";

$(function () {
    setTimeout(function () {
        IsNeedClear();
        getTransferData("login_key");
        fondCQ();
    }, 100)

});

isgoback(true);

function onBackPressed() {
    window.history.go(-1);
}

function fondCQ(){
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.subeaccount.haveCQ";
    //请求参数追加自定义参数
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.subeaccount.haveCQ";
    getForData(jsonObject2,function (data) {
        if(data.flag=="0"){
            //TODO:选择旅游社——同程,点击下一步进入，判断是否签约
            dataInit(1);
        }else{
            //TODO:选择旅游社——春秋
            dataInit(2);
        }
    });
};

function dataInit(from){
    getTips(from);
}

//获取旅游公司提示
function getTips(from){
    var type="";
    if(from=='1'){
        type="TC";
    }else{
        type="CQ"
    }
    var jsonObject = getJsonObject();
    jsonObject["method"] ="dbk.subeaccount.getWXTS";
    jsonObject["type"] = type;
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.subeaccount.getWXTS";
    getForData(jsonObject2, function (data) {
        tips=data.wxtsList;
        $(".tips").text(tips);
        if (from=="1"){
            //同程保证金
            $("#sign").click(function () {
                rightEnter(function () {
                    //进入签约
                    getSignInfo("1");
                });
            });
            $("#query").click(function () {
                rightEnter(function () {
                    getSignInfo("");
                });
            })
        }else {
            //春秋保证金
            $("#typeTitle").text("春秋保证金");
//          $(".tips").text("温馨提示：如有保证金相关问题，可拨打春秋客服热线4007-777-7777，不收取长途费。");
            $("#sign").click(function () {
                rightEnter(function () {
                    getCQSignInfo("1");
                });
            });
            $("#query").click(function () {
                rightEnter(function () {
                    getCQSignInfo("");
                });
            });
        }
    });
}




/**
 * 获取同程用户信息
 */
function getSignInfo(type) {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.subeaccount.serachTravelUserInfo";
    //请求参数追加自定义参数
    jsonObject["userId"] = getMid();
    jsonObject["type"] ="TC";
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.subeaccount.serachTravelUserInfo";
    $.ajax({
        type: "POST",
        url: address,
        dataType: "json",
        data: jsonObject2,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        timeout: requestTimeOut,beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var data = secondaryde(data1);
            signData = data;
            if (data.retCode == "000000") {
                isSuccess = true;
                if(type =="1"){
                    if (isSuccess) {
                        // restoreState(signData["bzjflag"]);
                        if (signData.flag == "1") {
                            signData["bzjflag"]="TC";
                            // alert(JSON.stringify(signData));
                            window.location.href = "signSuccess.html?txt$" + encodeURI(JSON.stringify(signData));
                        } else if (signData.flag == "0") {
                            signData["bzjflag"]="TC";
                            // alert(JSON.stringify(signData));
                            window.location.href = "sign.html?txt$" + encodeURI(JSON.stringify(signData));
                        }
                    }
                }else{
                    checkSign();
                }
            } else if (data.retCode == "Login9999") {
                logout();
                doKickOutAction("", "");
            } else if (data.retCode == "Login9998") {
                logout();
                logout1("home");
            } else {
                isSuccess = false;
                tipsError(data.retMsg);
            }
        },
        error: function () {
            isSuccess = false;
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}


function getCQSignInfo(type) {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.subeaccount.serachTravelUserInfo";
    //请求参数追加自定义参数
    jsonObject["userId"] = getMid();
    jsonObject["type"] ="CQ";
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.subeaccount.serachTravelUserInfo";
    $.ajax({
        type: "POST",
        url: address,
        dataType: "json",
        data: jsonObject2,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        timeout: requestTimeOut,
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var data = secondaryde(data1);
            signData = data;
            // alert(JSON.stringify(signData));
            if (data.retCode == "000000") {
                isSuccess = true;
                if(type =="1"){
                    if (isSuccess) {
                        // restoreState(signData["bzjflag"]);
                        if (signData.flag == "1") {
                            signData["bzjflag"]="CQ";
                            // alert(JSON.stringify(signData));
                            window.location.href = "signSuccess.html?txt$" + encodeURI(JSON.stringify(signData));
                            // window.location.href = "bzj_signSuccess.html?txt$" + encodeURI(JSON.stringify(signData));
                        } else if (signData.flag == "0") {
                            signData["bzjflag"]="CQ";
                            // alert(JSON.stringify(signData));
                            window.location.href = "sign.html?txt$" + encodeURI(JSON.stringify(signData));
                            // window.location.href = "bzj_sign.html?txt$" + encodeURI(JSON.stringify(signData));
                        }
                    }
                }else{
                    checkSign("1");

                }
            } else if (data.retCode == "Login9999") {
                logout();
                doKickOutAction("", "");
            } else if (data.retCode == "Login9998") {
                logout();
                logout1("home");
            } else {
                isSuccess = false;
                tipsError(data.retMsg);
            }
        },
        error: function () {
            isSuccess = false;
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
}

/**
 * 检查用户是否签约
 */
function checkSign(type) {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.subeaccount.queryTongCheng";
    //请求参数追加自定义参数
    jsonObject["mobile"] = getMobile();
    if (type=="1"){
        jsonObject["type"] ="CQ";

    }else {
        jsonObject["type"] ="TC";

    }
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.subeaccount.queryTongCheng";
    getForData(jsonObject2, function (data) {
        // var data = secondaryde(data1);
        // if (data.retCode == "000000") {
        // alert(JSON.stringify(data));
        if (data.contractStatus == "0") {
            var sign = confirm("您尚未签约，是否签约?");
            if (sign) {
                //1 chunqiu
                if (type=="1"){
                    signData["bzjflag"]="CQ";

                    window.location.href = "sign.html?txt$" + encodeURI(JSON.stringify(signData));

                }else {
                    signData["bzjflag"]="TC";

                    window.location.href = "sign.html?txt$" + encodeURI(JSON.stringify(signData));

                }
            }
        } else if (data.contractStatus == "1") {
            if (type=="1"){
                data["type"]="1";
                window.location.href = "query.html?txt$"+encodeURI(JSON.stringify(data));

            }else {
                data["type"]="0";

                window.location.href = "query.html?txt$"+encodeURI(JSON.stringify(data));

            }
        }
    });
}
