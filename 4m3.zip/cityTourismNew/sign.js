/**
 * Created by wym on 2016/7/19.
 */
var list=[];
var li="";
var addList=[];
var  backflag="1";
var Request, txt, dataSign, bzjflag, suc, from;
/*var txt = (Request["txt"]);
var dataSign = JSON.parse(txt);
var bzjflag =dataSign.bzjflag;
var suc=dataSign.flag;
var from = dataSign.from;*/
var canGoBack = true;
isgoback(true);

function onBackPressed() {
    isgoback(true);
    if (canGoBack) {
        window.history.go(-1);
    } else {
        $('.bzj-xieyi,#addZ').hide();
        canGoBack = true;
    }
}


setTimeout(function () {
    try {
        IsNeedClear();
        getTransferData("login_key");
    } catch (e) {
        alert(e.message);
    }
    Request = GetRequest();
    txt = (Request["txt"]);
    dataSign = JSON.parse(txt);
    bzjflag = dataSign.bzjflag;
    suc = dataSign.flag;
    from = dataSign.from;
    // agree();
    if (bzjflag == "CQ") {
        $("#titName").text("春秋旅游保证金");
    }
    if (dataSign != null) {
        if(bzjflag=="CQ"){
            $(".CQ").show();
            $(".TC").hide();
            $("#tuanhao").val(dataSign.travelNo);
        }else{
            $(".CQ").hide();
            $(".TC").show();
            $("#dingdanhao").val(dataSign.travelNo);
        }
        $("#name").html(dataSign.userName);
        var idNumber = dataSign.idNumber;
        $("#cardNo").html(idNumber.substring(0, 3) + "*************" + idNumber.substring(idNumber.length - 2, idNumber.length));
        phone = dataSign.mobile;
        $("#phoneNum").html(phone.substring(0, 3) + "****" + phone.substring(phone.length - 4, phone.length));
        $('#agreement').text('《'+ dataSign.agreementName+'》' );

        $('#headerName,#headerName1').text(dataSign.agreementName);
        $('#agreement').click(function () {
            $('#tcxy').show();
            canGoBack = false;
        });
        //todo:
        /*if (/iphone|ipad|ipod/.test(ua)) {
            $('#agreement').click(function(){
                $('#tcxy').show();
            });
        }
        else if (/android/.test(ua)) {
            // $('#showHref').text(dataSign.agreementUrl);
            // http://testclient.mybosc.com:10088/portal4m120/page/agreement/tongcheng.html
            $('#agreementurl').attr('src', dataSign.agreementUrl);

            $('#agreement').click(function () {
                isgoback(true);

                $('#xieyi-az').show();
                backflag="0";

            });
        }*/
        //出游日期
        $("#toDate").text(dataSign.travelDate);
        //归来日期
        $("#backDate").text(dataSign.travelBackDate);
        //保证金金额
        $("#money").val(dataSign.txnAmt);
        var travelUserInfoList =dataSign.travelUserInfoList;

        if(travelUserInfoList==""){
            addList=[];
        }else{
            addList=travelUserInfoList;
        }
        var sethtml ="";
        //出游人信息
        $.each(addList, function(index,item) {
            sethtml = '<p class="border-bottom users">\n' +
                // '                    <span class="font-14">' + item.travelUserName + '</span>\n' +
                '                    <span class="font-16">' + item.travelUserName + '</span>\n' +
                '                    <span class="font-666 font-16">' + item.travelUserIdNo.substr(0, 3) + item.travelUserIdNo.slice(3, -2).replace(/\d/ig, '*') + item.travelUserIdNo.substr(item.travelUserIdNo.length - 2, item.travelUserIdNo.length > 3 ? 2 : -1) + '</span>\n' +
                '                    <span class="del"><img src="../img/cityTourismNew/gb@2x.png" alt=""></span>\n' +
                '                </p>'
            // sethtml ='<span  class="users">'+item.travelUserName+'</span>';
            $("#chu").append(sethtml);
        });
    }
}, 100);

var phone = "";

function del(t){
    window.event.stopPropagation();
    showPopAffirm('温馨提示', '是否删除出游人信息？', '取消', '确认');
    $(".confirm").on('click', function () {
        goCofirm(t);
    });
}
function goCofirm(t){
    addList.splice($(t).closest('p').index(), 1);
    // alert($(t).closest('p').index());
    $(t).closest("p").remove();
    if ($(".user-info").eq(0).children().length === 0) {
        $(".user-info").closest(".revise").addClass("border-bottom");
        $("#personMsg").css({'top':'0.266rem','font-size':'0.16rem'});
        $("#personMsg").parents('ul').css('height','0.72rem').addClass('border-bottom');
        $('#add, #addPerson').css('top', '10%');
    }
}
$('#addPerson').click(function () {
    var len=$('.users').length;
    if(len>=10){
        alert("最多只能添加10个出游人");
        return ;
    }else{
        $('#addZ').show();
        canGoBack = false;
        $('#enter').show().siblings('#enters').hide();
        $('#addOrEdit').text('新增出游人');
        $('#add-close').show().siblings('img').hide();
    }
});


//点击进入编辑状态
function edit(t){
    $(".users").removeClass('active');
    $(t).addClass('active');
    $("#sightseeing_name").val(addList[$(t).index()].travelUserName);
    $("#types_dummy").text(addList[$(t).index()].travelUserType);
    $("#sightseeing_number").val(addList[$(t).index()].travelUserIdNo);
    $('#addZ').show();
    canGoBack = false;
    $('#addOrEdit').text('编辑出游人信息');
    $('#edit-close').show().siblings('img').hide();
    $('#enters').show();
    $('#enter').hide();
    hasValueClass('#addZ');
    focusAnimation('#dummy');
}

//修改
$("#enters").click(function(){
    var sightseeing_name=$("#sightseeing_name").val();
    var optionsType = $('#types_dummy').text();
    var sightseeing_number=$("#sightseeing_number").val();
    if(sightseeing_name==""){
        tipsError("请输入姓名");
        return;
    }else if(optionsType==""){
        tipsError("请选择证件类型");
        return;
    }else if(sightseeing_number==""){
        tipsError("请输入证件号码");
        return;
    }
    else if(sightseeing_name!=""&&optionsType!="请选择证件类型"&&sightseeing_number!=""){
        //替换当前名字
        $('#chu').find('.active').find('.font-14').text(sightseeing_name);
        $('#chu').find('.active').find('.font-16').text(sightseeing_number.substr(0, 3) + sightseeing_number.slice(3, -2).replace(/\d/ig, '*') + sightseeing_number.substr(sightseeing_number.length - 2, sightseeing_number.length > 3 ? 2 : -1));
        //替换该条数据；
        var user = $('#chu').find('.active').index();
        addList[user].travelUserName=sightseeing_name;
        addList[user].travelUserType=optionsType;
        addList[user].travelUserIdNo=sightseeing_number;
        $("#sightseeing_name,#sightseeing_number").val('');
        $('#types_dummy').text('');
        hasValueClass('#addZ');
        blurAnimation('#dummy');
        $('#addZ').hide();
        canGoBack = true;
    }
});

//获取验证码
$("#getCodes").click(function () {
    $("#getCodes").attr("disabled", true);
    var count_down = parseInt(60);
    $("#getCodes").val("60s后重新发送");
    $('#getCodes').css({"color": "#999",});
    var time = setInterval(function () {
        count_down--;
        // $("#getCodes").val(count_down + "s后重新发送");
        $("#getCodes").val(count_down + "s");
        if (count_down < 0) {
            clearInterval(time);
            $("#getCodes").val("重新发送");
            $('#getCodes').css({"color": "#1773D0"});
            $("#getCodes").attr("disabled", false);
        }
    }, 1000);
    getCode();
});

/*
* 隐藏协议
* */
$('.hide').click(function(){
    $('#tcxy,.bzj-xieyi').hide();
    canGoBack = true;
});

/*
* 编辑、添加关闭事件*/
$('#add-close').click(function () {
    $('#addZ').hide();
    canGoBack = true;
});
$('#edit-close').click(function () {
    $('#sightseeing_name,#sightseeing_number').val('');
    $('#types_dummy').text('');
    hasValueClass('#addZ');
    blurAnimation('#dummy');
    $('#addZ').hide();
    canGoBack = true;
});

//添加出游人
$('#enter').click(function () {
    var sightseeing_name=$("#sightseeing_name").val();
    //todo:证件类型
    var  optionsType=$("#types_dummy").text();
    var sightseeing_number=$("#sightseeing_number").val();
    if(sightseeing_name==""){
        // alert("请输入姓名");
        tipsError("请输入姓名");
        return;
    }else if(optionsType==""){
        // alert("请选择证件类型");
        tipsError("请选择证件类型");
        return;
    }else if(sightseeing_number==""){
        // alert("请输入证件号码");
        tipsError("请输入证件号码");
        return;
    }
    else if(sightseeing_name!=""&&optionsType!="请选择证件类型"&&sightseeing_number!=""){
        var sethtml =   '<p class="border-bottom users" onclick="edit(this)">\n' +
            '            <span class="font-14">'+ sightseeing_name + '</span>\n' +
            '            <span class="font-666 font-16">' + sightseeing_number.substr(0, 3) + sightseeing_number.slice(3, -2).replace(/\d/ig, '*') + sightseeing_number.substr(sightseeing_number.length - 2, sightseeing_number.length > 3 ? 2 : -1) + '</span>\n' +
            '            <span class="del"><img src="../img/cityTourismNew/gb@2x.png" alt="" onclick="del(this)"></span>\n' +
            '            </p>';
        var len=$('.users').length;
        if(len<1){
            $("#chu").append(sethtml);
        }else{
            $("#chu .users:last-child").after(sethtml);
        }
        var ob={travelUserName:sightseeing_name,travelUserType:optionsType,travelUserIdNo:sightseeing_number}
        addList.push(ob);
        $('#sightseeing_name,#sightseeing_number').val('');
        $('#types_dummy').text('');
        isNull();
        $('#add, #addPerson').css('top', '0%');
        hasValueClass('#addZ');
        blurAnimation('#dummy');
        $('#addZ').hide();
        canGoBack = true;
    }
});

$('.hide').click(function(){
    $('#tcxy,.bzj-xieyi').hide();
    canGoBack = true;
});

/**
 * 获取短信验证码
 */
function getCode() {
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.auth.shortMsgLoginCheck";
    //请求参数追加自定义参数
    jsonObject["sendType"] = "0";
    jsonObject["queryEacctFlag"] = "0";
    jsonObject["mobile"] = phone;
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.auth.shortMsgLoginCheck";
    $.ajax({
        type: "POST",
        url: address,
        dataType: "json",
        data: jsonObject2,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        timeout: requestTimeOut,
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var dataCode = secondaryde(data1);
            if (null != jsonObject.timeStamp) {
                if (dataCode != null) {
                    var retSign = getRetSign(dataCode.retSign);
                    if (jsonObject.timeStamp == retSign) {
                        if (dataCode.retCode == "000000") {
                            if (isBeta) {
                                $("#codeNo").val(dataCode.dymcode);
                                // Alert("验证码为" + dataCode.dymcode);
                            }
                            tipsWell(dataCode.retMsg);
                        } else {
                            tipsError(dataCode.retMsg);
                        }
                    } else {
                        // alert("校验签名失败1");
                        tipsError("校验签名失败1");
                    }
                }
            } else {
                // alert("校验签名失败2");
                tipsError("校验签名失败2");
            }
        },
        error: function () {
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });
    msgCodeEvent('点击发送验证码-旅游保证金','sign.html','1');
}

/**
 * 短信验证码验证
 * @param code
 */
function checkCode(userlist) {
    msgCodeEvent('提交验证码-旅游保证金','sign.html','2');
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.auth.shortMsgValidate";
    //请求参数追加自定义参数
    jsonObject["dymCode"] = userlist.no;
    jsonObject["isRegFlag"] = "1";
    jsonObject["mobile"] = phone;
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.auth.shortMsgValidate";
    getForData(jsonObject2, function (data) {
        sureSign(userlist);
    });
}

/**
 * 用户签约接口
 */
function sureSign(userlist) {
    // alert(JSON.stringify(userlist));
    var jsonObject = getJsonObject();
    jsonObject["method"] = "dbk.subeaccount.openSubEaccount";
    //请求参数追加自定义参数
    jsonObject["userId"] = getMid();
    jsonObject["type"] =bzjflag;
    jsonObject["travelNo"] =userlist.travelNo;
    //var travelUserInfoList=list;
    jsonObject["travelUserInfoList"] =addList;
    jsonObject["travelDate"] =userlist.travelDate;
    jsonObject["travelBackDate"] =userlist.travelBackDate;
    jsonObject["txnAmt"] =userlist.txnAmt;
    // alert('sureSign-----jsonObject--->' + JSON.stringify(jsonObject));
    var jsonObject2 = secondaryIndilling(jsonObject);
    jsonObject2["method"] = "dbk.subeaccount.openSubEaccount";
    $.ajax({
        type: "POST",
        url: address,
        dataType: "json",
        data: jsonObject2,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        timeout: requestTimeOut,
        beforeSend: function () {
            showLoding();
        },
        success: function (data1) {
            var data = secondaryde(data1);
            data["bzjflag"]=bzjflag;
            if (data.retCode == "000000") {
                if (data.flag == "1") {
                    if(data.openFlag=="1"){
                        var success = confirm(data.wxts);
                        if (success) {
                            var bzjData = {};
                            bzjData["from"] = "bzj";
                            window.location.href = "../assetsNew/assets-ecome.html?txt$" + JSON.stringify(bzjData);
                        } else {
                            data['from'] = 'sign';
                            window.location.href = "signSuccess.html?txt$" + JSON.stringify(data);
                        }
                    }else{
                        var success = confirm("恭喜您，签约成功");
                        if (success) {
                            var bzjData = {};
                            bzjData["from"] = "bzj";
                            window.location.href = "../assetsNew/assets-ecome.html?txt$" + JSON.stringify(bzjData);
                        } else {
                            data['from'] = 'sign';
                            window.location.href = "signSuccess.html?txt$" + JSON.stringify(data);
                        }
                    }

                } else {
                    tipsError(data.retMsg);
                }
            } else {
                tipsError(data.retMsg);
            }
        },
        error: function () {
            requestFailTips();
        },
        complete: function () {
            dissmissLoding();
        }
    });

}


$('#sure').click(function(){
    var no = $("#codeNo").val();
    var sta = $('#agreeInput').prop('checked'); // 协议
    var	travelNo="";
    var travelDate=$("#toDate").val();
    var travelBackDate=$("#backDate").val();
    var txnAmt=$("#money").val();

    if(bzjflag=="TC"){
        travelNo=$("#dingdanhao").val();
        if(travelNo==""){
            // alert("请输入出游订单号");
            tipsError("请输入出游订单号");
            return;
        }
    }else{
        travelNo=$("#tuanhao").val();
        if(travelNo==""){
            // alert("请输入出游团号");
            tipsError("请输入出游团号");
            return;
        }
    };
    if(travelDate==""){
        // alert("请选择出游日期");
        tipsError("请选择出游日期");
        return;
    };
    if(travelBackDate==""){
        // alert("请选择归来日期");
        tipsError("请选择归来日期");
        return;
    };
    if(travelDate>travelBackDate){
//  	console.log(travelDate + travelBackDate)
//         alert('归来日期不能大于出游日期');
        tipsError('归来日期不能大于出游日期');
        return;

    };
    if(txnAmt==""){
        // alert("请输入保证金金额");
        tipsError("请输入保证金金额");
        return;
    }else if(txnAmt<=0){
        // alert("保证金金额不能为0");
        tipsError("保证金金额不能为0");
        return;
    };

    if (no == "" || no == null) {
        // alert("请输入动态密码");
        // alert("请输入短信验证码");
        tipsError("请输入短信验证码");
        return;
    };

    if (!sta) {
        // alert("请勾选协议");
        tipsError("请勾选协议");
        return;
    };
    if(addList.length<1){
        // alert("请添加出游人信息");
        tipsError("请添加出游人信息");
        return;
    };


    var userlist={no:no,travelNo:travelNo,travelDate:travelDate,travelBackDate:travelBackDate,txnAmt:txnAmt};
    checkCode(userlist);
})




