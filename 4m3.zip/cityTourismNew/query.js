var dat = {};
setTimeout(function () {
    var Request = GetRequest();
    var fo = (Request["txt"]);
    dat = JSON.parse(fo);
    if (dat["type"]=="1"){
        $("#typeTitle").text("春秋保证金");
        $("#tip").show();

    }else {
        //TODO:页面上元素不存在???
        $("#tip1").show();
    }
    if (dat != null) {
        // alert(JSON.stringify(dat));
        // $('#travelNo').text(dat.travelNo);
        $("#workingBal").text("¥" + dat.workingBal);
        $("#rateOfCall").text(dat.rateOfCall);
        $("#currentState").text(dat.currentState);
    }
}, 100);

isgoback(true);
function onBackPressed(){
    window.history.go(-1)
}